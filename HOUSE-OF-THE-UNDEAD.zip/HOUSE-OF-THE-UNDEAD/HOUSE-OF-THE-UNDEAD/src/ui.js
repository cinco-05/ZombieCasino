// ui.js — everything DOM: HUD updates, banners, floating text, hitmarkers,
// threat indicator, settings persistence, local high scores, panel show/hide.

import { CONFIG, clamp } from './config.js';
import { Audio } from './audio.js';

const $ = (id) => document.getElementById(id);
const HS_KEY = 'hotu_highscore_v1';

export class UI {
  constructor(game) {
    this.game = game;
    this.promptTimer = 0;
    this.bannerTimer = 0;
    this._wireSettings();
    this.renderHighscore();
  }

  // ------------------------------ panels ------------------------------------
  show(id) { $(id).classList.remove('hidden'); }
  hide(id) { $(id).classList.add('hidden'); }
  hideAllPanels() {
    for (const id of ['main-menu', 'pause-menu', 'settings-panel', 'boss-intro',
      'intermission', 'wager-panel', 'allin-confirm', 'blackjack-panel',
      'roulette-panel', 'slots-panel', 'poker-panel', 'upgrade-panel', 'summary-panel', 'vault-panel']) {
      this.hide(id);
    }
  }

  requestPointer() {
    // Chrome rejects/throws if this is called too soon after Esc released the
    // lock — one of the intermittent "crashes". Swallow it; the click handler
    // in main.js re-requests on the next click.
    try {
      const p = this.game.renderer.domElement.requestPointerLock?.();
      if (p && typeof p.catch === 'function') p.catch(() => {});
    } catch { /* ignore */ }
  }

  // ------------------------------- HUD --------------------------------------
  updateHUD() {
    const g = this.game, p = g.player, w = g.weapons.current;
    $('hp-text').textContent = Math.ceil(p.hp);
    $('hp-fill').style.width = `${clamp(p.hp / p.maxHp * 100, 0, 100)}%`;
    $('hp-fill').classList.toggle('low', p.hp < 30);

    const armorWrap = $('armor-wrap');
    armorWrap.style.display = p.armor > 0 ? '' : 'none';
    $('armor-fill').style.width = `${clamp(p.armor, 0, 100)}%`;

    $('chips-hud').textContent = g.chips;
    $('weapon-name').textContent = w.def.name + (g.weapons.reloading ? ' — RELOADING' : '');
    $('ammo-mag').textContent = w.mag;
    $('ammo-reserve').textContent = w.reserve;

    // weapon slots line, now 4 slots
    const ids = ['pistol', 'shotgun', 'smg', 'rifle'];
    $('weapon-slots').textContent = ids.map((id, i) => {
      const wp = g.weapons.arsenal[id];
      if (!wp || wp.locked) return '·';
      return g.weapons.currentId === id ? `[${i + 1}]` : `${i + 1}`;
    }).join(' ');

    // NEW: grenades + dash + combo
    $('grenade-hud').textContent = '💣'.repeat(g.player.grenades) || '—';
    const dashPct = clamp(1 - p.dashCd / (CONFIG.player.dashCooldown * g.playerMods.dashCd), 0, 1);
    $('dash-fill').style.width = `${dashPct * 100}%`;
    $('dash-wrap').classList.toggle('ready', dashPct >= 1);

    const comboEl = $('combo-hud');
    if (g.combo >= 2) {
      comboEl.style.display = '';
      comboEl.textContent = `COMBO x${g.comboMult().toFixed(2)} (${g.combo})`;
    } else comboEl.style.display = 'none';

    $('round-hud').textContent = g.round > 0
      ? (g.round > CONFIG.rounds ? `ROUND ${g.round} — ENDLESS` : `ROUND ${g.round} / ${CONFIG.rounds}`)
      : '—';
    const obj = $('objective-hud');
    if (g.objective && (g.state === 'COMBAT' || g.state === 'COUNTDOWN')) {
      obj.style.display = '';
      obj.textContent = g.objective.def.label(g.objective);
      obj.classList.toggle('failed', !!g.objective.failed);
    } else obj.style.display = 'none';
    $('enemies-hud').textContent = g.state === 'COMBAT'
      ? `☠ ${g.enemies.remaining() + g.bosses.filter((b) => !b.dead).length}` : '';

    // penalties list + active special round
    const pen = g.casino.activePenaltyLabels();
    let penHtml = pen.map((t) => `<div class="pen">⚠ ${t}</div>`).join('');
    if (g.specialRound && (g.state === 'COMBAT' || g.state === 'COUNTDOWN')) {
      penHtml = `<div class="pen special">★ ${g.specialRound.name} — chips x${g.specialRound.chipMult}</div>` + penHtml;
    }
    $('penalties-hud').innerHTML = penHtml;

    // boss bar
    const boss = g.bosses.find((b) => !b.dead);
    $('boss-bar').classList.toggle('hidden', !boss);
    if (boss) {
      $('boss-name').textContent = boss.name;
      $('boss-fill').style.width = `${clamp(boss.hp / boss.maxHp * 100, 0, 100)}%`;
    }

    // low-hp vignette pulse (steady when reduced flash)
    const v = $('damage-vignette');
    if (p.hp < 30 && p.hp > 0) {
      const a = this.game.settings.reducedFlash ? 0.35
        : 0.25 + 0.15 * Math.sin(performance.now() / 220);
      v.style.boxShadow = `inset 0 0 140px rgba(200,20,30,${a})`;
    } else if (!this.hurtFlashUntil || performance.now() > this.hurtFlashUntil) {
      v.style.boxShadow = 'none';
    }
  }

  /** corner minimap radar: enemy dots relative to where you're FACING */
  updateRadar() {
    const g = this.game;
    const cv = $('radar');
    const active = (g.state === 'COMBAT' || g.state === 'COUNTDOWN') && !g.casino.roundMods.noIndicator;
    cv.classList.toggle('hidden', !active);
    if (!active) return;

    const ctx = cv.getContext('2d');
    const cx = cv.width / 2, cy = cv.height / 2;
    const R = cv.width / 2 - 4;
    const RANGE = 32;                       // meters shown edge to edge
    const scale = R / RANGE;
    ctx.clearRect(0, 0, cv.width, cv.height);

    // dish
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(8, 5, 16, 0.72)'; ctx.fill();
    ctx.strokeStyle = 'rgba(201,162,39,0.7)'; ctx.lineWidth = 2; ctx.stroke();
    for (const rr of [R * 0.33, R * 0.66]) {
      ctx.beginPath(); ctx.arc(cx, cy, rr, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(201,162,39,0.18)'; ctx.lineWidth = 1; ctx.stroke();
    }

    const fwd = g.player.forwardFlat();
    const right = g.player.rightFlat();
    const dot = (worldPos, color, size, ring = false) => {
      const relX = worldPos.x - g.player.pos.x;
      const relZ = worldPos.z - g.player.pos.z;
      let sx = relX * right.x + relZ * right.z;   // facing-up projection
      let sy = relX * fwd.x + relZ * fwd.z;
      const d = Math.hypot(sx, sy);
      let alpha = 1;
      if (d > RANGE) {                            // clamp to the rim, dimmer
        sx *= RANGE / d; sy *= RANGE / d; alpha = 0.45;
      }
      ctx.globalAlpha = alpha;
      ctx.beginPath();
      ctx.arc(cx + sx * scale, cy - sy * scale, size, 0, Math.PI * 2);
      if (ring) { ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke(); }
      else { ctx.fillStyle = color; ctx.fill(); }
      ctx.globalAlpha = 1;
    };

    const KIND_COLORS = {
      walker: '#ff4a4a', sprinter: '#ff7ad0', brute: '#ff8a3a',
      spitter: '#7aff4a', gasbag: '#d6ff4a', pitguard: '#8fa4ff', collector: '#ffd24a',
      croupier: '#e8ffe8', magician: '#c27aff', jackpot: '#ffe97a',
    };
    for (const z of g.enemies.list) {
      if (z.dead) continue;
      dot(z.mesh.position, KIND_COLORS[z.kind] || '#ff4a4a', z.kind === 'brute' ? 4 : 3);
    }
    for (const b of g.bosses) {
      if (!b.dead) dot(b.mesh.position, '#ff2d2d', 7, true);
    }

    // you: center dot + facing wedge (always up)
    ctx.fillStyle = '#e8e2d0';
    ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx, cy - 11); ctx.lineTo(cx - 4, cy - 4); ctx.lineTo(cx + 4, cy - 4);
    ctx.closePath();
    ctx.fillStyle = 'rgba(232,226,208,0.85)'; ctx.fill();
  }

  hurtFlash() {
    const v = $('damage-vignette');
    this.hurtFlashUntil = performance.now() + 250;
    v.style.boxShadow = 'inset 0 0 160px rgba(220,30,40,0.55)';
  }

  hitmarker(crit = false) {
    const h = $('hitmarker');
    h.className = crit ? 'crit show' : 'show';
    clearTimeout(this._hm);
    this._hm = setTimeout(() => { h.className = ''; }, 90);
  }

  reloadBar(t) {
    const bar = $('reload-bar');
    if (t === null) { bar.style.display = 'none'; return; }
    bar.style.display = '';
    $('reload-fill').style.width = `${t * 100}%`;
  }

  crosshairSpread(px) {
    $('crosshair').style.letterSpacing = `${px}px`;
    $('crosshair').style.fontSize = `${22 + px}px`;
  }

  // --------------------------- text feedback --------------------------------
  banner(text, color = 'gold', ms = 1800) {
    const b = $('banner-el');
    b.textContent = text;
    b.className = `show ${color}`;
    clearTimeout(this._bt);
    this._bt = setTimeout(() => { b.className = ''; }, ms);
  }

  prompt(text, ms = 2200) {
    const p = $('prompt');
    p.textContent = text;
    p.classList.add('show');
    clearTimeout(this._pt);
    this._pt = setTimeout(() => p.classList.remove('show'), ms);
  }

  countdown(n) {
    const c = $('countdown-el');
    c.textContent = n > 0 ? n : 'FIGHT';
    c.className = 'show';
    Audio.play(n > 0 ? 'countdown' : 'go');
    clearTimeout(this._ct);
    this._ct = setTimeout(() => { c.className = ''; }, 800);
  }

  /** floating text at a world position (chips, damage numbers) */
  floatText(worldPos, text, cls = 'chips') {
    const v = worldPos.clone().project(this.game.camera);
    if (v.z > 1) return; // behind camera
    const el = document.createElement('div');
    el.className = `floater ${cls}`;
    el.textContent = text;
    el.style.left = `${(v.x * 0.5 + 0.5) * innerWidth}px`;
    el.style.top = `${(-v.y * 0.5 + 0.5) * innerHeight}px`;
    $('float-layer').appendChild(el);
    setTimeout(() => el.remove(), 900);
  }

  /** edge arrows pointing at off-screen enemies (disabled by a penalty) */
  updateThreatIndicator() {
    const layer = $('threat-layer');
    layer.innerHTML = '';
    const g = this.game;
    if (g.state !== 'COMBAT' || g.casino.roundMods.noIndicator) return;
    const fwd = g.player.forwardFlat();
    let worst = null, worstD = 1e9;
    const threats = [...g.enemies.list, ...g.bosses.filter((b) => !b.dead)];
    for (const e of threats) {
      const d = e.mesh.position.distanceTo(g.player.pos);
      if (d < worstD) { worstD = d; worst = e; }
    }
    if (!worst || worstD > 30) return;
    const to = worst.mesh.position.clone().sub(g.player.pos); to.y = 0; to.normalize();
    const cross = fwd.x * to.z - fwd.z * to.x;
    const dot = fwd.x * to.x + fwd.z * to.z;
    if (dot > 0.5) return; // roughly on screen
    const arrow = document.createElement('div');
    arrow.className = 'threat-arrow';
    arrow.textContent = '⮜';
    const side = cross > 0 ? 'left' : 'right';
    arrow.style[side] = '30px';
    arrow.style.top = '50%';
    if (side === 'right') arrow.style.transform = 'translateY(-50%) rotate(180deg)';
    else arrow.style.transform = 'translateY(-50%)';
    layer.appendChild(arrow);
  }

  // ------------------------------ settings ----------------------------------
  _wireSettings() {
    const g = this.game;
    const saved = JSON.parse(localStorage.getItem('hotu_settings') || '{}');
    g.settings = {
      sensitivity: saved.sensitivity ?? 1,
      master: saved.master ?? 0.8,
      music: saved.music ?? 0.5,
      sfx: saved.sfx ?? 0.9,
      reducedFlash: saved.reducedFlash ?? false,
    };
    $('set-sensitivity').value = g.settings.sensitivity;
    $('set-master').value = g.settings.master;
    $('set-music').value = g.settings.music;
    $('set-sfx').value = g.settings.sfx;
    $('set-reduced-flash').checked = g.settings.reducedFlash;

    const apply = () => {
      g.settings.sensitivity = parseFloat($('set-sensitivity').value);
      g.settings.master = parseFloat($('set-master').value);
      g.settings.music = parseFloat($('set-music').value);
      g.settings.sfx = parseFloat($('set-sfx').value);
      g.settings.reducedFlash = $('set-reduced-flash').checked;
      Audio.setVolumes(g.settings.master, g.settings.sfx, g.settings.music);
      localStorage.setItem('hotu_settings', JSON.stringify(g.settings));
    };
    for (const id of ['set-sensitivity', 'set-master', 'set-music', 'set-sfx', 'set-reduced-flash']) {
      $(id).addEventListener('input', apply);
    }
    apply();
  }

  // ----------------------------- high score ---------------------------------
  loadHighscore() {
    try { return JSON.parse(localStorage.getItem(HS_KEY) || 'null') || { bestRound: 0, bestChips: 0, wins: 0, runs: 0 }; }
    catch { return { bestRound: 0, bestChips: 0, wins: 0, runs: 0 }; }
  }

  saveRunResult(won, round, chips, kills) {
    const hs = this.loadHighscore();
    hs.runs += 1;
    if (won) hs.wins += 1;
    hs.bestRound = Math.max(hs.bestRound, round);
    hs.bestChips = Math.max(hs.bestChips, chips);
    hs.totalKills = (hs.totalKills || 0) + kills;
    try { localStorage.setItem(HS_KEY, JSON.stringify(hs)); } catch { /* private mode */ }
    this.renderHighscore();
  }

  renderHighscore() {
    const hs = this.loadHighscore();
    $('highscore-display').textContent = hs.runs
      ? `BEST: Round ${hs.bestRound} · ${hs.bestChips} chips · ${hs.wins} win${hs.wins === 1 ? '' : 's'} in ${hs.runs} runs`
      : 'No runs yet. The house is waiting.';
  }

  // ------------------------------ summary -----------------------------------
  showSummary(won, cause) {
    const g = this.game;
    $('summary-title').textContent = won ? 'YOU BEAT THE HOUSE' : 'THE HOUSE WINS';
    $('summary-title').className = won ? 'gold' : 'red';
    $('summary-cause').textContent = cause;
    $('summary-stats').innerHTML = `
      <div>Rounds survived: <b>${g.round}</b> / ${CONFIG.rounds}</div>
      <div>Zombies destroyed: <b>${g.stats.kills}</b></div>
      <div>Headshots: <b>${g.stats.headshots}</b></div>
      <div>Best combo: <b>x${g.stats.bestCombo}</b></div>
      <div>Chips at the end: <b>${g.chips}</b></div>
      <div>Chips gambled: <b>${g.stats.gambled}</b> · Wagers won: <b>${g.stats.wagersWon}</b></div>
      <div class="gold vault-line">🏦 Vault deposit: <b>+${(() => {
        const rate = Math.min(0.5, 0.2 + 0.02 * g.round + (won ? 0.1 : 0));
        const dep = Math.round(g.chips * rate);
        g.vault.deposit(dep);
        g.clearSave();
        this._lastDeposit = { dep, rate };
        return dep;
      })()}</b> chips (${Math.round(this._lastDeposit.rate * 100)}% cut) — vault holds ${g.vault.banked}</div>`;
    if (g.mode === 'daily') {
      const score = g.dailyScore();
      $('summary-stats').innerHTML += `<div class="cyan">⚡ DAILY SCORE: <b>${score}</b> — new seed at midnight</div>`;
      g._endDailyMode(score);
    }
    this.saveRunResult(won, g.round, g.chips, g.stats.kills);
    g._refreshMenu();
    this.hideAllPanels();
    this.show('summary-panel');
  }
}
