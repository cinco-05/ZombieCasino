// bosses.js — THE PIT BOSS (round 5 miniboss: charger with a slam) and
// THE HOUSE DEALER (round 10 final boss: teleports, deals razor-card fans,
// opens a glowing vulnerability window after each volley, phases at 66/33%).

import * as THREE from 'three';
import { CONFIG, clamp, rand, pick } from './config.js';
import { Audio } from './audio.js';
import { ARENA_HALF } from './arena.js';

class BossBase {
  constructor(game, name, hp) {
    this.game = game;
    this.name = name;
    this.maxHp = this.hp = hp;
    this.dead = false;
    this.parts = [];
    this.hitFlash = 0;
    this.def = { name, scale: 2 };
  }

  takeDamage(dmg, strong, point) {
    if (this.dead) return;
    if (this.vulnT > 0) dmg *= 2;           // dealer's open window
    this.hp -= dmg;
    this.hitFlash = 0.08;
    if (point) this.game.ui.floatText(point, Math.round(dmg), strong ? 'dmg crit' : 'dmg');
    this.game.ui.updateHUD();
    if (this.hp <= 0) this._die();
  }

  knockback() { /* bosses don't budge */ }

  _flash(mat) {
    if (this.hitFlash > 0) {
      this.hitFlash -= this.game.dt;
      mat.emissive.set(0xffffff);
      mat.emissiveIntensity = 0.7;
    }
  }
}

// ============================== THE PIT BOSS =================================
export class PitBoss extends BossBase {
  constructor(game) {
    super(game, 'THE PIT BOSS',
      1400 * (1 + 0.1 * (game.round - CONFIG.minibossRound))
           * (1 + 0.10 * Math.min(5, game.grudge?.pitboss || 0)));   // grudge: +10%/death, cap 5
    this.kind = 'pitboss';
    if ((game.grudge?.pitboss || 0) > 0) {
      setTimeout(() => game.ui.prompt('"YOU AGAIN. STILL IN DEBT."', 2600), 2400);
    }
    this.state = 'chase';
    this.stateT = 0;
    this.chargeDir = new THREE.Vector3();
    this.summonT = 8;
    this.vulnT = 0;
    this._build();
    game.ui.banner('THE PIT BOSS HAS ENTERED THE FLOOR', 'red', 2600);
    Audio.play('boss_phase');
  }

  _build() {
    this.mesh = new THREE.Group();
    this.bodyMat = new THREE.MeshStandardMaterial({ color: 0x7a1f1f, roughness: 0.7 });
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(1.0, 1.6, 4, 10), this.bodyMat);
    body.position.y = 2.0;
    body.userData = { ref: this, isHead: false };
    this.headMat = new THREE.MeshStandardMaterial({ color: 0xd9b38c, roughness: 0.8 });
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.8, 0.8), this.headMat);
    head.position.y = 3.6;
    head.userData = { ref: this, isHead: true };
    const hat = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.5, 12),
      new THREE.MeshStandardMaterial({ color: 0x111111 }));
    hat.position.y = 4.2;
    this.parts = [body, head];
    this.mesh.add(body, head, hat);
    this.mesh.position.set(0, 0, -ARENA_HALF + 4);
    this.game.scene.add(this.mesh);
  }

  update(dt) {
    if (this.dead) return;
    const g = this.game;
    this.game.dt = dt;
    this._flash(this.bodyMat);
    if (this.hitFlash <= 0) { this.bodyMat.emissive.set(0x000000); this.bodyMat.emissiveIntensity = 0; }

    const toPlayer = g.player.pos.clone().sub(this.mesh.position); toPlayer.y = 0;
    const dist = toPlayer.length();
    toPlayer.normalize();
    this.mesh.rotation.y = Math.atan2(toPlayer.x, toPlayer.z);
    this.stateT -= dt;

    // periodic summons
    this.summonT -= dt;
    if (this.summonT <= 0) {
      this.summonT = 11;
      g.enemies.spawnQueue.push({ kind: 'walker' }, { kind: 'sprinter' });
      g.ui.prompt('THE PIT BOSS CALLS FOR BACKUP');
    }

    switch (this.state) {
      case 'chase':
        this.mesh.position.add(toPlayer.clone().multiplyScalar(2.2 * dt));
        if (dist < 3 && this.stateT <= 0) { this.state = 'slamWind'; this.stateT = 0.7; this.bodyMat.color.set(0xff5555); g.audioAt('warn', this.mesh.position); }
        else if (dist > 8 && this.stateT <= 0) { this.state = 'chargeWind'; this.stateT = 0.8; this.chargeDir.copy(toPlayer); this.bodyMat.color.set(0xffaa33); g.audioAt('warn', this.mesh.position); }
        break;
      case 'chargeWind':
        if (this.stateT <= 0) { this.state = 'charge'; this.stateT = 1.0; }
        break;
      case 'charge':
        this.mesh.position.add(this.chargeDir.clone().multiplyScalar(14 * dt));
        if (g.player.pos.distanceTo(this.mesh.position) < 2.4) {
          g.player.takeDamage(28, this);
          g.addShake(0.2);
          this.stateT = 0;
        }
        if (this.stateT <= 0 || Math.abs(this.mesh.position.x) > ARENA_HALF - 1.5
            || Math.abs(this.mesh.position.z) > ARENA_HALF - 1.5) {
          this.state = 'chase'; this.stateT = 1.5; this.bodyMat.color.set(0x7a1f1f);
        }
        break;
      case 'slamWind':
        if (this.stateT <= 0) {
          this.state = 'chase'; this.stateT = 1.2; this.bodyMat.color.set(0x7a1f1f);
          g.audioAt('explosion', this.mesh.position);
          g.addShake(0.28);
          g.effects.spawnBurst(this.mesh.position.clone().setY(0.5), 0xff7a4a, 12, 6);
          if (g.player.pos.distanceTo(this.mesh.position) < 5 && g.player.onGround) {
            g.player.takeDamage(24, this);
          }
        }
        break;
    }
    g.arena.collide(this.mesh.position, 1.4);
  }

  _die() {
    this.dead = true;
    const g = this.game;
    g.scene.remove(this.mesh);
    g.onBossDefeated(this.kind);
  }
}

// ============================ THE HOUSE DEALER ===============================
export class HouseDealer extends BossBase {
  constructor(game) {
    super(game, 'THE HOUSE DEALER',
      3200 * (1 + 0.12 * Math.max(0, game.round - CONFIG.finalRound))   // endless scaling
           * (1 + 0.10 * Math.min(5, game.grudge?.housedealer || 0)));  // grudge
    this.kind = 'housedealer';
    if ((game.grudge?.housedealer || 0) > 0) {
      setTimeout(() => game.ui.prompt('"BACK FOR ANOTHER HAND? HOW PREDICTABLE."', 2600), 2400);
    }
    this.phase = 1;
    this.teleT = 4;
    this.volleyT = 2.5;
    this.vulnT = 0;
    this.orbitT = 0;
    this._build();
    game.arena.setRedAlert(true);
    game.ui.banner('THE HOUSE DEALER: "FINAL HAND."', 'red', 3000);
    Audio.play('boss_phase');
    Audio.setBossMode(true);
  }

  _build() {
    this.mesh = new THREE.Group();
    this.bodyMat = new THREE.MeshStandardMaterial({ color: 0x1a1a2a, roughness: 0.5, metalness: 0.3 });
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.8, 1.8, 4, 10), this.bodyMat);
    body.position.y = 2.1;
    body.userData = { ref: this, isHead: false };
    this.headMat = new THREE.MeshStandardMaterial({ color: 0xf5f5f5, roughness: 0.6 });
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.45, 12, 12), this.headMat);
    head.position.y = 3.5;
    head.userData = { ref: this, isHead: true };
    // floating card halo
    this.halo = new THREE.Group();
    for (let i = 0; i < 8; i++) {
      const card = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.6),
        new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide }));
      const a = (i / 8) * Math.PI * 2;
      card.position.set(Math.cos(a) * 1.6, 3.2, Math.sin(a) * 1.6);
      card.rotation.y = -a;
      this.halo.add(card);
    }
    this.parts = [body, head];
    this.mesh.add(body, head, this.halo);
    this.mesh.position.set(0, 0, -10);
    this.game.scene.add(this.mesh);
  }

  _teleport() {
    const g = this.game;
    g.audioAt('card', this.mesh.position);
    const spots = [[-22, -22], [22, -22], [-22, 18], [22, 18], [0, -26], [0, 6], [-26, 0], [26, 0]];
    const [x, z] = pick(spots);
    this.mesh.position.set(x, 0, z);
  }

  _volley() {
    const g = this.game;
    g.audioAt('warn', this.mesh.position);
    const n = this.phase === 3 ? 14 : this.phase === 2 ? 10 : 7;
    const spread = 0.5;
    const base = g.player.pos.clone().sub(this.mesh.position).setY(0).normalize();
    for (let i = 0; i < n; i++) {
      const a = (i - (n - 1) / 2) * (spread / n * 2.2);
      const dir = base.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), a);
      dir.y = 0.02;
      g.enemies.spawnProjectile(
        this.mesh.position.clone().add(new THREE.Vector3(0, 2.6, 0)),
        dir.multiplyScalar(this.phase === 3 ? 13 : 10), 14, 0xffffff, this);
    }
    // after dealing, the dealer's head glows — 2x damage window
    this.vulnT = 2.2;
    this.game.ui.prompt('THE DEALER IS OPEN — HIT THE HEAD!', 1800);
  }

  update(dt) {
    if (this.dead) return;
    const g = this.game;
    this.game.dt = dt;
    this.orbitT += dt;
    this.halo.rotation.y += dt * (this.phase * 0.8);
    this._flash(this.bodyMat);
    if (this.hitFlash <= 0) { this.bodyMat.emissive.set(0x000000); this.bodyMat.emissiveIntensity = 0; }

    // phase transitions at 66% / 33%
    const frac = this.hp / this.maxHp;
    if (this.phase === 1 && frac < 0.66) this._phaseUp(2);
    if (this.phase === 2 && frac < 0.33) this._phaseUp(3);

    const toPlayer = g.player.pos.clone().sub(this.mesh.position); toPlayer.y = 0;
    this.mesh.rotation.y = Math.atan2(toPlayer.x, toPlayer.z);

    // drift slowly, teleport on a timer
    this.mesh.position.add(toPlayer.normalize().multiplyScalar(1.2 * dt));
    this.teleT -= dt;
    if (this.teleT <= 0) {
      this.teleT = this.phase === 3 ? 4.5 : 6.5;
      this._teleport();
    }

    this.volleyT -= dt;
    if (this.volleyT <= 0) {
      this.volleyT = this.phase === 3 ? 2.2 : this.phase === 2 ? 3.0 : 3.8;
      this._volley();
    }

    if (this.vulnT > 0) {
      this.vulnT -= dt;
      this.headMat.emissive = new THREE.Color(0xffd24a);
      this.headMat.emissiveIntensity = 2 + (g.settings.reducedFlash ? 0 : Math.sin(this.orbitT * 10));
    } else {
      this.headMat.emissive = new THREE.Color(0x000000);
      this.headMat.emissiveIntensity = 0;
    }
    g.arena.collide(this.mesh.position, 1.2);
  }

  _phaseUp(n) {
    this.phase = n;
    const g = this.game;
    Audio.play('boss_phase');
    g.ui.banner(n === 2 ? 'THE DEALER RESHUFFLES — PHASE 2' : 'FINAL PHASE — ALL BETS ARE OFF', 'red', 2400);
    g.enemies.spawnQueue.push({ kind: 'sprinter' }, { kind: 'sprinter' },
      n === 3 ? { kind: 'gasbag' } : { kind: 'walker' });
  }

  _die() {
    this.dead = true;
    const g = this.game;
    g.scene.remove(this.mesh);
    g.arena.setRedAlert(false);
    Audio.setBossMode(false);
    g.onBossDefeated(this.kind);
  }
}
