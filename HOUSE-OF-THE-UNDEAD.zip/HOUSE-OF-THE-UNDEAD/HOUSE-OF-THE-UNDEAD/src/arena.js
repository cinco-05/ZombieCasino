// arena.js — the casino floor, now dressed like a real one: loud patterned
// carpet, wainscoted walls, a ceiling with a bulb grid and a chandelier,
// modeled slot machines with glowing screens and marquee bulbs, felt card
// tables with chip stacks, neon text signage, and slow orbiting colored
// lights. Reduced-flash setting keeps every animated light steady.

import * as THREE from 'three';
import { clamp } from './config.js';

export const ARENA_HALF = 34;   // bigger floor — was 24

// ------------------------- canvas texture helpers ---------------------------
function canvasTex(w, h, draw, repeatX = 1, repeatY = 1) {
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  draw(cv.getContext('2d'), w, h);
  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/** classic obnoxious casino carpet: purple base, gold diamonds, teal swirls */
function carpetTexture() {
  return canvasTex(256, 256, (c, w, h) => {
    c.fillStyle = '#241238';
    c.fillRect(0, 0, w, h);
    // gold diamond lattice
    c.strokeStyle = '#c9a227';
    c.lineWidth = 3;
    for (const off of [0, 128]) {
      c.beginPath();
      c.moveTo(64 + off - 128, 0); c.lineTo(192 + off - 128, 128); c.lineTo(64 + off - 128, 256); c.lineTo(-64 + off - 128 + 256, 128);
      c.closePath(); c.stroke();
    }
    // teal dots + red paisley commas
    for (let i = 0; i < 24; i++) {
      const x = (i * 97) % 256, y = (i * 53) % 256;
      c.fillStyle = i % 3 ? '#1f8f8f' : '#8f1f3f';
      c.beginPath(); c.arc(x, y, i % 3 ? 5 : 8, 0, Math.PI * 2); c.fill();
    }
    // card suits at the diamond centers
    c.font = 'bold 28px serif';
    c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillStyle = '#e8506a'; c.fillText('♥', 64, 64); c.fillText('♦', 192, 192);
    c.fillStyle = '#3fd0ff'; c.fillText('♠', 192, 64); c.fillText('♣', 64, 192);
  }, 10, 10);
}

/** glowing neon sign with text */
function neonSignTexture(text, color) {
  return canvasTex(512, 128, (c, w, h) => {
    c.clearRect(0, 0, w, h);
    c.font = 'bold 72px "Courier New", monospace';
    c.textAlign = 'center'; c.textBaseline = 'middle';
    c.shadowColor = color; c.shadowBlur = 26;
    c.strokeStyle = color; c.lineWidth = 4;
    c.strokeText(text, w / 2, h / 2);
    c.shadowBlur = 8;
    c.fillStyle = '#ffffff';
    c.fillText(text, w / 2, h / 2);
  });
}

/** slot machine screen with three symbols */
function slotScreenTexture(syms, glow) {
  return canvasTex(128, 64, (c, w, h) => {
    c.fillStyle = '#08060f'; c.fillRect(0, 0, w, h);
    c.font = '36px serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.shadowColor = glow; c.shadowBlur = 10;
    syms.forEach((s, i) => c.fillText(s, 24 + i * 40, h / 2 + 2));
  });
}

/** roulette wheel top for the center dais */
function rouletteTexture() {
  return canvasTex(256, 256, (c, w, h) => {
    const cx = w / 2, cy = h / 2;
    for (let i = 0; i < 37; i++) {
      const a0 = (i / 37) * Math.PI * 2, a1 = ((i + 1) / 37) * Math.PI * 2;
      c.beginPath(); c.moveTo(cx, cy); c.arc(cx, cy, 120, a0, a1);
      c.fillStyle = i === 0 ? '#0f7a3d' : i % 2 ? '#b3122e' : '#15151d';
      c.fill();
    }
    c.beginPath(); c.arc(cx, cy, 34, 0, Math.PI * 2); c.fillStyle = '#c9a227'; c.fill();
    c.beginPath(); c.arc(cx, cy, 122, 0, Math.PI * 2); c.lineWidth = 6; c.strokeStyle = '#c9a227'; c.stroke();
  });
}

export class Arena {
  constructor(game) {
    this.game = game;
    this.group = new THREE.Group();
    this.colliders = [];
    this.redAlert = false;
    this.lowLight = false;
    this.pulseT = 0;
    this.marqueeBulbs = [];   // animated color-cycling bulbs
    this.flickerNeons = [];   // signs that occasionally flicker
    this.discoLights = [];    // orbiting colored point lights
    this._build();
    game.scene.add(this.group);
  }

  _mat(color, emissive = 0x000000, intensity = 1, extra = {}) {
    return new THREE.MeshStandardMaterial({ color, emissive, emissiveIntensity: intensity, roughness: 0.8, ...extra });
  }

  _build() {
    const g = this.group;
    const GOLD = 0xc9a227;

    // ------------------------------- floor ----------------------------------
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(ARENA_HALF * 2 + 4, ARENA_HALF * 2 + 4),
      new THREE.MeshStandardMaterial({ map: carpetTexture(), roughness: 0.95 }));
    floor.rotation.x = -Math.PI / 2;
    g.add(floor);

    // gold walkway ring
    const ring = new THREE.Mesh(new THREE.RingGeometry(7.5, 8.2, 48),
      new THREE.MeshStandardMaterial({ color: GOLD, emissive: GOLD, emissiveIntensity: 0.25, side: THREE.DoubleSide, metalness: 0.6, roughness: 0.4 }));
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.02;
    g.add(ring);

    // ------------------------------- walls -----------------------------------
    const H = 7, L = ARENA_HALF * 2 + 4;
    const wallMat = this._mat(0x3a1020);                       // deep casino red
    const wainscotMat = this._mat(0x1a0d14, 0, 1, { roughness: 0.5, metalness: 0.2 });
    const trimMat = this._mat(GOLD, GOLD, 0.2, { metalness: 0.8, roughness: 0.3 });
    for (const [x, z, ry] of [[0, -ARENA_HALF - 2, 0], [0, ARENA_HALF + 2, 0],
                              [-ARENA_HALF - 2, 0, Math.PI / 2], [ARENA_HALF + 2, 0, Math.PI / 2]]) {
      const w = new THREE.Mesh(new THREE.BoxGeometry(L, H, 0.6), wallMat);
      w.position.set(x, H / 2, z); w.rotation.y = ry; g.add(w);
      const wains = new THREE.Mesh(new THREE.BoxGeometry(L, 1.4, 0.7), wainscotMat);
      wains.position.set(x, 0.7, z); wains.rotation.y = ry; g.add(wains);
      const trim = new THREE.Mesh(new THREE.BoxGeometry(L, 0.12, 0.72), trimMat);
      trim.position.set(x, 1.45, z); trim.rotation.y = ry; g.add(trim);
    }

    // corner columns with gold caps
    for (const [x, z] of [[-ARENA_HALF - 1, -ARENA_HALF - 1], [ARENA_HALF + 1, -ARENA_HALF - 1],
                          [-ARENA_HALF - 1, ARENA_HALF + 1], [ARENA_HALF + 1, ARENA_HALF + 1]]) {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.0, H, 12), wainscotMat);
      col.position.set(x, H / 2, z); g.add(col);
      const cap = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 0.95, 0.4, 12), trimMat);
      cap.position.set(x, H - 0.2, z); g.add(cap);
    }

    // ------------------------------ ceiling ----------------------------------
    const ceil = new THREE.Mesh(new THREE.PlaneGeometry(L, L), this._mat(0x120a18));
    ceil.rotation.x = Math.PI / 2;
    ceil.position.y = H;
    g.add(ceil);

    // grid of warm ceiling bulbs (emissive only — cheap)
    const bulbGeo = new THREE.SphereGeometry(0.12, 6, 6);
    for (let bx = -30; bx <= 30; bx += 10) {
      for (let bz = -30; bz <= 30; bz += 10) {
        const bulbMat = new THREE.MeshBasicMaterial({ color: 0xffd9a0 });
        const b = new THREE.Mesh(bulbGeo, bulbMat);
        b.position.set(bx, H - 0.15, bz);
        g.add(b);
      }
    }

    // chandelier over the dais: gold rings + candle bulbs + real light
    const chand = new THREE.Group();
    for (const [r, y] of [[1.6, 0], [1.1, 0.5], [0.6, 1.0]]) {
      const torus = new THREE.Mesh(new THREE.TorusGeometry(r, 0.07, 8, 24), trimMat);
      torus.rotation.x = Math.PI / 2; torus.position.y = y;
      chand.add(torus);
      const n = Math.round(r * 6);
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        const cb = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 6),
          new THREE.MeshBasicMaterial({ color: 0xffe9b0 }));
        cb.position.set(Math.cos(a) * r, y + 0.18, Math.sin(a) * r);
        chand.add(cb);
      }
    }
    chand.position.set(0, H - 1.6, -4);
    g.add(chand);
    this.chandLight = new THREE.PointLight(0xffd9a0, 50, 26);
    this.chandLight.position.set(0, H - 2.2, -4);
    g.add(this.chandLight);

    // ---------------------------- neon signage -------------------------------
    const addSign = (text, color, x, y, z, ry = 0, scale = 1) => {
      const tex = neonSignTexture(text, color);
      const m = new THREE.Mesh(new THREE.PlaneGeometry(8 * scale, 2 * scale),
        new THREE.MeshBasicMaterial({ map: tex, transparent: true }));
      m.position.set(x, y, z); m.rotation.y = ry;
      this.group.add(m);
      this.flickerNeons.push(m);
      return m;
    };
    addSign('HOUSE OF THE UNDEAD', '#ff2d78', 0, 5.2, -ARENA_HALF - 1.6, 0, 1.6);
    addSign('★ SLOTS ★', '#27e6ff', -20, 4.2, -ARENA_HALF - 1.6, 0, 1);
    addSign('JACKPOT', '#ffd24a', 20, 4.2, -ARENA_HALF - 1.6, 0, 1);
    addSign('TABLES', '#2dff7a', -ARENA_HALF - 1.6, 4.2, 0, Math.PI / 2, 1.1);
    addSign('LIVE TONIGHT', '#ff7ad0', -ARENA_HALF - 1.6, 4.2, -18, Math.PI / 2, 0.9);
    addSign('21', '#ff4a4a', ARENA_HALF + 1.6, 4.2, -10, -Math.PI / 2, 0.9);
    addSign('★ LUCKY ★', '#c27aff', ARENA_HALF + 1.6, 4.2, 12, -Math.PI / 2, 1);
    addSign('CASHIER', '#ffb04a', 0, 4.6, ARENA_HALF + 1.6, Math.PI, 1.1);
    addSign('BAR', '#ffb04a', -24, 4.2, ARENA_HALF + 1.6, Math.PI, 0.8);

    // --------------------------- slot machine banks --------------------------
    const SLOT_COLORS = [0xff2d78, 0x27e6ff, 0x2dff7a, 0x8a2dff, 0xffd24a, 0xff7a4a];
    const SYMS = [['🍒', '7', '🔔'], ['7', '7', '♥'], ['🔔', '💀', '🍒'], ['♥', '7', '7'], ['7', '🍒', '7'], ['💀', '🔔', '♥']];
    const bankPositions = [[-18, -10], [18, -10], [-18, 14], [18, 14], [-8, -22], [8, -22]];
    this.bankPositions = bankPositions;
    bankPositions.forEach(([x, z], bi) => {
      const glow = SLOT_COLORS[bi % SLOT_COLORS.length];
      const bank = new THREE.Group();
      for (let i = -1; i <= 1; i++) {
        const m = new THREE.Group();
        // cabinet
        const body = new THREE.Mesh(new THREE.BoxGeometry(1.3, 2.0, 1.1),
          this._mat(0x241a30, 0, 1, { roughness: 0.4, metalness: 0.3 }));
        body.position.y = 1.0;
        // glowing screen
        const screen = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.55),
          new THREE.MeshBasicMaterial({ map: slotScreenTexture(SYMS[(bi + i + SYMS.length) % SYMS.length], '#' + glow.toString(16).padStart(6, '0')) }));
        screen.position.set(0, 1.35, 0.56);
        // colored top light
        const top = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 0.3, 8),
          new THREE.MeshBasicMaterial({ color: glow }));
        top.position.y = 2.15;
        // arm lever
        const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.7, 6),
          this._mat(0x999999, 0, 1, { metalness: 0.9, roughness: 0.2 }));
        arm.position.set(0.72, 1.5, 0); arm.rotation.z = -0.4;
        const knob = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8),
          new THREE.MeshBasicMaterial({ color: 0xff3333 }));
        knob.position.set(0.85, 1.82, 0);
        m.add(body, screen, top, arm, knob);
        m.position.x = i * 1.55;
        bank.add(m);
      }
      // marquee bulb strip along the top of the bank
      for (let bxi = 0; bxi <= 10; bxi++) {
        const bm = new THREE.MeshBasicMaterial({ color: glow });
        const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 6), bm);
        bulb.position.set(-2.4 + bxi * 0.48, 2.35, 0.5);
        bank.add(bulb);
        this.marqueeBulbs.push({ mat: bm, base: new THREE.Color(glow), phase: bxi * 0.6 + bi });
      }
      bank.position.set(x, 0, z);
      g.add(bank);
      this.colliders.push({ x, z, r: 3.1 });
      // a soft colored light per bank
      const pl = new THREE.PointLight(glow, 26, 16);
      pl.position.set(x, 3.2, z);
      g.add(pl);
    });

    // ----------------------------- card tables -------------------------------
    const feltMat = this._mat(0x145a32, 0, 1, { roughness: 0.95 });
    const addTable = (x, z) => {
      const t = new THREE.Group();
      const top = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 0.14, 20), feltMat);
      top.position.y = 0.95;
      const rim = new THREE.Mesh(new THREE.TorusGeometry(1.5, 0.09, 8, 24), trimMat);
      rim.rotation.x = Math.PI / 2; rim.position.y = 1.0;
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.34, 0.95, 10), wainscotMat);
      leg.position.y = 0.48;
      t.add(top, rim, leg);
      // chip stacks + scattered cards on the felt
      const chipColors = [0xe84a5f, 0x3fd0ff, 0xf5f0e0, 0xc9a227];
      for (let i = 0; i < 4; i++) {
        const a = i * 1.7 + x;   // deterministic-ish scatter
        const stack = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.05 + (i % 3) * 0.06, 10),
          this._mat(chipColors[i % 4], chipColors[i % 4], 0.15));
        stack.position.set(Math.cos(a) * 0.8, 1.06, Math.sin(a) * 0.8);
        t.add(stack);
        const card = new THREE.Mesh(new THREE.PlaneGeometry(0.24, 0.34),
          new THREE.MeshBasicMaterial({ color: 0xf5f0e0 }));
        card.rotation.x = -Math.PI / 2; card.rotation.z = a;
        card.position.set(Math.cos(a + 1) * 0.5, 1.03, Math.sin(a + 1) * 0.5);
        t.add(card);
      }
      t.position.set(x, 0, z);
      g.add(t);
      this.colliders.push({ x, z, r: 1.9 });
      // pendant lamp over each table
      const shade = new THREE.Mesh(new THREE.ConeGeometry(0.45, 0.4, 12, 1, true),
        this._mat(0x0d3b24, 0x2dff7a, 0.3, { side: THREE.DoubleSide }));
      shade.position.set(x, 3.4, z);
      g.add(shade);
      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.1, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0xfff2c0 }));
      bulb.position.set(x, 3.28, z);
      g.add(bulb);
    };
    addTable(-9, 2);
    addTable(9, 2);
    addTable(0, -16);
    addTable(-24, -4);
    addTable(24, -4);

    // ------------------------ center dais: giant roulette --------------------
    const dais = new THREE.Mesh(new THREE.CylinderGeometry(2.4, 2.6, 0.9, 24),
      this._mat(0x3a2a10, GOLD, 0.15, { metalness: 0.4 }));
    dais.position.set(0, 0.45, -4);
    g.add(dais);
    this.wheel = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 0.1, 37),
      new THREE.MeshStandardMaterial({ map: rouletteTexture(), roughness: 0.5 }));
    this.wheel.position.set(0, 0.96, -4);
    g.add(this.wheel);
    this.colliders.push({ x: 0, z: -4, r: 2.8 });

    // ------------------------------ bar corner -------------------------------
    const bar = new THREE.Mesh(new THREE.BoxGeometry(9, 1.2, 1.4),
      this._mat(0x2a1a0a, 0, 1, { roughness: 0.3, metalness: 0.2 }));
    bar.position.set(-24, 0.6, 26);
    g.add(bar);
    this.colliders.push({ x: -24, z: 26, r: 5 });
    const shelf = new THREE.Mesh(new THREE.BoxGeometry(9, 0.12, 0.5), trimMat);
    shelf.position.set(-24, 2.4, 30);
    g.add(shelf);
    const bottleColors = [0x27e6ff, 0xff2d78, 0x2dff7a, 0xffd24a, 0xc27aff, 0xff7a4a, 0x3fd0ff];
    bottleColors.forEach((bc, i) => {
      const bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 0.55, 8),
        new THREE.MeshStandardMaterial({ color: bc, emissive: bc, emissiveIntensity: 0.8, transparent: true, opacity: 0.85 }));
      bottle.position.set(-27.4 + i * 1.1, 2.75, 30);
      g.add(bottle);
    });
    const barLight = new THREE.PointLight(0xffb04a, 18, 14);
    barLight.position.set(-24, 3.4, 27);
    g.add(barLight);

    // ---------------------- the stage (new wing) -----------------------------
    // raised platform with velvet curtain, mic stand, and sweeping spotlights
    const stage = new THREE.Mesh(new THREE.BoxGeometry(14, 1.1, 6),
      this._mat(0x1a0d14, 0, 1, { roughness: 0.5 }));
    stage.position.set(20, 0.55, 27);
    g.add(stage);
    this.colliders.push({ x: 20, z: 27, r: 7.5 });
    const stageTrim = new THREE.Mesh(new THREE.BoxGeometry(14.3, 0.15, 6.3), trimMat);
    stageTrim.position.set(20, 1.12, 27);
    g.add(stageTrim);
    const curtain = new THREE.Mesh(new THREE.BoxGeometry(14, 5.5, 0.5),
      this._mat(0x5a0f1f, 0x5a0f1f, 0.12, { roughness: 0.95 }));
    curtain.position.set(20, 3.9, 30.4);
    g.add(curtain);
    for (let i = 0; i < 8; i++) {   // curtain folds
      const fold = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.4, 5.5, 8),
        this._mat(0x6d1426, 0, 1, { roughness: 0.95 }));
      fold.position.set(13.8 + i * 1.8, 3.9, 30.1);
      g.add(fold);
    }
    const micStand = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.6, 6),
      this._mat(0x777777, 0, 1, { metalness: 0.9 }));
    micStand.position.set(20, 1.9, 26.5);
    g.add(micStand);
    const mic = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8),
      this._mat(0x222222, 0, 1, { metalness: 0.7 }));
    mic.position.set(20, 2.75, 26.5);
    g.add(mic);
    // stage spotlights
    for (const [sx, color] of [[15, 0xff7ad0], [25, 0x27e6ff]]) {
      const spot = new THREE.PointLight(color, 30, 18);
      spot.position.set(sx, 6, 25);
      g.add(spot);
    }

    // ------------------- fountain of dubious liquid (new) --------------------
    const basin = new THREE.Mesh(new THREE.CylinderGeometry(3, 3.3, 0.8, 20),
      this._mat(0x2a2438, 0, 1, { roughness: 0.4 }));
    basin.position.set(0, 0.4, 14);
    g.add(basin);
    this.colliders.push({ x: 0, z: 14, r: 3.6 });
    this.fountainWater = new THREE.Mesh(new THREE.CylinderGeometry(2.7, 2.7, 0.1, 20),
      new THREE.MeshStandardMaterial({ color: 0x27e6ff, emissive: 0x27e6ff, emissiveIntensity: 0.5, transparent: true, opacity: 0.75 }));
    this.fountainWater.position.set(0, 0.82, 14);
    g.add(this.fountainWater);
    const spire = new THREE.Mesh(new THREE.ConeGeometry(0.5, 2.2, 10), trimMat);
    spire.position.set(0, 1.9, 14);
    g.add(spire);
    const fountainLight = new THREE.PointLight(0x27e6ff, 20, 12);
    fountainLight.position.set(0, 2.6, 14);
    g.add(fountainLight);

    // ------------------------------- lighting --------------------------------
    this.hemi = new THREE.HemisphereLight(0x9a86ff, 0x1a0e22, 0.75);
    g.add(this.hemi);
    this.points = [this.chandLight, barLight];

    // orbiting party lights (magenta / cyan / gold)
    for (const [color, phase] of [[0xff2d78, 0], [0x27e6ff, 2.1], [0xffd24a, 4.2]]) {
      const pl = new THREE.PointLight(color, 34, 24);
      pl.position.set(0, 5.4, 0);
      g.add(pl);
      this.discoLights.push({ light: pl, phase, baseColor: new THREE.Color(color) });
      this.points.push(pl);
    }

    this.game.scene.fog = new THREE.FogExp2(0x140a1e, 0.011);
    this.game.scene.background = new THREE.Color(0x140a1e);
  }

  /** does a straight line between two points pass through cover? (2D) */
  lineBlocked(a, b) {
    const ax = a.x, az = a.z, bx = b.x, bz = b.z;
    const dx = bx - ax, dz = bz - az;
    const len2 = dx * dx + dz * dz;
    if (len2 < 1) return false;
    for (const c of this.colliders) {
      // ignore cover we're standing right next to (it isn't between us)
      const da = Math.hypot(ax - c.x, az - c.z);
      const db = Math.hypot(bx - c.x, bz - c.z);
      if (da < c.r + 1.2 || db < c.r + 1.2) continue;
      const t = Math.max(0, Math.min(1, ((c.x - ax) * dx + (c.z - az) * dz) / len2));
      const px = ax + t * dx, pz = az + t * dz;
      if (Math.hypot(px - c.x, pz - c.z) < c.r * 0.85) return true;
    }
    return false;
  }

  // ------------------------------ collision ---------------------------------
  collide(pos, radius) {
    const lim = ARENA_HALF - radius;
    pos.x = clamp(pos.x, -lim, lim);
    pos.z = clamp(pos.z, -lim, lim);
    for (const c of this.colliders) {
      const dx = pos.x - c.x, dz = pos.z - c.z;
      const r = c.r + radius;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r && d2 > 1e-9) {
        const d = Math.sqrt(d2);
        pos.x = c.x + (dx / d) * r;
        pos.z = c.z + (dz / d) * r;
      }
    }
  }

  // ---------------------------- lighting states -----------------------------
  setLowLight(on) {
    this.lowLight = on;
    this.hemi.intensity = on ? 0.22 : 0.75;
    this.chandLight.intensity = on ? 14 : 50;
    for (const d of this.discoLights) d.light.intensity = on ? 12 : 34;
  }

  setRedAlert(on) {
    this.redAlert = on;
    if (!on) {
      this.hemi.color.set(0x9a86ff);
      this.setLowLight(this.lowLight);
      for (const d of this.discoLights) d.light.color.copy(d.baseColor);
    } else {
      this.hemi.color.set(0xff3333);
    }
  }

  // ------------------------------ animation ---------------------------------
  update(dt) {
    this.pulseT += dt;
    const t = this.pulseT;
    const rf = this.game.settings.reducedFlash;

    // a slot machine somewhere pays out for a ghost
    this.chimeT = (this.chimeT ?? 6) - dt;
    if (this.chimeT <= 0) {
      this.chimeT = 7 + Math.random() * 9;
      const banks = this.bankPositions;
      const [x, z] = banks[Math.floor(Math.random() * banks.length)];
      this.game.audioAt('ambient_chime', { x, y: 2, z }, 'ambient');
    }

    // roulette centerpiece slowly spins; fountain shimmers
    this.wheel.rotation.y += dt * 0.4;
    if (this.fountainWater) {
      this.fountainWater.material.emissiveIntensity = 0.4 + 0.15 * Math.sin(t * 2);
    }

    // orbiting party lights sweep the floor
    for (const d of this.discoLights) {
      const a = t * 0.35 + d.phase;
      d.light.position.set(Math.cos(a) * 18, 5.4, Math.sin(a) * 18);
    }

    // marquee bulbs chase (steady glow when reduced flashing is on)
    if (!rf) {
      for (const b of this.marqueeBulbs) {
        const k = 0.45 + 0.55 * Math.max(0, Math.sin(t * 4 + b.phase));
        b.mat.color.copy(b.base).multiplyScalar(k);
      }
      // rare neon flicker
      if (Math.random() < 0.004 && this.flickerNeons.length) {
        const sign = this.flickerNeons[Math.floor(Math.random() * this.flickerNeons.length)];
        sign.visible = false;
        setTimeout(() => { sign.visible = true; }, 60 + Math.random() * 90);
      }
    }

    if (this.redAlert) {
      const base = rf ? 25 : 20 + 14 * Math.sin(t * 3);
      for (const d of this.discoLights) { d.light.color.set(0xff2222); d.light.intensity = base; }
      this.chandLight.color.set(0xff5555);
    } else {
      this.chandLight.color.set(0xffd9a0);
    }
  }
}
