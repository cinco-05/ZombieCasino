// config.js — every tunable balance number in one place. If the game feels
// too easy or too hard, this is the file to edit.

export const CONFIG = {
  rounds: 10,
  minibossRound: 5,
  finalRound: 10,
  intermissionSeconds: 45,

  player: {
    hp: 100,
    speed: 6.2,
    sprintMult: 1.45,
    jumpVel: 7.5,
    gravity: 22,
    eyeHeight: 1.7,
    radius: 0.55,
    fov: 75,
    aimFov: 55,
    dashSpeed: 22,          // NEW: dash burst
    dashTime: 0.22,
    dashCooldown: 3.5,
    dashIFrames: 0.35,
    hurtIFrames: 0.35,
    armorAbsorb: 0.6,       // 60% of damage goes to armor first
  },

  melee: {                   // NEW: panic pistol-whip (F)
    damage: 45,
    range: 2.6,
    arcDot: 0.55,            // how forward-facing a target must be
    cooldown: 0.8,
    knockback: 9,
  },

  grenade: {                 // NEW: chip bombs (G)
    damage: 90,
    radius: 5.5,
    fuse: 1.4,
    throwSpeed: 16,
    start: 2,
    max: 5,
    price: 60,               // cashier price for +1
  },

  // balance pass v3: pistol buffed (starter should feel snappy), shotgun
  // buffed (harder slap, faster reload), smg per-shot nerf but faster + bigger
  // mag (same DPS, sprayier), rifle buffed hard (it's a legendary unlock).
  weapons: {
    pistol: {
      name: 'Lucky Seven', slot: 1, auto: false,
      damage: 38, fireRate: 4.2, mag: 12, reserve: 48, maxReserve: 120,
      reload: 1.25, spread: 0.011, pellets: 1, critChance: 0.10, zoomOk: true,
    },
    shotgun: {
      name: 'Riverboat Scattergun', slot: 2, auto: false,
      damage: 11, fireRate: 1.5, mag: 6, reserve: 24, maxReserve: 60,
      reload: 2.0, spread: 0.05, pellets: 8, critChance: 0.04, zoomOk: false,
    },
    smg: {
      name: 'Chip Spitter', slot: 3, auto: true,
      damage: 8, fireRate: 12.5, mag: 35, reserve: 105, maxReserve: 245,
      reload: 1.7, spread: 0.032, pellets: 1, critChance: 0.05, zoomOk: false,
    },
    rifle: {                 // 4th weapon, starts locked — legendary, hits like one
      name: 'Boneyard Special', slot: 4, auto: false, locked: true,
      damage: 70, fireRate: 1.8, mag: 8, reserve: 40, maxReserve: 96,
      reload: 2.0, spread: 0.003, pellets: 1, critChance: 0.22, zoomOk: true,
    },
  },
  critMult: 2.0,
  headshotMult: 2.0,

  enemies: {
    walker:   { hp: 55,  speed: 2.2, damage: 12, chips: [8, 14],  scale: 1.0 },
    sprinter: { hp: 32,  speed: 5.6, damage: 9,  chips: [10, 16], scale: 0.85 },
    brute:    { hp: 220, speed: 1.6, damage: 26, chips: [30, 45], scale: 1.45 },
    spitter:  { hp: 45,  speed: 2.6, damage: 14, chips: [14, 22], scale: 0.95,  // NEW ranged
                projSpeed: 12, attackRange: 14, attackCd: 2.4 },
    gasbag:   { hp: 70,  speed: 1.9, damage: 30, chips: [18, 28], scale: 1.15,  // NEW exploder
                blastRadius: 4.5 },
    pitguard: { hp: 160, speed: 2.4, damage: 20, chips: [25, 40], scale: 1.2,   // NEW armored
                bodyResist: 0.7 },  // body shots do 30% damage; head is normal + headshot mult
    collector:{ hp: 140, speed: 4.6, damage: 8,  chips: [60, 90], scale: 1.05,  // severe penalty hunter
                stealOnHit: 25 },
    croupier: { hp: 60,  speed: 2.8, damage: 11, chips: [16, 26], scale: 0.95,  // NEW: razor-card burst
                projSpeed: 14, attackRange: 13, attackCd: 3.0, burst: 3 },
    magician: { hp: 50,  speed: 2.4, damage: 15, chips: [20, 32], scale: 0.9,   // NEW: teleports at you
                blinkCd: 4.5 },
    jackpot:  { hp: 110, speed: 3.4, damage: 6,  chips: [130, 200], scale: 1.1, // NEW: golden bonus target,
                despawn: 20 },                                                  // flees, escapes if ignored
  },
  eliteMult: { hp: 2.2, speed: 1.25, chips: 3 },

  // round composition: counts scale off these
  spawn: {
    baseCount: 8,
    perRound: 3,
    maxAlive: 17,   // bigger floor holds a bigger crowd
    hpScalePerRound: 0.14,
    dmgScalePerRound: 0.06,
  },

  chips: {
    roundClearBonus: 60,
    headshotBonus: 3,
    comboWindow: 3.5,        // NEW: killstreak combo
    comboMaxMult: 3.0,
    comboStep: 0.25,         // +25% chips per combo stage
  },

  shop: {
    smallHeal: { price: 50, amount: 35 },
    fullHeal: { price: 120 },
    ammo: { price: 75 },
    armor: { price: 100, amount: 50 },
    grenade: { price: 60 },
    rifleUnlock: { price: 450 },   // alternative path to the new gun
  },

  // choose-your-stake wagers: bet ANY amount from minBet to everything.
  // Reward tier is earned by risk — both an absolute floor and a fraction of
  // your bankroll, so the rich can't buy legendaries with pocket change and
  // the broke can't get them for 8 chips:
  //   COMMON    any stake >= minBet            (lose: mild penalty)
  //   RARE      >= 150 chips AND >= 40% of it  (lose: moderate)
  //   LEGENDARY >= 300 chips AND >= 85% of it  (lose: severe)
  wagers: {
    minBet: 50,
    rare:      { min: 150, frac: 0.40 },
    legendary: { min: 300, frac: 0.85 },
    houseCreditTier: 'common',
  },

  slots: { price: 60 },      // 5x5 machine, 7 paylines, runs of 3+ pay
  poker: { minAnte: 50 },    // five card draw — ante is your choice; hand rank
                             // sets the tier; a legendary-risk ante bumps it +1
};

// ------------------------------ tiny helpers --------------------------------
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const lerp = (a, b, t) => a + (b - a) * t;
export const rand = (a, b) => a + Math.random() * (b - a);
export const randInt = (a, b) => Math.floor(rand(a, b + 1));
export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
