// pickups.js — chip piles (magnetize to the player), ammo boxes, medkits.

import * as THREE from 'three';
import { CONFIG, rand } from './config.js';
import { Audio } from './audio.js';

export class Pickups {
  constructor(game) {
    this.game = game;
    this.list = [];
    this.chipGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.07, 12);
    this.chipMat = new THREE.MeshStandardMaterial({ color: 0xc9a227, emissive: 0xc9a227, emissiveIntensity: 0.5 });
    this.ammoMat = new THREE.MeshStandardMaterial({ color: 0x27e6ff, emissive: 0x27e6ff, emissiveIntensity: 0.4 });
    this.healMat = new THREE.MeshStandardMaterial({ color: 0xff2d55, emissive: 0xff2d55, emissiveIntensity: 0.5 });
  }

  spawnChips(pos, amount) {
    const m = new THREE.Mesh(this.chipGeo, this.chipMat);
    m.position.copy(pos); m.position.y = 0.4;
    this.game.scene.add(m);
    this.list.push({ kind: 'chips', mesh: m, amount, t: 20, vy: 3 });
  }

  spawnDrop(pos) {
    // rolls a chance for ammo / health, modified by penalties
    const healMult = this.game.casino.roundMods.healDropMult ?? 1;
    const r = Math.random();
    if (r < 0.10 * healMult) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.4, 0.4), this.healMat);
      m.position.copy(pos); m.position.y = 0.4;
      this.game.scene.add(m);
      this.list.push({ kind: 'heal', mesh: m, amount: 20, t: 15, vy: 3 });
    } else if (r < 0.22) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.3, 0.45), this.ammoMat);
      m.position.copy(pos); m.position.y = 0.35;
      this.game.scene.add(m);
      this.list.push({ kind: 'ammo', mesh: m, t: 15, vy: 3 });
    }
  }

  update(dt) {
    const g = this.game;
    const ppos = g.player.pos;
    for (let i = this.list.length - 1; i >= 0; i--) {
      const p = this.list[i];
      p.t -= dt;
      p.mesh.rotation.y += dt * 3;
      // little hop on spawn
      if (p.vy > 0) { p.mesh.position.y += p.vy * dt; p.vy -= 12 * dt; }
      const d = p.mesh.position.distanceTo(ppos);
      // chips magnetize
      const magnetR = 5 * g.playerMods.magnet;
      if (p.kind === 'chips' && d < magnetR) {
        p.mesh.position.lerp(ppos, Math.min(1, dt * Math.max(1, magnetR + 1 - d) * 2.2));
      }
      if (d < 1.2) {
        this._collect(p);
        this.list.splice(i, 1);
      } else if (p.t <= 0) {
        g.scene.remove(p.mesh);
        this.list.splice(i, 1);
      }
    }
  }

  _collect(p) {
    const g = this.game;
    g.scene.remove(p.mesh);
    if (p.kind === 'chips') {
      const amt = Math.round(p.amount * g.comboMult() * g.playerMods.chipPickupMult);  // Loaded Dice
      g.addChips(amt);
      if (g.playerMods.chipHeal) g.player.heal(Math.floor(amt / 25));                  // Vampire Chips
      Audio.play('chip');
      g.ui.floatText(p.mesh.position, `+${amt}`, 'chips');
    } else if (p.kind === 'ammo') {
      g.weapons.addReservePct(0.35);
      Audio.play('ammo');
      g.ui.floatText(p.mesh.position, '+AMMO', 'ammo');
    } else if (p.kind === 'heal') {
      g.player.heal(p.amount);
      Audio.play('heal');
      g.ui.floatText(p.mesh.position, `+${p.amount} HP`, 'heal');
    }
  }

  clear() {
    for (const p of this.list) this.game.scene.remove(p.mesh);
    this.list = [];
  }
}
