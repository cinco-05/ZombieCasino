// player.js — first-person controller: WASD + sprint + jump, mouse look,
// NEW dash (Q) with i-frames, health/armor, damage handling.

import * as THREE from 'three';
import { CONFIG, clamp } from './config.js';
import { Audio } from './audio.js';

const P = CONFIG.player;

export class Player {
  constructor(game) {
    this.game = game;
    this.keys = {};
    this.aiming = false;

    this.pos = new THREE.Vector3(0, P.eyeHeight, 8);
    this.vel = new THREE.Vector3();
    this.yaw = Math.PI;      // face the room
    this.pitch = 0;
    this.onGround = true;

    this.maxHp = P.hp;
    this.hp = P.hp;
    this.armor = 0;
    this.iFrames = 0;

    this.grenades = CONFIG.grenade.start;   // NEW
    this.dashCd = 0;                        // NEW
    this.dashT = 0;
    this.dashDir = new THREE.Vector3();

    this.bobT = 0;
  }

  reset() {
    this.pos.set(0, P.eyeHeight, 8);
    this.vel.set(0, 0, 0);
    this.yaw = Math.PI; this.pitch = 0;
    this.hp = this.maxHp = P.hp;
    this.armor = 0;
    this.iFrames = 0;
    this.grenades = CONFIG.grenade.start;
    this.dashCd = 0; this.dashT = 0;
    this.aiming = false;
  }

  onMouseMove(dx, dy) {
    const s = 0.0022 * this.game.settings.sensitivity * (this.aiming ? 0.6 : 1);
    this.yaw -= dx * s;
    this.pitch = clamp(this.pitch - dy * s, -1.45, 1.45);
  }

  forwardFlat() {
    return new THREE.Vector3(Math.sin(this.yaw), 0, Math.cos(this.yaw)).multiplyScalar(-1);
  }

  rightFlat() {
    const f = this.forwardFlat();
    return new THREE.Vector3(-f.z, 0, f.x);
  }

  tryDash() {
    if (this.dashCd > 0 || this.dashT > 0) return;
    const dir = new THREE.Vector3();
    if (this.keys['KeyW']) dir.add(this.forwardFlat());
    if (this.keys['KeyS']) dir.sub(this.forwardFlat());
    if (this.keys['KeyD']) dir.add(this.rightFlat());
    if (this.keys['KeyA']) dir.sub(this.rightFlat());
    if (dir.lengthSq() < 0.01) dir.copy(this.forwardFlat());
    dir.normalize();
    this.dashDir.copy(dir);
    this.dashT = P.dashTime;
    this.dashCd = P.dashCooldown * this.game.playerMods.dashCd;
    this.iFrames = Math.max(this.iFrames, P.dashIFrames);
    if (this.game.playerMods.dashDamage) this.game.dashBuffT = 1.5;   // Dash & Cash
    Audio.play('dash');
  }

  update(dt) {
    const g = this.game;
    this.iFrames = Math.max(0, this.iFrames - dt);
    this.dashCd = Math.max(0, this.dashCd - dt);

    // horizontal intent
    const dir = new THREE.Vector3();
    if (this.keys['KeyW']) dir.add(this.forwardFlat());
    if (this.keys['KeyS']) dir.sub(this.forwardFlat());
    if (this.keys['KeyD']) dir.add(this.rightFlat());
    if (this.keys['KeyA']) dir.sub(this.rightFlat());
    if (dir.lengthSq() > 0) dir.normalize();

    let speed = P.speed;
    if (this.keys['ShiftLeft'] || this.keys['ShiftRight']) speed *= P.sprintMult;
    if (this.aiming) speed *= 0.55;
    speed *= g.casino.roundMods.playerSlowMult || 1;
    speed *= g.playerMods.speed;

    let move;
    if (this.dashT > 0) {
      this.dashT -= dt;
      move = this.dashDir.clone().multiplyScalar(P.dashSpeed * dt);
    } else {
      move = dir.multiplyScalar(speed * dt);
    }
    this.pos.add(move);

    // jump + gravity
    if (this.keys['Space'] && this.onGround) {
      this.vel.y = P.jumpVel;
      this.onGround = false;
    }
    const fallSpeed = -this.vel.y;
    this.vel.y -= P.gravity * dt;
    this.pos.y += this.vel.y * dt;
    if (this.pos.y <= P.eyeHeight) {
      this.pos.y = P.eyeHeight;
      this.vel.y = 0;
      if (!this.onGround && fallSpeed > 5) {
        this.landDipT = 0.18;                       // camera dips on a hard landing
        Audio.play('step_heavy');
      }
      this.onGround = true;
    }
    this.landDipT = Math.max(0, (this.landDipT ?? 0) - dt);

    // collide with arena bounds + cover
    g.arena.collide(this.pos, P.radius);

    // camera
    const bobbing = this.onGround && move.lengthSq() > 1e-6 && this.dashT <= 0;
    if (bobbing) this.bobT += dt * (speed > P.speed ? 11 : 8);
    const bob = bobbing ? Math.sin(this.bobT) * 0.035 : 0;
    const landDip = this.landDipT > 0 ? Math.sin((1 - this.landDipT / 0.18) * Math.PI) * 0.07 : 0;
    g.camera.position.set(this.pos.x, this.pos.y + bob - landDip, this.pos.z);
    g.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');

    // aim zoom
    const targetFov = this.aiming && g.weapons.current.def.zoomOk ? P.aimFov : P.fov;
    g.camera.fov += (targetFov - g.camera.fov) * Math.min(1, dt * 12);
    g.camera.updateProjectionMatrix();
  }

  heal(amount) {
    this.hp = clamp(this.hp + amount, 0, this.maxHp);
    this.game.ui.updateHUD();
  }

  addArmor(amount) {
    this.armor = clamp(this.armor + amount, 0, 100);
  }

  /** returns true if damage actually landed */
  takeDamage(amount, source = null) {
    const g = this.game;
    if (this.hp <= 0 || this.iFrames > 0 || g.debug.invuln) return false;
    if (g.state !== 'COMBAT') return false;

    if (this.armor > 0 && !g.playerMods.armorDisabled) {   // Glass Cannon voids armor
      const absorbed = Math.min(this.armor, amount * P.armorAbsorb);
      this.armor -= absorbed;
      amount -= absorbed;
    }
    this.hp -= amount;
    // Loaded Dice: getting hit shakes chips loose
    if (g.playerMods.hitChipLoss > 0 && g.chips > 0) {
      g.chips = Math.max(0, g.chips - g.playerMods.hitChipLoss);
    }
    // UNTOUCHABLE objective fails on any hit
    if (g.objective?.def.key === 'untouchable') g.objective.failed = true;
    this.iFrames = P.hurtIFrames;
    Audio.play('hurt');
    g.addShake(0.08);
    g.ui.hurtFlash();

    // Debt Collector steals chips on hit
    if (source?.def?.stealOnHit && g.chips > 0) {
      const stolen = Math.min(g.chips, source.def.stealOnHit);
      g.chips -= stolen;
      source.stash = (source.stash || 0) + stolen;
      Audio.play('steal');
      g.ui.prompt(`THE DEBT COLLECTOR TOOK ${stolen} CHIPS`);
    }

    if (this.hp <= 0) {
      this.hp = 0;
      g.onPlayerDeath(source?.def?.name || 'the horde');
    }
    return true;
  }
}
