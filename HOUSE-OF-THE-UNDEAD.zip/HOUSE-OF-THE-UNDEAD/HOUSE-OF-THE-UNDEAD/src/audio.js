// audio.js — 100% procedural WebAudio. No sound files, nothing to download.
// Audio.init() must be called from a user gesture (main.js does this on the
// first canvas click). Every play() is safe to call before init — it no-ops.

let ctx = null;
let master = null, sfxGain = null, musicGain = null, ambientGain = null;
let musicTimer = null, musicStep = 0, musicFast = false, musicIntensity = 0.15;
let currentDest = null;   // when set, synth nodes route here (spatial panner)

function now() { return ctx.currentTime; }

function env(gainNode, peak, attack, decay, t0 = now()) {
  const g = gainNode.gain;
  g.cancelScheduledValues(t0);
  g.setValueAtTime(0.0001, t0);
  g.exponentialRampToValueAtTime(Math.max(peak, 0.0001), t0 + attack);
  g.exponentialRampToValueAtTime(0.0001, t0 + attack + decay);
}

function osc(type, freq, peak, attack, decay, slideTo = null) {
  if (!ctx) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, now());
  if (slideTo !== null) o.frequency.exponentialRampToValueAtTime(Math.max(slideTo, 1), now() + attack + decay);
  env(g, peak, attack, decay);
  o.connect(g).connect(currentDest || sfxGain);
  o.start();
  o.stop(now() + attack + decay + 0.05);
}

let noiseBuf = null;
function noise(peak, decay, filterFreq = 1200, filterType = 'lowpass') {
  if (!ctx) return;
  if (!noiseBuf) {
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.6, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  const src = ctx.createBufferSource();
  src.buffer = noiseBuf;
  const f = ctx.createBiquadFilter();
  f.type = filterType;
  f.frequency.value = filterFreq;
  const g = ctx.createGain();
  env(g, peak, 0.005, decay);
  src.connect(f).connect(g).connect(currentDest || sfxGain);
  src.start();
  src.stop(now() + decay + 0.1);
}

const SFX = {
  shoot_pistol:  () => { noise(0.5, 0.10, 1800); osc('square', 160, 0.25, 0.005, 0.08, 60); },
  shoot_shotgun: () => { noise(0.8, 0.22, 900);  osc('square', 90, 0.3, 0.005, 0.18, 40); },
  shoot_smg:     () => { noise(0.3, 0.06, 2400); osc('square', 300, 0.15, 0.003, 0.05, 120); },
  shoot_rifle:   () => { noise(0.7, 0.3, 700);   osc('sine', 70, 0.4, 0.005, 0.25, 30); },
  dryfire:       () => osc('square', 900, 0.12, 0.003, 0.04),
  reload:        () => { osc('square', 500, 0.15, 0.005, 0.05); setTimeout(() => osc('square', 750, 0.15, 0.005, 0.05), 140); },
  hit:           () => osc('square', 700, 0.14, 0.003, 0.05),
  crit:          () => { osc('square', 950, 0.16, 0.003, 0.08); osc('sine', 1400, 0.12, 0.003, 0.09); },
  hurt:          () => osc('sawtooth', 170, 0.3, 0.005, 0.18, 90),
  steal:         () => osc('sawtooth', 600, 0.2, 0.005, 0.15, 200),
  zombie_die:    () => { noise(0.25, 0.2, 500); osc('sawtooth', 220, 0.18, 0.01, 0.2, 70); },
  groan:         () => { osc('sawtooth', 90 + Math.random() * 50, 0.12, 0.15, 0.5, 60); noise(0.06, 0.5, 400); },
  step_heavy:    () => { osc('sine', 55, 0.25, 0.004, 0.12, 35); noise(0.08, 0.08, 300); },
  step_click:    () => { noise(0.15, 0.05, 3000, 'highpass'); osc('square', 800, 0.05, 0.002, 0.03); },
  ambient_chime: () => { const f = 660 + Math.random() * 500; osc('sine', f, 0.06, 0.02, 0.5); setTimeout(() => osc('sine', f * 1.25, 0.05, 0.02, 0.6), 160); },
  neon_buzz:     () => noise(0.04, 0.9, 120, 'bandpass'),
  crowd_gasp:    () => { osc('sawtooth', 200, 0.03, 0.2, 0.6, 150); noise(0.03, 0.8, 600); },
  explosion:     () => { noise(0.9, 0.5, 350); osc('sine', 55, 0.5, 0.01, 0.45, 25); },
  gas_hiss:      () => noise(0.3, 0.5, 3500, 'highpass'),
  chip:          () => osc('sine', 1300, 0.14, 0.003, 0.07, 1700),
  heal:          () => { osc('sine', 780, 0.14, 0.01, 0.2); osc('sine', 990, 0.12, 0.01, 0.25); },
  ammo:          () => { osc('square', 420, 0.14, 0.005, 0.06); setTimeout(() => osc('square', 560, 0.14, 0.005, 0.06), 90); },
  dash:          () => noise(0.25, 0.15, 4000, 'highpass'),
  melee:         () => { noise(0.4, 0.1, 800); osc('square', 220, 0.2, 0.004, 0.08, 100); },
  card:          () => noise(0.2, 0.06, 5000, 'highpass'),
  wheel_tick:    () => osc('square', 1100, 0.08, 0.002, 0.03),
  slot_spin:     () => osc('square', 500, 0.1, 0.003, 0.04),
  wager_win:     () => { osc('sine', 523, 0.2, 0.01, 0.25); setTimeout(() => osc('sine', 659, 0.2, 0.01, 0.3), 120); setTimeout(() => osc('sine', 784, 0.2, 0.01, 0.4), 240); },
  wager_lose:    () => { osc('sawtooth', 300, 0.22, 0.01, 0.3, 150); setTimeout(() => osc('sawtooth', 220, 0.22, 0.01, 0.4, 110), 200); },
  jackpot:       () => { for (let i = 0; i < 5; i++) setTimeout(() => osc('sine', 523 * Math.pow(1.2, i), 0.2, 0.01, 0.3), i * 90); },
  boss_phase:    () => { osc('sawtooth', 110, 0.35, 0.02, 0.6, 55); noise(0.3, 0.6, 300); },
  warn:          () => osc('square', 880, 0.18, 0.005, 0.12, 660),
  door:          () => { osc('sine', 392, 0.18, 0.01, 0.2); setTimeout(() => osc('sine', 523, 0.18, 0.01, 0.3), 110); },
  countdown:     () => osc('square', 660, 0.15, 0.005, 0.09),
  go:            () => osc('square', 990, 0.2, 0.005, 0.2),
};

// ---------------------- casino lounge band (procedural) ----------------------
// A swinging walking bassline over a jazzy vamp, brushed ride ticks, and a
// soft chord pad every four bars. Danger speeds the swing and adds hats;
// boss mode drops it into a fast minor stride.

// walking bass lines (Hz): Am7 -> D7 -> G6 -> E7 vamp, and a minor stride for bosses
const WALK_MAJOR = [110.0, 130.8, 164.8, 155.6, 146.8, 138.6, 123.5, 116.5];
const WALK_MINOR = [110.0, 110.0, 130.8, 110.0, 103.8, 98.0, 92.5, 98.0];
// chord pads (triads, Hz) — one per bar, cycled every 4 bars
const PADS = [
  [220.0, 261.6, 329.6],   // Am
  [220.0, 277.2, 349.2],   // D-ish
  [196.0, 246.9, 293.7],   // G
  [207.7, 246.9, 329.6],   // E7-ish
];

function musicTick() {
  if (!ctx) return;
  const minor = musicFast;
  const walk = minor ? WALK_MINOR : WALK_MAJOR;
  const step = musicStep % 8;

  // upright bass: triangle with a soft pluck envelope
  const f = walk[step];
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = 'triangle';
  o.frequency.value = f / 2;
  env(g, 0.28, 0.012, 0.3);
  o.connect(g).connect(musicGain);
  o.start(); o.stop(now() + 0.45);

  // brushed ride: soft highpassed tick every beat, accented on the 1
  if (noiseBuf) {
    const src = ctx.createBufferSource();
    src.buffer = noiseBuf;
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass'; hp.frequency.value = 7500;
    const rg = ctx.createGain();
    env(rg, step % 4 === 0 ? 0.045 : 0.022, 0.002, 0.09);
    src.connect(hp).connect(rg).connect(musicGain);
    src.start(); src.stop(now() + 0.12);
  }

  // chord pad on the downbeat of each bar — the lounge in "lounge music"
  if (step % 8 === 0) {
    const pad = PADS[Math.floor(musicStep / 8) % PADS.length];
    for (const pf of pad) {
      const po = ctx.createOscillator();
      const pg = ctx.createGain();
      po.type = 'sine';
      po.frequency.value = pf * (minor ? 0.944 : 1);   // minor drop for boss mode
      po.detune.value = (Math.random() - 0.5) * 8;     // gentle chorus wobble
      env(pg, 0.045, 0.35, 1.6);
      po.connect(pg).connect(musicGain);
      po.start(); po.stop(now() + 2.2);
    }
  }

  // occasional vibraphone-ish blip riffing over the top
  if (step === 5 && Math.random() < 0.4) {
    const bf = walk[(step + 3) % 8] * 4;
    const bo = ctx.createOscillator();
    const bg = ctx.createGain();
    bo.type = 'sine'; bo.frequency.value = bf;
    env(bg, 0.05, 0.01, 0.5);
    bo.connect(bg).connect(musicGain);
    bo.start(); bo.stop(now() + 0.6);
  }
  // hi-hat layer fades in as things get dangerous
  if (musicIntensity > 0.45 && ctx) {
    const hg = ctx.createGain();
    const src = ctx.createBufferSource();
    if (noiseBuf) {
      src.buffer = noiseBuf;
      const hp = ctx.createBiquadFilter();
      hp.type = 'highpass'; hp.frequency.value = 6000;
      env(hg, 0.05 * musicIntensity, 0.002, 0.05);
      src.connect(hp).connect(hg).connect(musicGain);
      src.start(); src.stop(now() + 0.1);
    }
  }
  musicStep++;
  const base = musicFast ? 170 : Math.round(330 - 160 * musicIntensity);
  const swing = musicStep % 2 === 1 ? 1.32 : 0.68;     // that lounge shuffle
  musicTimer = setTimeout(musicTick, Math.round(base * swing));
}

// --------------------------- ambient soundscape ------------------------------
// faint slot chimes, neon buzz, crowd murmur — the casino never goes silent
let murmurStarted = false;
function startMurmur() {
  if (murmurStarted || !ctx) return;
  murmurStarted = true;
  if (!noiseBuf) {
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 0.6, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  const src = ctx.createBufferSource();
  src.buffer = noiseBuf;
  src.loop = true;
  const lp = ctx.createBiquadFilter();
  lp.type = 'lowpass'; lp.frequency.value = 260;
  const g = ctx.createGain();
  g.gain.value = 0.035;
  // slow swell so it breathes
  const lfo = ctx.createOscillator();
  const lfoGain = ctx.createGain();
  lfo.frequency.value = 0.06;
  lfoGain.gain.value = 0.018;
  lfo.connect(lfoGain).connect(g.gain);
  src.connect(lp).connect(g).connect(ambientGain);
  src.start(); lfo.start();
}

function scheduleAmbience() {
  if (!ctx) return;
  setTimeout(() => {
    if (ctx && ctx.state !== 'suspended') {
      const pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
      if (pan) {
        pan.pan.value = Math.random() * 1.8 - 0.9;
        pan.connect(ambientGain);
        currentDest = pan;
      }
      const r = Math.random();
      try {
        if (r < 0.55) SFX.ambient_chime();
        else if (r < 0.85) SFX.neon_buzz();
        else SFX.crowd_gasp();
      } catch { /* never crash on ambience */ }
      currentDest = null;
      if (pan) setTimeout(() => { try { pan.disconnect(); } catch {} }, 3000);
    }
    scheduleAmbience();
  }, 3500 + Math.random() * 6000);
}

export const Audio = {
  ready: false,

  init() {
    if (this.ready) return;
    try {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      master = ctx.createGain();
      sfxGain = ctx.createGain();
      musicGain = ctx.createGain();
      ambientGain = ctx.createGain();
      sfxGain.connect(master);
      musicGain.connect(master);
      ambientGain.connect(master);
      master.connect(ctx.destination);
      this.ready = true;
      this.setVolumes(0.8, 0.9, 0.5);
      startMurmur();   // also builds the shared noise buffer for the ride
      musicTick();
      scheduleAmbience();
    } catch (e) {
      console.warn('WebAudio unavailable:', e);
    }
  },

  setVolumes(masterV, sfxV, musicV) {
    if (!ctx) return;
    master.gain.value = masterV;
    sfxGain.gain.value = sfxV;
    musicGain.gain.value = musicV;
    ambientGain.gain.value = musicV * 0.9;   // ambience rides the music slider
  },

  setBossMode(on) { musicFast = on; },

  /** 0..1 danger level — drives music tempo + hat layer */
  setIntensity(v) { musicIntensity = Math.max(0, Math.min(1, v)); },

  /** play a sound AT a world position; pans + attenuates with distance.
      opts.muffled runs it through a lowpass (behind cover). */
  playAt(name, pos, opts = {}) {
    if (!ctx || ctx.state === 'suspended') return;
    const fn = SFX[name];
    if (!fn) return;
    const panner = ctx.createPanner();
    panner.panningModel = 'equalpower';
    panner.distanceModel = 'inverse';
    panner.refDistance = 3;
    panner.maxDistance = 50;
    panner.rolloffFactor = 1.35;
    if (panner.positionX) {
      panner.positionX.value = pos.x;
      panner.positionY.value = pos.y ?? 1.5;
      panner.positionZ.value = pos.z;
    } else panner.setPosition(pos.x, pos.y ?? 1.5, pos.z);
    const bus = opts.bus === 'ambient' ? ambientGain : sfxGain;
    if (opts.muffled) {
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass'; lp.frequency.value = 650;
      panner.connect(lp).connect(bus);
    } else {
      panner.connect(bus);
    }
    currentDest = panner;
    try { fn(); } catch { /* never crash on audio */ }
    currentDest = null;
    setTimeout(() => { try { panner.disconnect(); } catch {} }, 3000);
  },

  /** call every frame with the camera so left/right/behind are real */
  updateListener(pos, fwd) {
    if (!ctx) return;
    const L = ctx.listener;
    if (L.positionX) {
      L.positionX.value = pos.x; L.positionY.value = pos.y; L.positionZ.value = pos.z;
      L.forwardX.value = fwd.x; L.forwardY.value = fwd.y; L.forwardZ.value = fwd.z;
      L.upX.value = 0; L.upY.value = 1; L.upZ.value = 0;
    } else {
      L.setPosition(pos.x, pos.y, pos.z);
      L.setOrientation(fwd.x, fwd.y, fwd.z, 0, 1, 0);
    }
  },

  play(name) {
    if (!ctx || ctx.state === 'suspended') return;
    const fn = SFX[name];
    if (fn) { try { fn(); } catch (e) { /* never crash on audio */ } }
  },
};
