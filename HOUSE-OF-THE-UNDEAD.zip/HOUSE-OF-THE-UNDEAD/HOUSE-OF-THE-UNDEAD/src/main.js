// main.js — bootstrap + input wiring. Everything else lives in the systems.

import { Game } from './game.js';
import { initDebug } from './debug.js';
import { Audio } from './audio.js';

const game = new Game();
const debugPanel = initDebug(game);
window.HOTU = game; // handy for console poking

const canvas = game.renderer.domElement;

// ---------- pointer lock ----------
canvas.addEventListener('click', () => {
  Audio.init(); // first user gesture unlocks WebAudio
  if (game.state === 'COMBAT' || game.state === 'COUNTDOWN') game.ui.requestPointer();
});

document.addEventListener('pointerlockchange', () => {
  const locked = document.pointerLockElement === canvas;
  if (!locked && (game.state === 'COMBAT' || game.state === 'COUNTDOWN')) {
    game.pause(); // Esc released the pointer → pause menu
  }
});

document.addEventListener('mousemove', (e) => {
  if (document.pointerLockElement === canvas) {
    game.player.onMouseMove(e.movementX, e.movementY);
  }
});

// ---------- mouse buttons ----------
document.addEventListener('mousedown', (e) => {
  if (document.pointerLockElement !== canvas) return;
  if (e.button === 0) {
    game.weapons.triggerHeld = true;
    game.weapons.tryFire();
  } else if (e.button === 2) {
    game.player.aiming = true;
  }
});
document.addEventListener('mouseup', (e) => {
  if (e.button === 0) game.weapons.triggerHeld = false;
  if (e.button === 2) game.player.aiming = false;
});
document.addEventListener('contextmenu', (e) => e.preventDefault());

// ---------- keyboard ----------
document.addEventListener('keydown', (e) => {
  game.player.keys[e.code] = true;
  if (e.code === 'KeyR') game.weapons.startReload();
  if (e.code === 'Digit1') game.weapons.switchTo('pistol');
  if (e.code === 'Digit2') game.weapons.switchTo('shotgun');
  if (e.code === 'Digit3') game.weapons.switchTo('smg');
  if (e.code === 'Digit4') game.weapons.switchTo('rifle');
  if (e.code === 'KeyQ') game.player.tryDash();
  if (e.code === 'KeyG') game.weapons.tryGrenade();
  if (e.code === 'KeyF') game.weapons.tryMelee();
  if (e.code === 'F3') { e.preventDefault(); debugPanel.toggle(); }
  if (e.code === 'Space' && document.pointerLockElement === canvas) e.preventDefault();
});
document.addEventListener('keyup', (e) => {
  game.player.keys[e.code] = false;
});

// losing tab focus during combat pauses too
document.addEventListener('visibilitychange', () => {
  if (document.hidden) game.pause();
});
