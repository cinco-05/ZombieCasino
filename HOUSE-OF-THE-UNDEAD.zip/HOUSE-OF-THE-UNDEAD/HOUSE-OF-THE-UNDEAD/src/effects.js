// effects.js — cheap particle juice: impact bursts (blood / chip sparks /
// explosion embers) and ejected shell casings. Everything is a tiny mesh with
// velocity + gravity + lifetime; capped so it can never eat the frame rate.

import * as THREE from 'three';
import { rand } from './config.js';

const MAX_PARTICLES = 90;
const MAX_SHELLS = 30;

export class Effects {
  constructor(game) {
    this.game = game;
    this.particles = [];
    this.shells = [];
    this._pGeo = new THREE.BoxGeometry(0.07, 0.07, 0.07);
    this._shellGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.07, 6);
    this._shellMat = new THREE.MeshStandardMaterial({ color: 0xd4af37, metalness: 0.9, roughness: 0.3 });
  }

  /** burst of colored particles at a world position. Negative gravity = smoke rises. */
  spawnBurst(pos, color, count = 6, speed = 4, gravity = 12) {
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= MAX_PARTICLES) {
        const old = this.particles.shift();
        this.game.scene.remove(old.mesh);
      }
      const mesh = new THREE.Mesh(this._pGeo, new THREE.MeshBasicMaterial({ color }));
      mesh.position.copy(pos);
      this.game.scene.add(mesh);
      this.particles.push({
        mesh, grav: gravity,
        vel: new THREE.Vector3(rand(-1, 1), rand(0.3, 1.4), rand(-1, 1)).normalize().multiplyScalar(rand(speed * 0.5, speed)),
        t: gravity < 0 ? rand(0.5, 0.9) : rand(0.35, 0.65),
      });
    }
  }

  /** shell casing ejected from the current weapon's breech */
  spawnShell() {
    const g = this.game;
    if (this.shells.length >= MAX_SHELLS) {
      const old = this.shells.shift();
      g.scene.remove(old.mesh);
    }
    const mesh = new THREE.Mesh(this._shellGeo, this._shellMat);
    g.weapons.vm.getWorldPosition(mesh.position);
    // eject to the player's right and slightly up
    const right = g.player.rightFlat();
    const vel = right.multiplyScalar(rand(1.6, 2.6))
      .add(new THREE.Vector3(0, rand(2.2, 3.2), 0))
      .add(g.player.forwardFlat().multiplyScalar(rand(-0.4, 0.4)));
    g.scene.add(mesh);
    this.shells.push({ mesh, vel, spin: rand(8, 18), t: 1.1, bounced: false });
  }

  update(dt) {
    const g = this.game;
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.t -= dt;
      p.vel.y -= (p.grav ?? 12) * dt;
      p.mesh.position.add(p.vel.clone().multiplyScalar(dt));
      p.mesh.rotation.x += dt * 9;
      p.mesh.rotation.z += dt * 7;
      if (p.t <= 0 || (p.grav >= 0 && p.mesh.position.y < 0)) {
        g.scene.remove(p.mesh);
        this.particles.splice(i, 1);
      }
    }
    for (let i = this.shells.length - 1; i >= 0; i--) {
      const sh = this.shells[i];
      sh.t -= dt;
      sh.vel.y -= 16 * dt;
      sh.mesh.position.add(sh.vel.clone().multiplyScalar(dt));
      sh.mesh.rotation.x += dt * sh.spin;
      sh.mesh.rotation.z += dt * sh.spin * 0.6;
      if (sh.mesh.position.y < 0.04 && !sh.bounced) {
        sh.bounced = true;
        sh.mesh.position.y = 0.04;
        sh.vel.y = Math.abs(sh.vel.y) * 0.3;
        sh.vel.x *= 0.5; sh.vel.z *= 0.5;
      }
      if (sh.t <= 0) {
        g.scene.remove(sh.mesh);
        this.shells.splice(i, 1);
      }
    }
  }

  clear() {
    for (const p of this.particles) this.game.scene.remove(p.mesh);
    for (const s of this.shells) this.game.scene.remove(s.mesh);
    this.particles = [];
    this.shells = [];
  }
}
