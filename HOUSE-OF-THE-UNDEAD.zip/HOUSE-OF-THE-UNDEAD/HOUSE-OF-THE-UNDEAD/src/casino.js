// casino.js — the entire between-rounds loop: supply shop, wager selection
// (Safe Bet / High Roller / All In / House Credit), playable blackjack,
// animated fair roulette, the NEW slot machine, and penalty resolution.
// Winning a wager is the only way to earn attachment upgrades.

import { CONFIG, pick, clamp } from './config.js';
import {
  newDeck, handValue, isBlackjack, dealerPlay, resolveBlackjack,
  spinRoulette, evaluateRouletteBet, WHEEL_ORDER, pocketColor,
  spinSlots, spinReel, slotPayout, spinGrid, evalSlotsGrid,
  spinGrid5, evalSlotsGrid5,
  evaluatePokerHand, comparePoker, pokerTier, dealerHolds,
} from './cards.js';
import { Audio } from './audio.js';

const $ = (id) => document.getElementById(id);

// ---------------------------- penalties -------------------------------------
const PENALTIES = {
  mild: [
    { label: 'Enemies move 10% faster', mod: { speedMult: 1.1 } },
    { label: '15% more enemies next round', mod: { countMult: 1.15 } },
    { label: '-20% reserve ammunition', immediate: (g) => g.weapons.applyReservePenalty(0.8) },
    { label: 'Healing drops are scarcer', mod: { healDropMult: 0.4 } },
  ],
  moderate: [
    { label: 'An extra special enemy joins the round', mod: { extraSpecial: 1 } },
    { label: 'Enemies deal 15% more damage', mod: { dmgMult: 1.15 } },
    { label: 'Threat indicator disabled', mod: { noIndicator: true } },
    { label: 'The lights go low', mod: { lowLight: true } },
    { label: '30% more enemies next round', mod: { countMult: 1.3 } },
  ],
  severe: [
    { label: 'THE DEBT COLLECTOR is coming for you', mod: { debtCollector: true } },
    { label: 'Two moderate penalties at once', compound: 2 },
    { label: 'Reserve ammunition halved', immediate: (g) => g.weapons.applyReservePenalty(0.5) },
    { label: 'Elite zombies join the horde', mod: { elite: true } },
    { label: 'Double special enemies', mod: { extraSpecial: 2, countMult: 1.15 } },
  ],
};

export class Casino {
  constructor(game) {
    this.game = game;
    this.timer = 0;
    this.timerRunning = false;
    this.houseCreditUsed = false;
    this.pendingMods = [];    // penalties queued for next round: {label, mod}
    this.roundMods = {};      // merged mods active THIS round
    this.currentWager = null; // {level, amount, credit}
    this.slotRespinUsed = false;
    this.slotReels = null;
    this.bj = null;
    this.rouletteBet = null;
    this._wireStaticButtons();
  }

  reset() {
    this.pendingMods = [];
    this.roundMods = {};
    this.currentWager = null;
    this.houseCreditUsed = false;
    this.timerRunning = false;
  }

  activePenaltyLabels() { return this.pendingMods.map((p) => p.label); }

  // ============================ intermission =================================
  beginIntermission() {
    const g = this.game;
    this.houseCreditUsed = false;
    this.slotRespinUsed = false;
    this.timer = CONFIG.intermissionSeconds;
    this.timerRunning = true;
    if (g.playerMods.interest > 0) {
      g.addChips(g.playerMods.interest);
      g.ui.banner(`CARD COUNTER: +${g.playerMods.interest} chips`, 'cyan', 1600);
    }
    this.updateChipsUI();
    $('inter-round').textContent = g.round >= 10 && g.beatHouse
      ? `ROUND ${g.round} CLEARED — THE FLOOR STAYS OPEN`
      : `ROUND ${g.round} CLEARED — NEXT: ROUND ${g.round + 1}`;
    $('btn-cashout').style.display = g.beatHouse ? '' : 'none';
    const creditNote = $('house-credit-note');
    creditNote.style.display = (g.chips < CONFIG.wagers.minBet && !this.houseCreditUsed) ? '' : 'none';
    this._refreshShopButtons();
    g.ui.show('intermission');
    Audio.play('door');
    g.saveRun();
  }

  updateTimer(dt) {
    if (!this.timerRunning) return;
    this.timer -= dt;
    $('inter-timer').textContent = `Next round in ${Math.max(0, Math.ceil(this.timer))}s — or skip`;
    if (this.timer <= 0) this.startNextRound();
  }

  startNextRound() {
    this.timerRunning = false;
    this.game.ui.hideAllPanels();
    this.game.startNextRound();
  }

  updateChipsUI() {
    const g = this.game;
    for (const el of document.querySelectorAll('.chip-balance')) {
      el.textContent = `${g.chips} CHIPS`;
    }
    this._refreshShopButtons();
  }

  // =============================== shop ======================================
  /** cashier price after the COMPED RATES vault perk */
  price(p) {
    return Math.round(p * (this.game.vault?.value('comped', 1) || 1));
  }

  _refreshShopButtons() {
    const g = this.game;
    const S = CONFIG.shop;
    const rifleLocked = g.weapons.arsenal.rifle.locked;
    $('buy-rifle').style.display = rifleLocked ? '' : 'none';
    const afford = (basePrice, el) => {
      const p = this.price(basePrice);
      el.classList.toggle('cant-afford', g.chips < p);
      const span = el.querySelector('span');
      if (span) span.textContent = p;   // show the comped price on the button
    };
    afford(S.smallHeal.price, $('buy-small-heal'));
    afford(S.fullHeal.price, $('buy-full-heal'));
    afford(S.ammo.price, $('buy-ammo'));
    afford(S.armor.price, $('buy-armor'));
    afford(S.grenade.price, $('buy-grenade'));
    if (rifleLocked) afford(S.rifleUnlock.price, $('buy-rifle'));
    $('buy-grenade').classList.toggle('cant-afford',
      g.chips < this.price(S.grenade.price) || g.player.grenades >= g.playerMods.grenadeMax);
  }

  _buy(price, fn) {
    const g = this.game;
    if (g.chips < price) { Audio.play('dryfire'); g.ui.prompt('Not enough chips.'); return; }
    g.chips -= price;
    fn();
    Audio.play('chip');
    this.updateChipsUI();
    g.ui.updateHUD();
    g.saveRun();
  }

  // ===================== wagers: choose your stake ===========================
  /** stake -> {tier, penalty} using risk thresholds (absolute + fraction) */
  tierForStake(stake, chips) {
    const W = CONFIG.wagers;
    if (stake >= W.legendary.min && stake >= chips * W.legendary.frac) {
      return { tier: 'legendary', penalty: 'severe' };
    }
    if (stake >= W.rare.min && stake >= chips * W.rare.frac) {
      return { tier: 'rare', penalty: 'moderate' };
    }
    return { tier: 'common', penalty: 'mild' };
  }

  openWagerPanel(gameKind) {
    const g = this.game;
    this.gameKind = gameKind;
    this.updateChipsUI();
    const poker = gameKind === 'poker';
    $('wager-title').textContent = poker ? 'CHOOSE YOUR ANTE' : 'CHOOSE YOUR STAKE';
    const wrap = $('wager-buttons');
    wrap.innerHTML = '';
    const minBet = poker ? CONFIG.poker.minAnte : CONFIG.wagers.minBet;

    if (g.chips >= minBet) {
      $('wager-custom').style.display = '';
      const slider = $('wager-slider');
      slider.min = minBet;
      slider.max = g.chips;
      slider.step = 10;
      slider.value = Math.min(g.chips, 150);
      this._updateStakeReadout();
    } else {
      // broke: house credit if it's still on the table
      $('wager-custom').style.display = 'none';
      if (!this.houseCreditUsed) {
        const b = document.createElement('button');
        b.className = 'btn wager-btn credit';
        b.innerHTML = `<b>HOUSE CREDIT</b> — free ${poker ? 'hand' : 'wager'}<br>
          <span class="small">${poker ? 'Hand rank still sets the reward.' : 'Win: COMMON upgrade.'} Lose: mild penalty. The house is "generous". Once.</span>`;
        b.onclick = () => this._acceptWager('credit', 0, { tier: CONFIG.wagers.houseCreditTier, penalty: 'mild' });
        wrap.appendChild(b);
      } else {
        wrap.innerHTML = `<p class="dim">You need at least ${minBet} chips, and the house credit is spent. Go earn some.</p>`;
      }
    }

    g.ui.hide('intermission');
    g.ui.show('wager-panel');
  }

  _updateStakeReadout() {
    const g = this.game;
    const stake = parseInt($('wager-slider').value, 10);
    $('wager-amount').textContent = `${stake} CHIPS`;
    const note = $('wager-tier-note');
    if (this.gameKind === 'poker') {
      const bump = this.tierForStake(stake, g.chips).tier === 'legendary';
      note.innerHTML = `Hand rank sets the reward tier.<br>` +
        (bump ? `<span class="gold">BIG-RISK ANTE: reward tier bumped +1!</span>`
              : `<span class="dim small">Ante 85% of your chips (300+) to bump the tier +1.</span>`) +
        `<br><span class="dim small">Lose: moderate penalty.</span>`;
      note.className = bump ? 'tier-note legendary' : 'tier-note';
    } else {
      const { tier, penalty } = this.tierForStake(stake, g.chips);
      note.innerHTML = `Win: <b>${tier.toUpperCase()}</b> upgrade + chips back double.<br>` +
        `<span class="dim small">Lose: ${penalty} penalty next round.</span>`;
      note.className = `tier-note ${tier}`;
    }
  }

  _confirmStake() {
    const g = this.game;
    const stake = parseInt($('wager-slider').value, 10);
    if (stake > g.chips) return;
    const poker = this.gameKind === 'poker';
    const { tier, penalty } = this.tierForStake(stake, g.chips);
    const def = poker
      ? { tier: 'common', penalty: 'moderate', riskBump: tier === 'legendary' }
      : { tier, penalty };

    // legendary-level risk gets the "are you sure" treatment
    if (tier === 'legendary') {
      $('allin-text').textContent = poker
        ? `You are anteing ${stake} chips — nearly everything. Your reward tier gets bumped +1, but a loss costs it all plus a moderate penalty.`
        : `You are pushing ${stake} chips onto the table. Win: a LEGENDARY upgrade. Lose: those chips, plus a SEVERE penalty next round.`;
      g.ui.hide('wager-panel');
      g.ui.show('allin-confirm');
      $('allin-yes').onclick = () => {
        g.ui.hide('allin-confirm');
        this._acceptWager('custom', stake, def);
      };
      $('allin-no').onclick = () => {
        g.ui.hide('allin-confirm');
        g.ui.show('wager-panel');
      };
    } else {
      this._acceptWager('custom', stake, def);
    }
  }

  _acceptWager(level, amount, def) {
    const g = this.game;
    if (level === 'credit') this.houseCreditUsed = true;
    else g.chips -= amount;
    g.stats.gambled += amount;
    this.currentWager = {
      level, amount, tier: def.tier, penalty: def.penalty,
      credit: level === 'credit', riskBump: !!def.riskBump,
    };
    this.updateChipsUI();
    g.saveRun();   // stake is committed — closing the tab won't refund it
    g.ui.hide('wager-panel');
    if (this.gameKind === 'blackjack') { g.setState('BLACKJACK'); this.startBlackjack(); }
    else if (this.gameKind === 'poker') { g.setState('POKER'); this.startPokerHand(); }
    else { g.setState('ROULETTE'); this.startRoulette(); }
  }

  /** result: 'win' | 'loss' | 'push' | 'blackjack' | jackpot flag via opts */
  resolveWager(result, opts = {}) {
    const g = this.game;
    const w = this.currentWager;
    this.currentWager = null;
    g.ui.hideAllPanels();

    // whatever happens, we land back on the intermission screen — this was
    // the soft-lock bug: every panel got hidden and no state resumed.
    g.setState('INTERMISSION');
    g.ui.show('intermission');

    if (result === 'push') {
      if (!w.credit) g.chips += w.amount;   // stake returned
      g.ui.banner('PUSH — stake returned', 'cyan');
      Audio.play('card');
    } else if (result === 'win' || result === 'blackjack') {
      g.stats.wagersWon++;
      // natural blackjack or single-number roulette hit bumps the tier
      let tier = w.tier;
      if ((result === 'blackjack' || opts.tierBump) && tier !== 'legendary') {
        tier = tier === 'common' ? 'rare' : 'legendary';
        g.ui.banner(result === 'blackjack' ? 'BLACKJACK! Reward tier upgraded!' : 'STRAIGHT UP! Reward tier upgraded!', 'gold', 2400);
        Audio.play('jackpot');
      } else {
        Audio.play('wager_win');
      }
      if (!w.credit) g.chips += w.amount * 2;   // even-money chips back
      this.updateChipsUI();
      g.saveRun();
      setTimeout(() => g.upgrades.offer(tier), 500);
      return;
    } else {
      Audio.play('wager_lose');
      this.applyPenalty(w.penalty);
      g.ui.banner('THE HOUSE TAKES IT', 'red');
    }
    this.updateChipsUI();
    g.saveRun();
  }

  // ============================== penalties ==================================
  applyPenalty(kind) {
    const g = this.game;
    // HOUSE MARKER: the house collects — next penalty is one step nastier
    if (g.playerMods.markerDebt > 0 && kind !== 'severe') {
      g.playerMods.markerDebt--;
      kind = kind === 'mild' ? 'moderate' : 'severe';
      g.ui.prompt('THE HOUSE REMEMBERS YOUR MARKER — penalty upgraded', 3000);
    }
    const pool = PENALTIES[kind];
    const p = pick(pool);
    if (p.compound) {
      for (let i = 0; i < p.compound; i++) this.applyPenalty('moderate');
      return;
    }
    if (p.immediate) {
      p.immediate(g);
      g.ui.prompt(`PENALTY: ${p.label}`, 3000);
    } else {
      this.pendingMods.push({ label: p.label, mod: p.mod });
      g.ui.prompt(`PENALTY NEXT ROUND: ${p.label}`, 3000);
    }
    g.ui.updateHUD();
  }

  /** merge queued penalties into this round's mods; called by game.beginRound */
  consumeMods() {
    const merged = {};
    for (const { mod } of this.pendingMods) {
      for (const [k, v] of Object.entries(mod)) {
        if (typeof v === 'number' && typeof merged[k] === 'number') merged[k] *= v;
        else merged[k] = v;
      }
    }
    this.pendingMods = [];
    this.roundMods = merged;
    return merged;
  }

  // ============================== blackjack ==================================
  startBlackjack() {
    const g = this.game;
    this.bj = { deck: newDeck(), player: [], dealer: [], doubled: false, done: false };
    const b = this.bj;
    b.player.push(b.deck.pop(), b.deck.pop());
    b.dealer.push(b.deck.pop(), b.deck.pop());
    this._bjSeen = { p: 0, d: 0 };          // for deal-in animation
    this._holeRevealed = false;
    const panel = $('blackjack-panel');
    panel.classList.remove('win-flash', 'lose-flash', 'push-flash');
    $('bj-wager-info').innerHTML = this._wagerInfoText() + this._stakeChipsHtml();
    $('bj-double').style.display = '';
    g.ui.show('blackjack-panel');
    // card snaps, one per dealt card
    for (let i = 0; i < 4; i++) setTimeout(() => Audio.play('card'), i * 170);

    // debug rigging
    const rig = g.debug.forceBJ;
    if (rig) {
      g.debug.forceBJ = null;
      this._renderBlackjack(false);
      setTimeout(() => this._finishBlackjack(rig === 'win' ? 'win' : rig === 'push' ? 'push' : 'loss'), 1600);
      return;
    }

    if (isBlackjack(b.player)) {
      this._renderBlackjack(true);
      setTimeout(() => this._finishBlackjack(resolveBlackjack(b.player, b.dealer)), 1800);
      return;
    }
    this._renderBlackjack(false);
  }

  bjHit() {
    const b = this.bj;
    if (!b || b.done) return;
    Audio.play('card');
    b.player.push(b.deck.pop());
    $('bj-double').style.display = 'none';
    if (handValue(b.player) > 21) {
      this._renderBlackjack(true);
      setTimeout(() => this._finishBlackjack('loss'), 700);
    } else this._renderBlackjack(false);
  }

  bjStand() {
    const b = this.bj;
    if (!b || b.done) return;
    b.done = 'dealing';                     // lock inputs during the draw-out
    this._renderBlackjack(true);            // flip the hole card first
    const drawNext = () => {
      if (handValue(b.dealer) < 17) {
        b.dealer.push(b.deck.pop());
        Audio.play('card');
        this._renderBlackjack(true);
        setTimeout(drawNext, 620);
      } else {
        b.done = false;
        setTimeout(() => this._finishBlackjack(resolveBlackjack(b.player, b.dealer)), 500);
      }
    };
    setTimeout(drawNext, 750);
  }

  bjDouble() {
    // double down: one card only, stake doubles (if affordable)
    const g = this.game, b = this.bj, w = this.currentWager;
    if (!b || b.done || b.player.length !== 2) return;
    if (!w.credit && g.chips >= w.amount) {
      g.chips -= w.amount;
      g.stats.gambled += w.amount;
      w.amount *= 2;
      this.updateChipsUI();
    }
    Audio.play('card');
    b.player.push(b.deck.pop());
    if (handValue(b.player) > 21) {
      this._renderBlackjack(true);
      setTimeout(() => this._finishBlackjack('loss'), 700);
      return;
    }
    this.bjStand();
  }

  _finishBlackjack(result) {
    if (!this.bj || this.bj.done === true) return;
    this.bj.done = true;
    $('bj-status').textContent =
      result === 'blackjack' ? 'BLACKJACK!' :
      result === 'win' ? 'YOU WIN' :
      result === 'push' ? 'PUSH' : 'THE HOUSE WINS';
    const panel = $('blackjack-panel');
    const rf = this.game.settings.reducedFlash;
    panel.classList.add(
      (result === 'win' || result === 'blackjack') ? (rf ? 'win-steady' : 'win-flash')
      : result === 'push' ? 'push-flash' : (rf ? 'lose-steady' : 'lose-flash'));
    setTimeout(() => this.resolveWager(result), 1400);
  }

  _stakeChipsHtml() {
    const w = this.currentWager;
    if (!w || w.credit) return '';
    const stacks = Math.min(6, 1 + Math.floor(w.amount / 100));
    return `<div class="stake-chips">${'🪙'.repeat(stacks)} <b>${w.amount}</b> on the felt</div>`;
  }

  _renderBlackjack(revealDealer) {
    const b = this.bj;
    const initial = this._bjSeen.p === 0;   // first render: stagger the whole deal
    const cardHtml = (c, hidden, isNew, delay, flip) => {
      const cls = ['pcard'];
      if (hidden) cls.push('back');
      else if (c.suit === '♥' || c.suit === '♦') cls.push('red');
      if (isNew) cls.push('deal');
      if (flip) cls.push('flip');
      const style = delay ? ` style="animation-delay:${delay}ms"` : '';
      return `<span class="${cls.join(' ')}"${style}>${hidden ? '🂠' : c.rank + c.suit}</span>`;
    };
    const flipNow = revealDealer && !this._holeRevealed;
    if (revealDealer) this._holeRevealed = true;

    $('bj-player-cards').innerHTML = b.player.map((c, i) =>
      cardHtml(c, false, initial ? true : i >= this._bjSeen.p, initial ? i * 340 : 0, false)).join('');
    $('bj-dealer-cards').innerHTML = b.dealer.map((c, i) => {
      const hidden = !revealDealer && i === 1;
      return cardHtml(c, hidden, initial ? true : i >= this._bjSeen.d,
        initial ? 170 + i * 340 : 0, flipNow && i === 1);
    }).join('');
    this._bjSeen = { p: b.player.length, d: b.dealer.length };
    if (flipNow) Audio.play('card');

    $('bj-player-value').textContent = handValue(b.player);
    $('bj-dealer-value').textContent = revealDealer ? handValue(b.dealer)
      : (b.dealer.length ? handValue([b.dealer[0]]) + ' + ?' : '');
    if (!b.done) $('bj-status').textContent = handValue(b.player) === 21 ? '21!' : 'Hit or stand?';
  }

  // =============================== roulette ==================================
  startRoulette() {
    const g = this.game;
    this.rouletteBet = null;
    this.spinning = false;
    this.rouHistory = this.rouHistory || [];
    const panel = $('roulette-panel');
    panel.classList.remove('win-flash', 'lose-flash', 'win-steady', 'lose-steady');
    $('rou-wager-info').innerHTML = this._wagerInfoText() + this._stakeChipsHtml();
    $('rou-status').textContent = 'Place your bet.';
    $('rou-spin').disabled = true;
    for (const b of document.querySelectorAll('.rou-bet')) b.classList.remove('selected');
    this._renderRouHistory();
    this._drawWheel(0);
    g.ui.show('roulette-panel');
  }

  _renderRouHistory() {
    const el = $('rou-history');
    if (!this.rouHistory?.length) { el.innerHTML = '<span class="dim small">past spins appear here</span>'; return; }
    el.innerHTML = this.rouHistory.map((h) =>
      `<span class="rou-hist ${h.color}">${h.n}</span>`).join('');
  }

  _selectBet(type, btn) {
    if (this.spinning) return;
    this.rouletteBet = type === 'single'
      ? { type, number: clamp(parseInt($('rou-number').value || '7', 10), 0, 36) }
      : { type };
    for (const b of document.querySelectorAll('.rou-bet')) b.classList.remove('selected');
    btn.classList.add('selected');
    $('rou-status').textContent = type === 'single'
      ? `Straight up on ${this.rouletteBet.number} — a hit upgrades your reward tier!`
      : `Betting ${type.toUpperCase()}.`;
    $('rou-spin').disabled = false;
  }

  spinTheWheel() {
    const g = this.game;
    if (!this.rouletteBet || this.spinning) return;
    this.spinning = true;
    $('rou-spin').disabled = true;

    // pick the result now; rig if the debug panel asked
    let result = spinRoulette();
    const rig = g.debug.forceRoulette;
    if (rig) {
      g.debug.forceRoulette = null;
      for (let i = 0; i < 500; i++) {
        result = spinRoulette();
        const won = evaluateRouletteBet(this.rouletteBet, result.number);
        if ((rig === 'win') === won) break;
      }
    }

    // animate: wheel turns one way, the ball whips the other way, both
    // easing out so the ball drops into the winning pocket at the pointer
    const target = result.index;
    const turns = 4;
    const finalAngle = turns * Math.PI * 2 + (target / 37) * Math.PI * 2;
    const ballTurns = 7;
    const dur = 3.6;
    const t0 = performance.now();
    let lastTickPocket = -1;
    const anim = () => {
      const t = Math.min(1, (performance.now() - t0) / (dur * 1000));
      const ease = 1 - Math.pow(1 - t, 3);         // wheel: cubic ease-out
      const easeBall = 1 - Math.pow(1 - t, 4);     // ball: eases out later
      const angle = finalAngle * ease;
      // ball ends exactly at the top pointer (-PI/2), where the pocket lands
      const ballAngle = -Math.PI / 2 - (1 - easeBall) * ballTurns * Math.PI * 2;
      // ball spirals inward as it slows, like the real thing
      const ballR = 0.98 - 0.16 * t;
      this._drawWheel(angle, ballAngle, ballR);
      const pocket = Math.floor(((angle / (Math.PI * 2)) % 1) * 37);
      if (pocket !== lastTickPocket) { Audio.play('wheel_tick'); lastTickPocket = pocket; }
      if (t < 1) requestAnimationFrame(anim);
      else this._rouletteLanded(result);
    };
    requestAnimationFrame(anim);
  }

  _rouletteLanded(result) {
    const won = evaluateRouletteBet(this.rouletteBet, result.number);
    const color = pocketColor(result.number);
    $('rou-status').textContent = `${result.number} ${color.toUpperCase()} — ${won ? 'YOU WIN' : 'THE HOUSE WINS'}`;
    this.rouHistory.unshift({ n: result.number, color });
    this.rouHistory = this.rouHistory.slice(0, 10);
    this._renderRouHistory();
    const rf = this.game.settings.reducedFlash;
    $('roulette-panel').classList.add(won ? (rf ? 'win-steady' : 'win-flash') : (rf ? 'lose-steady' : 'lose-flash'));
    const tierBump = won && this.rouletteBet.type === 'single';
    setTimeout(() => {
      this.spinning = false;
      this.resolveWager(won ? 'win' : 'loss', { tierBump });
    }, 1500);
  }

  _drawWheel(angle, ballAngle = null, ballR = 0.85) {
    const cv = $('roulette-canvas');
    const ctx = cv.getContext('2d');
    const cx = cv.width / 2, cy = cv.height / 2, R = cv.width / 2 - 8;
    ctx.clearRect(0, 0, cv.width, cv.height);
    const seg = (Math.PI * 2) / 37;
    for (let i = 0; i < 37; i++) {
      const n = WHEEL_ORDER[i];
      const a0 = -Math.PI / 2 + i * seg - angle;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, R, a0, a0 + seg);
      const c = pocketColor(n);
      ctx.fillStyle = c === 'green' ? '#0f7a3d' : c === 'red' ? '#b3122e' : '#15151d';
      ctx.fill();
      // number labels
      const mid = a0 + seg / 2;
      ctx.save();
      ctx.translate(cx + Math.cos(mid) * (R - 16), cy + Math.sin(mid) * (R - 16));
      ctx.rotate(mid + Math.PI / 2);
      ctx.fillStyle = '#e8e2d0';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(String(n), 0, 0);
      ctx.restore();
    }
    // hub + pointer
    ctx.beginPath(); ctx.arc(cx, cy, 26, 0, Math.PI * 2);
    ctx.fillStyle = '#c9a227'; ctx.fill();
    ctx.beginPath();
    ctx.moveTo(cx - 8, 6); ctx.lineTo(cx + 8, 6); ctx.lineTo(cx, 24);
    ctx.fillStyle = '#e8e2d0'; ctx.fill();
    // the ball
    if (ballAngle !== null) {
      const bx = cx + Math.cos(ballAngle) * R * ballR;
      const by = cy + Math.sin(ballAngle) * R * ballR;
      ctx.beginPath(); ctx.arc(bx, by, 7, 0, Math.PI * 2);
      ctx.fillStyle = '#f5f5f5'; ctx.fill();
      ctx.beginPath(); ctx.arc(bx - 2, by - 2, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff'; ctx.fill();
    }
  }

  // ========================= poker: five card draw ===========================
  // Fixed 100-chip ante. Beat the dealer and your HAND RANK sets the upgrade
  // tier: pair or less = COMMON, two pair-straight = RARE, flush+ = LEGENDARY.
  // Lose and it's a moderate penalty. One draw, hold what you like.
  startPokerHand() {
    const g = this.game;
    const w = this.currentWager;
    const deck = newDeck();
    this.poker = {
      deck,
      player: [deck.pop(), deck.pop(), deck.pop(), deck.pop(), deck.pop()],
      dealer: [deck.pop(), deck.pop(), deck.pop(), deck.pop(), deck.pop()],
      held: [false, false, false, false, false],
      phase: 'draw',
    };
    const panel = $('poker-panel');
    panel.classList.remove('win-flash', 'lose-flash', 'push-flash', 'win-steady', 'lose-steady');
    $('poker-wager-info').innerHTML =
      (w.credit ? 'HOUSE CREDIT hand — your final HAND RANK sets the reward tier'
        : `${w.amount} chip ante — your final HAND RANK sets the reward tier`
          + (w.riskBump ? ' <span class="gold">(+1 tier, big-risk ante)</span>' : ''))
      + this._stakeChipsHtml();
    $('poker-status').textContent = 'Click cards to HOLD, then draw.';
    $('poker-draw').disabled = false;
    this._renderPoker(false, true);
    g.ui.show('poker-panel');
    for (let i = 0; i < 5; i++) setTimeout(() => Audio.play('card'), i * 140);
  }

  _renderPoker(revealDealer, initial = false) {
    const pk = this.poker;
    const card = (c, i, hidden, clickable, held, dealDelay) => {
      const cls = ['pcard'];
      if (hidden) cls.push('back');
      else if (c.suit === '♥' || c.suit === '♦') cls.push('red');
      if (clickable) cls.push('clickable');
      if (held) cls.push('held');
      if (dealDelay !== null) cls.push('deal');
      const style = dealDelay ? ` style="animation-delay:${dealDelay}ms"` : '';
      return `<span class="${cls.join(' ')}" data-idx="${i}"${style}>${hidden ? '🂠' : c.rank + c.suit}</span>`;
    };
    $('poker-player-cards').innerHTML = pk.player.map((c, i) =>
      card(c, i, false, pk.phase === 'draw', pk.held[i], initial ? i * 140 : null)).join('');
    $('poker-dealer-cards').innerHTML = pk.dealer.map((c, i) =>
      card(c, i, !revealDealer, false, false, initial ? 70 + i * 140 : (revealDealer && !this._pokerRevealed ? 0 : null))).join('');
    if (revealDealer && !this._pokerRevealed) {
      this._pokerRevealed = true;
      for (const el of document.querySelectorAll('#poker-dealer-cards .pcard')) el.classList.add('flip');
      Audio.play('card');
    }
    if (!revealDealer) this._pokerRevealed = false;
    // hold toggles
    if (pk.phase === 'draw') {
      for (const el of document.querySelectorAll('#poker-player-cards .pcard')) {
        el.onclick = () => {
          const i = parseInt(el.dataset.idx, 10);
          pk.held[i] = !pk.held[i];
          Audio.play('card');
          this._renderPoker(false);
        };
      }
    }
  }

  pokerDraw() {
    const g = this.game, pk = this.poker;
    if (!pk || pk.phase !== 'draw') return;
    pk.phase = 'showdown';
    $('poker-draw').disabled = true;
    // player draw
    let drew = 0;
    for (let i = 0; i < 5; i++) if (!pk.held[i]) { pk.player[i] = pk.deck.pop(); drew++; }
    // dealer AI draw
    const holds = dealerHolds(pk.dealer);
    for (let i = 0; i < 5; i++) if (!holds[i]) pk.dealer[i] = pk.deck.pop();
    for (let i = 0; i < Math.max(1, drew); i++) setTimeout(() => Audio.play('card'), i * 130);
    this._renderPoker(false);
    $('poker-status').textContent = drew ? `Drew ${drew}. The dealer draws...` : 'Standing pat. The dealer draws...';

    setTimeout(() => {
      const pe = evaluatePokerHand(pk.player);
      const de = evaluatePokerHand(pk.dealer);
      const cmp = comparePoker(pe, de);
      this._renderPoker(true);
      $('poker-status').textContent = `Your ${pe.name} vs the dealer's ${de.name}`;
      const rf = g.settings.reducedFlash;
      const panel = $('poker-panel');
      setTimeout(() => {
        if (cmp > 0) {
          let tier = pokerTier(pe.rank);
          if (this.currentWager.riskBump) {
            tier = tier === 'common' ? 'rare' : 'legendary';
          }
          this.currentWager.tier = tier;
          panel.classList.add(rf ? 'win-steady' : 'win-flash');
          $('poker-status').textContent = `${pe.name} WINS — ${this.currentWager.tier.toUpperCase()} reward!`;
          setTimeout(() => this.resolveWager('win'), 1300);
        } else if (cmp < 0) {
          panel.classList.add(rf ? 'lose-steady' : 'lose-flash');
          setTimeout(() => this.resolveWager('loss'), 1300);
        } else {
          panel.classList.add('push-flash');
          setTimeout(() => this.resolveWager('push'), 1300);
        }
      }, 1300);
    }, 1400);
  }

  // ===================== slots: 5x5, 7 paylines, runs pay ====================
  openSlots() {
    const g = this.game;
    g.setState('SLOTS');
    this.slotGrid = null;
    $('slots-status').textContent = `Pull the arm — ${CONFIG.slots.price} chips a spin. 7 paylines, runs of 3+ pay (x1 / x3 / x10).`;
    this._renderSlotGrid(null);
    $('slots-respin-row').style.display = 'none';
    this.updateChipsUI();
    g.ui.hide('intermission');
    g.ui.show('slots-panel');
  }

  /** cells are laid out column-major: index = col*5 + row */
  _renderSlotGrid(grid, winCells = []) {
    const winSet = new Set(winCells.map(([c, r]) => c * 5 + r));
    let html = '';
    for (let c = 0; c < 5; c++) {
      for (let r = 0; r < 5; r++) {
        const sym = grid ? grid[c][r] : '❔';
        const idx = c * 5 + r;
        const rf = this.game.settings.reducedFlash;
        html += `<span class="cell${winSet.has(idx) ? (rf ? ' win-steady-cell' : ' win') : ''}${r === 2 ? ' mid' : ''}">${sym}</span>`;
      }
    }
    $('slots-reels').innerHTML = html;
  }

  slotsSpin() {
    const g = this.game;
    if (this.slotSpinning) return;
    if (g.chips < CONFIG.slots.price) { Audio.play('dryfire'); $('slots-status').textContent = 'Not enough chips.'; return; }
    g.chips -= CONFIG.slots.price;
    g.stats.gambled += CONFIG.slots.price;
    this.updateChipsUI();
    $('slots-status').textContent = '...';
    this._animateSlots(spinGrid5(), () => this._slotsSettle());
  }

  slotsRespin(col) {
    if (this.slotSpinning || this.slotRespinUsed || !this.slotGrid) return;
    this.slotRespinUsed = true;
    const grid = this.slotGrid.map((c) => [...c]);
    grid[col] = Array.from({ length: 5 }, () => spinReel());
    this._animateSlots(grid, () => this._slotsSettle(), col);
  }

  _animateSlots(finalGrid, onDone, onlyCol = null) {
    this.slotSpinning = true;
    let ticks = 0;
    const iv = setInterval(() => {
      ticks++;
      Audio.play('slot_spin');
      // columns stop left to right: col c locks at tick 6 + c*4
      const rolling = [0, 1, 2, 3, 4].map((c) => (onlyCol !== null && c !== onlyCol) ? false : ticks < 6 + c * 4);
      const shown = finalGrid.map((colSyms, c) =>
        rolling[c] ? Array.from({ length: 5 }, () => spinReel()) : colSyms);
      this._renderSlotGrid(shown);
      if (!rolling.some(Boolean)) {
        clearInterval(iv);
        this.slotGrid = finalGrid;
        this.slotSpinning = false;
        onDone();
      }
    }, 85);
  }

  _slotsSettle() {
    const g = this.game;
    const res = evalSlotsGrid5(this.slotGrid);
    const winCells = res.wins.flatMap((w) => w.cells);
    this._renderSlotGrid(this.slotGrid, winCells);
    $('slots-status').textContent = res.wins.length
      ? res.wins.map((w) => `${w.name}: ${w.label}`).join('  ·  ')
      : 'No runs. The house smiles.';
    const fiveOfSevens = res.wins.some((w) => w.sym === '7' && w.len === 5);
    if (fiveOfSevens || res.chips >= 400) Audio.play('jackpot');
    else if (res.chips > 0 || res.heal || res.ammoUnits) Audio.play('wager_win');
    else if (res.hurt) Audio.play('hurt');
    if (res.chips) g.addChips(res.chips);
    if (res.heal) g.player.heal(res.heal);
    if (res.ammoUnits >= 3) g.weapons.refillAll();
    else if (res.ammoUnits > 0) g.weapons.addReservePct(0.35 * res.ammoUnits);
    if (res.hurt) { g.player.hp = Math.max(1, g.player.hp - res.hurt); } // slots can't kill you
    this.updateChipsUI();
    g.ui.updateHUD();
    g.saveRun();
    $('slots-respin-row').style.display = this.slotRespinUsed ? 'none' : '';
  }

  closeSlots() {
    this.game.ui.hide('slots-panel');
    this.game.setState('INTERMISSION');
    this.game.ui.show('intermission');
  }

  // ============================= wiring ======================================
  _wagerInfoText() {
    const w = this.currentWager;
    if (!w) return '';
    return w.credit
      ? `HOUSE CREDIT — win a ${w.tier.toUpperCase()} upgrade, lose for a ${w.penalty} penalty`
      : `${w.amount} chips on the line — win a ${w.tier.toUpperCase()} upgrade (+chips back), lose for a ${w.penalty} penalty`;
  }

  _wireStaticButtons() {
    const g = this.game;
    const S = CONFIG.shop;
    $('buy-small-heal').onclick = () => this._buy(this.price(S.smallHeal.price), () => g.player.heal(S.smallHeal.amount));
    $('buy-full-heal').onclick = () => this._buy(this.price(S.fullHeal.price), () => g.player.heal(999));
    $('buy-ammo').onclick = () => this._buy(this.price(S.ammo.price), () => g.weapons.refillAll());
    $('buy-armor').onclick = () => this._buy(this.price(S.armor.price), () => g.player.addArmor(S.armor.amount));
    $('buy-grenade').onclick = () => {
      if (g.player.grenades >= g.playerMods.grenadeMax) { g.ui.prompt('Grenade pouch is full.'); return; }
      this._buy(this.price(S.grenade.price), () => { g.player.grenades++; });
    };
    $('buy-rifle').onclick = () => this._buy(this.price(S.rifleUnlock.price), () => {
      g.weapons.unlock('rifle');
      this._refreshShopButtons();
    });

    $('btn-blackjack').onclick = () => this.openWagerPanel('blackjack');
    $('btn-roulette').onclick = () => this.openWagerPanel('roulette');
    $('btn-slots').onclick = () => this.openSlots();
    $('btn-poker').onclick = () => this.openWagerPanel('poker');
    $('poker-draw').onclick = () => this.pokerDraw();
    $('btn-skip-gamble').onclick = () => this.startNextRound();
    $('wager-slider').oninput = () => this._updateStakeReadout();
    $('wager-confirm').onclick = () => this._confirmStake();
    for (const b of document.querySelectorAll('.wq')) {
      b.onclick = () => {
        const g = this.game, slider = $('wager-slider');
        const minBet = parseInt(slider.min, 10);
        const q = b.dataset.q;
        slider.value = q === 'min' ? minBet
          : q === 'quarter' ? Math.max(minBet, Math.round(g.chips * 0.25 / 10) * 10)
          : q === 'half' ? Math.max(minBet, Math.round(g.chips * 0.5 / 10) * 10)
          : g.chips;
        this._updateStakeReadout();
      };
    }
    $('wager-back').onclick = () => {
      g.ui.hide('wager-panel');
      g.ui.show('intermission');
    };

    $('bj-hit').onclick = () => this.bjHit();
    $('bj-stand').onclick = () => this.bjStand();
    $('bj-double').onclick = () => this.bjDouble();

    for (const b of document.querySelectorAll('.rou-bet')) {
      b.onclick = () => this._selectBet(b.dataset.bet, b);
    }
    $('rou-spin').onclick = () => this.spinTheWheel();

    $('slots-spin').onclick = () => this.slotsSpin();
    $('slots-close').onclick = () => this.closeSlots();
    for (const b of document.querySelectorAll('.respin-btn')) {
      b.onclick = () => this.slotsRespin(parseInt(b.dataset.reel, 10));
    }
  }
}
