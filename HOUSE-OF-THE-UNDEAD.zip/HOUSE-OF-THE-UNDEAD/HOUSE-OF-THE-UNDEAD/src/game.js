// game.js — the orchestrator. Owns THREE scene/camera/renderer, the state
// machine, the round loop, chips + the NEW combo multiplier, boss spawns,
// menus, and the render loop.

import * as THREE from 'three';

import { CONFIG, clamp } from './config.js';
import { Audio } from './audio.js';
import { UI } from './ui.js';
import { Player } from './player.js';
import { Arena } from './arena.js';
import { Pickups } from './pickups.js';
import { Weapons } from './weapons.js';
import { Enemies } from './enemies.js';
import { Casino } from './casino.js';
import { Upgrades } from './upgrades.js';
import { Effects } from './effects.js';
import { Vault } from './vault.js';
import { PitBoss, HouseDealer } from './bosses.js';

const $ = (id) => document.getElementById(id);

// deterministic PRNG for daily runs — same date, same run, worldwide
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function hashStr(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
const todayStr = () => new Date().toISOString().slice(0, 10);

// special round modifiers — rolled on non-boss rounds 3+ (40% chance)
const SPECIAL_ROUNDS = [
  { name: 'HIGH STAKES', desc: 'Double chips. Half mercy.', minRound: 3,
    mods: { dmgMult: 1.5 }, chipMult: 2 },
  { name: 'BLACKOUT', desc: 'The power is out. They can smell you.', minRound: 3,
    mods: { lowLight: true, speedMult: 1.1 }, chipMult: 1.25 },
  { name: 'RUSH HOUR', desc: 'Valet shift change. All of them. At once.', minRound: 3,
    mods: { onlyKinds: ['sprinter'], countMult: 1.45 }, chipMult: 1.5 },
  { name: 'HEAVYWEIGHT NIGHT', desc: 'The big boys are on shift.', minRound: 6,
    mods: { heavyMix: true, countMult: 0.7 }, chipMult: 1.6 },
  { name: 'VIP NIGHT', desc: 'Every guest is a whale. Golden. Dangerous.', minRound: 5,
    mods: { elite: true, countMult: 0.65 }, chipMult: 2 },
];

// optional round objectives — complete for a bonus, no penalty for missing
const OBJECTIVES = [
  { key: 'headhunter', label: (o) => `◎ HEADHUNTER — ${o.progress}/8 headshots`, goal: 8,
    reward: (g) => { g.addChips(120); return '+120 chips'; } },
  { key: 'untouchable', label: (o) => o.failed ? '✗ UNTOUCHABLE — failed' : '◎ UNTOUCHABLE — take no damage', goal: 0,
    reward: (g) => { g.addChips(150); g.player.heal(15); return '+150 chips, +15 HP'; } },
  { key: 'demolition', label: (o) => `◎ DEMOLITION DERBY — ${o.progress}/6 explosion kills`, goal: 6,
    reward: (g) => {
      g.player.grenades = Math.min(g.playerMods.grenadeMax, g.player.grenades + 2);
      g.addChips(80); return '+2 chip bombs, +80 chips';
    } },
  { key: 'speedclear', label: (o) => `◎ SPEED CLEAR — ${Math.max(0, Math.ceil(60 - o.time))}s left`, goal: 0,
    reward: (g) => { g.addChips(100); return '+100 chips'; } },
];

export class Game {
  constructor() {
    // --- three.js core ---
    const canvas = document.getElementById('game-canvas');
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    this.renderer.setSize(innerWidth, innerHeight);
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(CONFIG.player.fov, innerWidth / innerHeight, 0.1, 200);
    this.scene.add(this.camera);

    // --- game state ---
    this.state = 'MENU';
    this.round = 0;
    this.chips = 0;
    this.debug = { invuln: false, forceBJ: null, forceRoulette: null, show: false };
    this.settings = {};   // populated by UI
    this.stats = this._freshStats();
    this.combo = 0;
    this.comboT = 0;
    this.bosses = [];
    this._countdownT = 0;
    this.specialRound = null;
    this.playerMods = this._freshPlayerMods();

    // --- systems (order matters: ui first for settings) ---
    this.ui = new UI(this);
    this.player = new Player(this);
    this.arena = new Arena(this);
    this.pickups = new Pickups(this);
    this.weapons = new Weapons(this);
    this.enemies = new Enemies(this);
    this.casino = new Casino(this);
    this.upgrades = new Upgrades(this);
    this.effects = new Effects(this);
    this.vault = new Vault(this);
    this.shakeAmp = 0;
    this.slowmoT = 0;
    this._audioMeterT = 0;
    this._fwd = new THREE.Vector3();
    this.dashBuffT = 0;
    this.objective = null;
    this.mode = 'normal';           // 'normal' | 'daily'
    this._realRandom = null;
    this.beatHouse = false;         // cleared round 10 this run -> endless floor
    this.grudge = this._loadGrudge();

    this._wireMenus();
    this._refreshMenu();
    addEventListener('resize', () => {
      this.renderer.setSize(innerWidth, innerHeight);
      this.camera.aspect = innerWidth / innerHeight;
      this.camera.updateProjectionMatrix();
    });

    // --- loop ---
    this.clock = new THREE.Clock();
    this._errCount = 0;
    this.renderer.setAnimationLoop(() => {
      // crash guard: a single bad frame should never hard-freeze the game
      try {
        this._tick();
        this._errCount = 0;
      } catch (err) {
        this._errCount++;
        console.error('[HOTU] frame error:', err);
        if (this._errCount > 60) {
          // something is genuinely broken — bail to menu instead of freezing
          this.renderer.setAnimationLoop(null);
          alert('HOUSE OF THE UNDEAD hit a fatal error — check the console (F12). ' + err.message);
        }
      }
    });
  }

  _freshStats() {
    return { kills: 0, headshots: 0, bestCombo: 0, gambled: 0, wagersWon: 0 };
  }

  _freshPlayerMods() {
    return {
      speed: 1,        // Running Shoes
      dashCd: 1,       // Quick Hands
      meleeDmg: 1,     // Steel Toe
      magnet: 1,       // Chip Magnet
      roundArmor: 0,   // Casino Insurance
      interest: 0,     // Card Counter: chips every intermission
      // per-run copies of values legendary cards used to mutate on CONFIG —
      // that leaked across runs (Demolition/Marked Cards were permanent). Fixed.
      grenadeMax: CONFIG.grenade.max,
      headshotBonus: CONFIG.chips.headshotBonus,
      // cursed upgrades (power with a downside)
      dmgAllMult: 1,        // Blood Pact
      critAdd: 0,           // Glass Cannon
      chipPickupMult: 1,    // Loaded Dice
      hitChipLoss: 0,       // Loaded Dice downside
      armorDisabled: false, // Glass Cannon downside
      reloadHpCost: 0,      // Devil's Reload
      markerDebt: 0,        // House Marker: next penalty upgraded
      // synergy attachments
      dashDamage: false,    // Dash & Cash
      critGrenade: false,   // Crit Comptroller
      chipHeal: false,      // Vampire Chips
      lastBullet: false,    // Last Call
      comboWindowAdd: 0,    // Combo Insurance
    };
  }

  // ------------------------------ state ------------------------------------
  setState(s) {
    this.state = s;
    if (s !== 'COMBAT' && s !== 'COUNTDOWN') $('radar')?.classList.add('hidden');
    if (s === 'COMBAT' || s === 'COUNTDOWN') this.ui.requestPointer();
    else if (document.pointerLockElement) document.exitPointerLock();
  }

  pause() {
    if (this.state !== 'COMBAT' && this.state !== 'COUNTDOWN') return;
    this._stateBeforePause = this.state;
    this.setState('PAUSED');
    this.ui.show('pause-menu');
  }

  resume() {
    this.ui.hide('pause-menu');
    this.setState(this._stateBeforePause || 'COMBAT');
  }

  // ------------------------------ chips + combo -----------------------------
  addChips(n) {
    if (this.specialRound && this.state === 'COMBAT') n = Math.round(n * this.specialRound.chipMult);
    this.chips += n;
    this.ui.updateHUD();
    if (this.state === 'INTERMISSION' || this.state === 'SLOTS') this.casino.updateChipsUI();
  }

  /** positional sound with cheap occlusion: muffled if cover blocks the line */
  audioAt(name, pos, bus = 'sfx') {
    const muffled = this.arena.lineBlocked(this.player.pos, pos);
    Audio.playAt(name, pos, { muffled, bus });
  }

  /** screen shake — amplitude decays exponentially */
  addShake(a) {
    this.shakeAmp = Math.min(0.45, this.shakeAmp + a);
  }

  /** brief slow motion (real-time seconds) */
  slowmo(seconds) {
    this.slowmoT = Math.max(this.slowmoT, seconds);
  }

  /** boss rounds: 5, 10, then every 5th in endless */
  isBossRound(r = this.round) {
    return r === CONFIG.minibossRound || r === CONFIG.finalRound
      || (r > CONFIG.finalRound && r % 5 === 0);
  }

  // ------------------------- boss grudges (persistent) ----------------------
  _loadGrudge() {
    try { return JSON.parse(localStorage.getItem('hotu_grudge_v1') || 'null') || { pitboss: 0, housedealer: 0 }; }
    catch { return { pitboss: 0, housedealer: 0 }; }
  }

  _saveGrudge() {
    try { localStorage.setItem('hotu_grudge_v1', JSON.stringify(this.grudge)); } catch { /* fine */ }
  }

  // ------------------------------ daily run ---------------------------------
  _loadDaily() {
    try { const d = JSON.parse(localStorage.getItem('hotu_daily_v1') || 'null'); return d || {}; }
    catch { return {}; }
  }

  _saveDaily(d) {
    try { localStorage.setItem('hotu_daily_v1', JSON.stringify(d)); } catch { /* fine */ }
  }

  dailyScore() {
    return this.round * 1000 + this.chips + this.stats.kills * 10 + (this.beatHouse ? 5000 : 0);
  }

  startDaily() {
    const daily = this._loadDaily();
    if (daily.date === todayStr() && daily.played) {
      this.ui.prompt(`Today's daily is done — score ${daily.score}. New seed at midnight.`);
      return;
    }
    // one attempt: mark it played the moment the doors open
    this._saveDaily({ date: todayStr(), played: true, score: 0 });
    this.clearSave();
    this._realRandom = Math.random;
    Math.random = mulberry32(hashStr('HOTU-DAILY-' + todayStr()));
    this.mode = 'daily';
    this._resetRun(false);          // level field: no vault perks on dailies
    this.round = 1;
    this.beginRound();
    this.ui.banner(`⚡ DAILY RUN — ${todayStr()} — one attempt, no perks, same seed for everyone`, 'cyan', 3200);
  }

  _endDailyMode(finalScore = null) {
    if (this.mode === 'daily') {
      if (finalScore !== null) this._saveDaily({ date: todayStr(), played: true, score: finalScore });
      if (this._realRandom) { Math.random = this._realRandom; this._realRandom = null; }
      this.mode = 'normal';
    }
  }

  comboMult() {
    if (this.combo < 2) return 1;
    return Math.min(CONFIG.chips.comboMaxMult, 1 + CONFIG.chips.comboStep * (this.combo - 1));
  }

  onKill(zombie) {
    this.stats.kills++;
    this.combo++;
    if (zombie.kind === 'jackpot') {
      this.ui.banner('JACKPOT CASHED OUT!', 'gold', 2000);
      Audio.play('jackpot');
    }
    if (this.objective?.def.key === 'demolition' && zombie.lastCause === 'explosion') {
      this.objective.progress++;
    }
    // last kill of the round: brief slow-mo + shake
    const alive = this.enemies.list.filter((z) => !z.dead).length + this.enemies.spawnQueue.length;
    const bossesAlive = this.bosses.some((b) => !b.dead);
    if (alive === 0 && !bossesAlive && this.state === 'COMBAT') {
      this.slowmo(0.7);
      this.addShake(0.12);
    }
    this.comboT = CONFIG.chips.comboWindow + this.playerMods.comboWindowAdd;
    if (this.combo > this.stats.bestCombo) this.stats.bestCombo = this.combo;
    if (this.combo === 5) this.ui.banner('HOT STREAK x' + this.comboMult().toFixed(2), 'cyan', 1200);
    if (this.combo === 10) this.ui.banner('ON FIRE! MAX CHIP MULTIPLIER', 'gold', 1500);
  }

  // ------------------------------- run flow ---------------------------------
  _resetRun(applyPerks = true) {
    this.ui.hideAllPanels();
    this.beatHouse = false;
    this.stats = this._freshStats();
    this.playerMods = this._freshPlayerMods();
    this.chips = 0;
    this.combo = 0;
    this.specialRound = null;
    this.bosses.forEach((b) => { if (b.mesh) this.scene.remove(b.mesh); });
    this.bosses = [];
    this.player.reset();
    this.weapons.reset();
    this.enemies.clearAll();
    this.pickups.clear();
    this.effects.clear();
    this.shakeAmp = 0;
    this.slowmoT = 0;
    this.casino.reset();
    this.upgrades.reset();
    this.arena.setRedAlert(false);
    this.arena.setLowLight(false);
    Audio.setBossMode(false);

    // ---- vault perks: every run starts with what you've banked for ----
    if (applyPerks) {
      const v = this.vault;
      this.playerMods.grenadeMax += v.value('pockets', 0);
      this.player.grenades += v.value('pockets', 0);
      this.player.addArmor(v.value('kevlar', 0));
      this.chips = v.value('front', 0);
      if (v.value('locker', false)) this.weapons.arsenal.rifle.locked = false;
    }
    this.vaultStartChips = this.chips;   // Front Money can't be re-deposited (farm fix)
  }

  newRun() {
    this._endDailyMode();
    this.clearSave();
    this._resetRun();
    this.round = 1;
    this.beginRound();
  }

  // ------------------------- mid-run save (localStorage) --------------------
  saveRun() {
    if (this.round < 1 || this.mode === 'daily') return;   // dailies are one attempt
    const arsenal = {};
    for (const [id, w] of Object.entries(this.weapons.arsenal)) {
      arsenal[id] = { locked: w.locked, mag: w.mag, reserve: w.reserve, mods: { ...w.mods } };
    }
    const data = {
      v: 1,
      round: this.round,
      chips: this.chips,
      player: {
        hp: this.player.hp, maxHp: this.player.maxHp,
        armor: this.player.armor, grenades: this.player.grenades,
      },
      playerMods: { ...this.playerMods },
      currentWeapon: this.weapons.currentId,
      arsenal,
      upgradesOwned: { ...this.upgrades.owned },
      pendingMods: this.casino.pendingMods,
      houseCreditUsed: this.casino.houseCreditUsed,
      stats: { ...this.stats },
      vaultStartChips: this.vaultStartChips || 0,
      beatHouse: this.beatHouse,
    };
    try { localStorage.setItem('hotu_run_save_v1', JSON.stringify(data)); } catch { /* private mode */ }
  }

  _loadSave() {
    try {
      const d = JSON.parse(localStorage.getItem('hotu_run_save_v1') || 'null');
      return d && d.v === 1 ? d : null;
    } catch { return null; }
  }

  clearSave() {
    try { localStorage.removeItem('hotu_run_save_v1'); } catch { /* fine */ }
  }

  continueRun() {
    const d = this._loadSave();
    if (!d) return;
    this._endDailyMode();
    this._resetRun();
    this.round = d.round;
    this.chips = d.chips;
    this.playerMods = { ...this._freshPlayerMods(), ...d.playerMods };
    this.player.hp = d.player.hp;
    this.player.maxHp = d.player.maxHp;
    this.player.armor = d.player.armor;
    this.player.grenades = d.player.grenades;
    for (const [id, wd] of Object.entries(d.arsenal || {})) {
      const w = this.weapons.arsenal[id];
      if (!w) continue;
      w.locked = wd.locked;
      w.mods = { ...w.mods, ...wd.mods };
      w.mag = wd.mag;
      w.reserve = wd.reserve;
    }
    if (this.weapons.arsenal[d.currentWeapon] && !this.weapons.arsenal[d.currentWeapon].locked) {
      this.weapons.currentId = d.currentWeapon;
    }
    this.weapons._refreshViewmodel();
    this.upgrades.owned = { ...d.upgradesOwned };
    this.casino.pendingMods = d.pendingMods || [];
    this.stats = { ...this._freshStats(), ...d.stats };
    this.vaultStartChips = d.vaultStartChips || 0;
    this.beatHouse = !!d.beatHouse;
    this.setState('INTERMISSION');
    this.casino.beginIntermission();
    this.casino.houseCreditUsed = !!d.houseCreditUsed;   // after: beginIntermission resets it
    this.ui.updateHUD();
    this.ui.banner(`WELCOME BACK — ROUND ${this.round + 1} AWAITS`, 'gold', 2400);
  }

  /** main-menu chrome: continue button + vault balance */
  _refreshMenu() {
    const save = this._loadSave();
    const cont = $('btn-continue');
    cont.classList.toggle('hidden', !save);
    if (save) cont.textContent = `CONTINUE RUN — ROUND ${save.round + 1}`;
    $('btn-vault').textContent = `🏦 THE VAULT — ${this.vault.banked} banked`;
    const daily = this._loadDaily();
    const done = daily.date === todayStr() && daily.played;
    const btn = $('btn-daily');
    btn.disabled = done;
    btn.textContent = done
      ? `⚡ DAILY DONE — SCORE ${daily.score}`
      : `⚡ DAILY RUN — ${todayStr()}`;
  }

  startNextRound() {
    this.round++;
    this.beginRound();
  }

  beginRound() {
    const mods = this.casino.consumeMods();

    // roll an optional objective on non-boss rounds 2+ (50%)
    this.objective = null;
    const isBoss = this.isBossRound();
    mods.bossRound = isBoss;
    if (!isBoss && this.round >= 2 && Math.random() < 0.5) {
      const def = OBJECTIVES[Math.floor(Math.random() * OBJECTIVES.length)];
      this.objective = { def, progress: 0, failed: false, time: 0, startHeadshots: this.stats.headshots };
    }

    // roll a special round on non-boss rounds 3+
    this.specialRound = null;
    if (!isBoss && this.round >= 3 && Math.random() < 0.4) {
      const pool = SPECIAL_ROUNDS.filter((sp) => this.round >= sp.minRound);
      this.specialRound = pool[Math.floor(Math.random() * pool.length)];
      for (const [k, v] of Object.entries(this.specialRound.mods)) {
        if (typeof v === 'number' && typeof mods[k] === 'number') mods[k] *= v;
        else mods[k] = v;
      }
    }
    this.arena.setLowLight(!!mods.lowLight);
    this.enemies.buildRound(this.round, mods);
    this.pickups.clear();
    if (this.playerMods.roundArmor > 0) this.player.addArmor(this.playerMods.roundArmor);

    let bossKind = null;
    if (this.round === CONFIG.minibossRound) bossKind = 'pitboss';
    else if (this.round === CONFIG.finalRound) bossKind = 'housedealer';
    else if (isBoss) bossKind = Math.random() < 0.5 ? 'pitboss' : 'housedealer';   // endless

    const spawnBoss = () => {
      this.bosses.push(bossKind === 'pitboss' ? new PitBoss(this) : new HouseDealer(this));
    };

    if (isBoss) {
      // dramatic intro card first
      const final = bossKind === 'housedealer';
      const grudgeN = this.grudge[bossKind] || 0;
      $('boss-intro-title').textContent = final ? 'THE HOUSE DEALER' : 'THE PIT BOSS';
      $('boss-intro-sub').textContent = this.round > CONFIG.finalRound
        ? `Endless floor, round ${this.round}. Management is upset.${grudgeN ? ` And they remember you — ${grudgeN} debt${grudgeN === 1 ? '' : 's'} unpaid.` : ''}`
        : (final
          ? `Round 10. The house always wins. Prove it wrong.${grudgeN ? ` (He's beaten you ${grudgeN} time${grudgeN === 1 ? '' : 's'}.)` : ''}`
          : `Round 5. He handles "problem players" personally.${grudgeN ? ` You two have history — ${grudgeN} loss${grudgeN === 1 ? '' : 'es'}.` : ''}`);
      this.ui.hideAllPanels();
      this.ui.show('boss-intro');
      Audio.play('boss_phase');
      setTimeout(() => {
        this.ui.hide('boss-intro');
        spawnBoss();
        this._startCountdown();
      }, 2200);
    } else {
      this._startCountdown();
      if (this.specialRound) {
        this.ui.banner(`★ ${this.specialRound.name} ★ — ${this.specialRound.desc}`, 'gold', 3000);
        Audio.play('warn');
      }
    }
  }

  _startCountdown() {
    this.setState('COUNTDOWN');
    this._countdownT = 3;
    this.ui.countdown(3);
    this.ui.updateHUD();
  }

  onRoundCleared() {
    if (this.state !== 'COMBAT') return;
    // settle the objective before the bonus (its reward gets special-round chips too)
    if (this.objective) {
      const o = this.objective;
      if (o.def.key === 'headhunter') o.progress = this.stats.headshots - o.startHeadshots;
      const done =
        (o.def.key === 'untouchable' && !o.failed) ||
        (o.def.key === 'speedclear' && o.time <= 60) ||
        (o.def.goal > 0 && o.progress >= o.def.goal);
      if (done) {
        const txt = o.def.reward(this);
        this.ui.banner(`OBJECTIVE COMPLETE — ${txt}`, 'cyan', 2600);
        Audio.play('wager_win');
      }
      this.objective = null;
    }
    this.combo = 0;
    this.addChips(CONFIG.chips.roundClearBonus);   // still boosted by the special — reward for surviving it
    this.specialRound = null;
    this.ui.banner(`ROUND ${this.round} CLEARED +${CONFIG.chips.roundClearBonus} chips`, 'gold');
    if (this.round === CONFIG.finalRound && !this.beatHouse) {
      // you beat the house — but the floor reopens for those who want more
      this.beatHouse = true;
      this.ui.banner('YOU BEAT THE HOUSE — THE FLOOR REOPENS. ENDLESS ROUNDS AHEAD, OR CASH OUT.', 'gold', 4000);
      Audio.play('jackpot');
    }
    this.setState('INTERMISSION');
    this.casino.beginIntermission();
  }

  cashOut() {
    this.ui.showSummary(true, `You cashed out after round ${this.round} and walked into the sunrise.`);
  }

  onBossDefeated(kind) {
    const debt = this.grudge[kind] || 0;
    if (debt > 0) {
      this.grudge[kind] = 0;
      this._saveGrudge();
      const payout = 75 * debt;
      this.addChips(payout);
      this.ui.banner(`GRUDGE SETTLED — ${debt} debt${debt === 1 ? '' : 's'} repaid +${payout} chips`, 'gold', 3000);
    }
    this.slowmo(1.0);
    this.addShake(0.3);
    this.effects.spawnBurst(this.player.pos.clone().add(this.player.forwardFlat().multiplyScalar(4)).setY(2), 0xc9a227, 20, 8);
    if (kind === 'pitboss') {
      this.addChips(250);
      this.ui.banner('THE PIT BOSS IS DOWN +250 chips', 'gold', 2600);
    } else {
      this.addChips(500);
      this.ui.banner('THE HOUSE DEALER FOLDS', 'gold', 3000);
    }
    Audio.play('jackpot');
  }

  onPlayerDeath(cause) {
    if (this.state === 'SUMMARY') return;
    // the bosses hold grudges — die to one and it remembers next run
    if (cause === 'THE PIT BOSS') { this.grudge.pitboss++; this._saveGrudge(); }
    if (cause === 'THE HOUSE DEALER') { this.grudge.housedealer++; this._saveGrudge(); }
    this.setState('SUMMARY');
    Audio.setBossMode(false);
    this.arena.setRedAlert(false);
    const won = this.beatHouse;   // dying deep in endless still counts as a win
    setTimeout(() => this.ui.showSummary(won,
      won ? `The house got you on round ${this.round} — but you beat it first.`
          : `Taken down by ${cause} on round ${this.round}.`), 900);
  }

  // ------------------------------- menus ------------------------------------
  _wireMenus() {
    $('btn-start').onclick = () => { Audio.init(); this.newRun(); };
    $('btn-continue').onclick = () => { Audio.init(); this.continueRun(); };
    $('btn-daily').onclick = () => { Audio.init(); this.startDaily(); };
    $('btn-cashout').onclick = () => this.cashOut();
    $('btn-vault').onclick = () => {
      this.ui.hide('main-menu');
      this.vault.render();
      this.ui.show('vault-panel');
    };
    $('btn-vault-close').onclick = () => {
      this.ui.hide('vault-panel');
      this._refreshMenu();
      this.ui.show('main-menu');
    };
    $('btn-play-again').onclick = () => this.newRun();
    $('btn-main-menu').onclick = () => {
      this.ui.hideAllPanels();
      this.setState('MENU');
      this.ui.renderHighscore();
      this._refreshMenu();
      this.ui.show('main-menu');
    };
    $('btn-resume').onclick = () => this.resume();
    $('btn-restart-pause').onclick = () => this.newRun();
    $('btn-quit-pause').onclick = () => {
      this.enemies.clearAll();
      this.ui.hideAllPanels();
      this.setState('MENU');
      this.ui.renderHighscore();
      this._refreshMenu();
      this.ui.show('main-menu');
    };
    const openSettings = (from) => {
      this._settingsReturn = from;
      this.ui.hide(from);
      this.ui.show('settings-panel');
    };
    $('btn-settings-main').onclick = () => openSettings('main-menu');
    $('btn-settings-pause').onclick = () => openSettings('pause-menu');
    $('btn-settings-close').onclick = () => {
      this.ui.hide('settings-panel');
      this.ui.show(this._settingsReturn || 'main-menu');
    };
  }

  // -------------------------------- loop ------------------------------------
  _tick() {
    const rawDt = Math.min(this.clock.getDelta(), 0.05);
    let dt = rawDt;
    if (this.slowmoT > 0) {
      this.slowmoT -= rawDt;          // slow-mo runs on real time
      dt = rawDt * 0.25;
    }

    switch (this.state) {
      case 'COUNTDOWN': {
        const before = Math.ceil(this._countdownT);
        this._countdownT -= dt;
        const after = Math.ceil(this._countdownT);
        if (after < before && after >= 0) this.ui.countdown(after);
        this.player.update(dt);
        this.ui.updateRadar();
        if (this._countdownT <= 0) this.setState('COMBAT');
        break;
      }
      case 'COMBAT': {
        // combo window decay
        if (this.comboT > 0) {
          this.comboT -= dt;
          if (this.comboT <= 0) this.combo = 0;
        }
        this.dashBuffT = Math.max(0, this.dashBuffT - dt);
        if (this.objective) this.objective.time += dt;
        this.player.update(dt);
        this.weapons.update(dt);
        this.enemies.update(dt);
        for (const b of this.bosses) b.update(dt);
        this.pickups.update(dt);
        this.arena.update(dt);
        this.effects.update(dt);
        this.ui.updateThreatIndicator();
        this.ui.updateRadar();

        const bossesAlive = this.bosses.some((b) => !b.dead);
        if (this.enemies.remaining() === 0 && !bossesAlive) this.onRoundCleared();
        this.ui.updateHUD();
        break;
      }
      case 'INTERMISSION':
        this.casino.updateTimer(dt);
        this.pickups.update(dt);
        break;
      case 'VICTORY':
        this.pickups.update(dt);
        break;
      default:
        break;
    }

    // 3D audio: keep the listener glued to the camera
    if (Audio.ready) {
      this._fwd.set(0, 0, -1).applyQuaternion(this.camera.quaternion);
      Audio.updateListener(this.camera.position, this._fwd);
      // danger meter -> music intensity, ~2x/sec
      this._audioMeterT -= rawDt;
      if (this._audioMeterT <= 0) {
        this._audioMeterT = 0.45;
        if (this.state === 'COMBAT') {
          let near = 0;
          for (const z of this.enemies.list) {
            if (!z.dead && z.mesh.position.distanceTo(this.player.pos) < 14) near++;
          }
          const bossBoost = this.bosses.some((b) => !b.dead) ? 0.35 : 0;
          const hpFear = (1 - this.player.hp / this.player.maxHp) * 0.35;
          Audio.setIntensity(0.15 + Math.min(0.5, near / 8) + hpFear + bossBoost);
        } else {
          Audio.setIntensity(0.15);
        }
      }
    }

    // screen shake: applied after all camera positioning, decays on real time
    if (this.shakeAmp > 0.002) {
      const a = this.shakeAmp * (this.settings.reducedFlash ? 0.6 : 1);
      this.camera.position.x += (Math.random() - 0.5) * a;
      this.camera.position.y += (Math.random() - 0.5) * a * 0.7;
      this.camera.position.z += (Math.random() - 0.5) * a;
      this.shakeAmp *= Math.exp(-7 * rawDt);
    } else this.shakeAmp = 0;

    this.renderer.render(this.scene, this.camera);
  }
}
