// debug.js — the F3 developer panel. Deliberately styled unlike the game UI
// so it can't be mistaken for a player-facing feature.

export function initDebug(game) {
  const panel = document.getElementById('debug-panel');
  const rows = [
    ['+500 chips', () => game.addChips(500)],
    ['Full heal', () => game.player.heal(999)],
    ['Refill ammo', () => game.weapons.refillAll()],
    ['Toggle invulnerable', () => { game.debug.invuln = !game.debug.invuln; flash(`invuln: ${game.debug.invuln}`); }],
    ['Skip round (win it)', () => {
      if (game.state !== 'COMBAT') return flash('need COMBAT');
      game.enemies.clearAll();
      game.bosses.forEach((b) => { if (!b.dead) { b.hp = 1; b.takeDamage(999, false, null); } });
      flash('round skipped');
    }],
    ['Jump to Round 5 (miniboss)', () => { game.newRun(); game.round = 4; jumpNote(); }],
    ['Jump to Round 10 (final boss)', () => { game.newRun(); game.round = 9; game.addChips(400); jumpNote(); }],
    ['Rig next blackjack: WIN', () => { game.debug.forceBJ = 'win'; flash('BJ rigged: win'); }],
    ['Rig next blackjack: LOSS', () => { game.debug.forceBJ = 'loss'; flash('BJ rigged: loss'); }],
    ['Rig next blackjack: PUSH', () => { game.debug.forceBJ = 'push'; flash('BJ rigged: push'); }],
    ['Rig next roulette: WIN', () => { game.debug.forceRoulette = 'win'; flash('roulette rigged: win'); }],
    ['Rig next roulette: LOSS', () => { game.debug.forceRoulette = 'loss'; flash('roulette rigged: loss'); }],
    ['+3 grenades', () => { game.player.grenades = Math.min(game.player.grenades + 3, 99); flash('grenades+'); }],
    ['Unlock Boneyard Special', () => { game.weapons.unlock('rifle'); }],
    ['Apply mild penalty', () => game.casino.applyPenalty('mild')],
    ['Apply moderate penalty', () => game.casino.applyPenalty('moderate')],
    ['Apply severe penalty', () => game.casino.applyPenalty('severe')],
    ['Offer COMMON upgrade', () => game.upgrades.offer('common')],
    ['Offer RARE upgrade', () => game.upgrades.offer('rare')],
    ['Offer LEGENDARY upgrade', () => game.upgrades.offer('legendary')],
  ];

  function jumpNote() {
    // newRun() already kicked off round 1's countdown; the next round-clear
    // will advance from the round we just set. Simplest correct jump: clear
    // the freshly loaded round immediately.
    setTimeout(() => {
      game.enemies.clearAll();
      if (game.state === 'COMBAT' || game.state === 'COUNTDOWN') {
        game.setState('COMBAT');
        game.onRoundCleared();
      }
    }, 100);
    flash('jumping…');
  }

  const head = document.createElement('div');
  head.className = 'dbg-head';
  head.textContent = 'DEBUG (F3) — dev tools, not gameplay';
  panel.appendChild(head);

  const stat = document.createElement('div');
  stat.className = 'dbg-stat';
  panel.appendChild(stat);

  const note = document.createElement('div');
  note.className = 'dbg-note';
  panel.appendChild(note);
  function flash(msg) { note.textContent = msg; setTimeout(() => { if (note.textContent === msg) note.textContent = ''; }, 2500); }

  for (const [label, fn] of rows) {
    const b = document.createElement('button');
    b.className = 'dbg-btn';
    b.textContent = label;
    b.onclick = fn;
    panel.appendChild(b);
  }

  // FPS + entity counter
  let frames = 0, last = performance.now();
  (function tick() {
    requestAnimationFrame(tick);
    frames++;
    const now = performance.now();
    if (now - last >= 1000) {
      stat.textContent = `FPS ${frames} · state ${game.state} · enemies ${game.enemies.list.length} · projectiles ${game.enemies.projectiles.length}`;
      frames = 0; last = now;
    }
  })();

  return {
    toggle() {
      game.debug.show = !game.debug.show;
      panel.classList.toggle('hidden', !game.debug.show);
    },
  };
}
