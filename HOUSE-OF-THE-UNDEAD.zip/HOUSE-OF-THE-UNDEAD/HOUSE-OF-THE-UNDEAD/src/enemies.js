// enemies.js — the horde. Seven kinds of casino zombie:
//   walker    — shuffling gambler (basic melee)
//   sprinter  — valet, fast and fragile
//   brute     — bouncer, slow tank
//   spitter   — NEW: lobs acid from range
//   gasbag    — NEW: swells and EXPLODES on death (stand back)
//   pitguard  — NEW: armored body, weak glowing head
//   collector — THE DEBT COLLECTOR (severe penalty): hunts you, steals chips
// Plus the enemy projectile pool and the player's chip-bomb grenades.

import * as THREE from 'three';
import { CONFIG, clamp, rand, randInt, pick } from './config.js';
import { Audio } from './audio.js';
import { ARENA_HALF } from './arena.js';

const E = CONFIG.enemies;

// ------------------------------- one zombie ---------------------------------
class Zombie {
  constructor(game, kind, roundScale, elite = false) {
    this.game = game;
    this.kind = kind;
    this.def = { name: kind.toUpperCase(), ...E[kind] };
    this.elite = elite;

    const hpMult = roundScale.hp * (elite ? CONFIG.eliteMult.hp : 1);
    this.maxHp = this.hp = this.def.hp * hpMult;
    this.speed = this.def.speed * (elite ? CONFIG.eliteMult.speed : 1) * roundScale.speedMult;
    this.damage = this.def.damage * roundScale.dmg;
    this.dead = false;
    this.attackCd = 0;
    this.hitFlash = 0;
    this.kbVel = new THREE.Vector3();
    this.swellT = 0;         // gasbag death telegraph

    this._buildMesh();
  }

  _buildMesh() {
    const s = this.def.scale;
    const palette = {
      walker: 0x5a7d5a, sprinter: 0x7a5a8d, brute: 0x8d5a3a,
      spitter: 0x4a8d6a, gasbag: 0x9dbb4a, pitguard: 0x555a70, collector: 0x3a3a3a,
      croupier: 0x6a7a5a, magician: 0x4a3a6a, jackpot: 0xc9a227,
    };
    const bodyColor = this.elite ? 0xc9a227 : palette[this.kind];
    // corpse flesh: pull every kind's hue toward grey-green decay, then vary it
    const skin = new THREE.Color(bodyColor)
      .lerp(new THREE.Color(0x8a9078), this.elite ? 0.1 : 0.4)
      .multiplyScalar(0.82 + Math.random() * 0.3);
    this.mesh = new THREE.Group();

    const bodyMat = new THREE.MeshStandardMaterial({ color: skin, roughness: 0.92 });
    this.bodyMat = bodyMat;
    // hunched torso — undead don't stand up straight (each one differently)
    const hunch = 0.1 + Math.random() * 0.14;
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.4 * s, 0.85 * s, 4, 10), bodyMat);
    body.position.y = 1.0 * s;
    body.position.z = 0.03 * s;
    body.rotation.x = hunch;
    body.userData = { ref: this, isHead: false };

    // festering wounds on the torso
    const woundMat = new THREE.MeshStandardMaterial({ color: 0x4a1518, roughness: 1 });
    for (let i = 0; i < 2 + Math.floor(Math.random() * 2); i++) {
      const wound = new THREE.Mesh(new THREE.SphereGeometry(0.09 * s * (0.7 + Math.random() * 0.7), 6, 5), woundMat);
      const wa = Math.random() * Math.PI * 2;
      wound.scale.z = 0.35;
      wound.position.set(Math.cos(wa) * 0.36 * s, (0.75 + Math.random() * 0.7) * s, 0.03 * s + Math.sin(wa) * 0.36 * s);
      wound.lookAt(0, wound.position.y, 0);
      this.mesh.add(wound);
    }

    // neck connecting head to torso
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.11 * s, 0.14 * s, 0.22 * s, 8), bodyMat);
    neck.position.set(0, 1.68 * s, 0.07 * s);
    neck.rotation.x = 0.15;
    this.mesh.add(neck);

    // rounded shoulders
    const shoulderGeo = new THREE.SphereGeometry(0.17 * s, 8, 8);
    for (const sx of [-0.42, 0.42]) {
      const sh = new THREE.Mesh(shoulderGeo, bodyMat);
      sh.position.set(sx * s, 1.52 * s, 0.03 * s);
      this.mesh.add(sh);
    }

    const headMat = new THREE.MeshStandardMaterial({
      color: this.kind === 'pitguard' ? 0xffd24a : skin,
      emissive: this.kind === 'pitguard' ? 0xffd24a : 0x000000,
      emissiveIntensity: this.kind === 'pitguard' ? 0.7 : 0,
      roughness: 0.85,
    });
    this.headMat = headMat;
    // round head, pushed forward with the hunch
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.26 * s, 12, 10), headMat);
    head.position.set(0, 1.95 * s, 0.1 * s);
    head.scale.set(1, 1.08, 1.02);
    head.rotation.z = (Math.random() - 0.5) * 0.24;   // lolling head tilt
    head.userData = { ref: this, isHead: true };

    // hanging jaw — the classic undead slack mouth
    const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.26 * s, 0.12 * s, 0.18 * s), bodyMat);
    jaw.position.set(0, 1.76 * s, 0.2 * s);
    jaw.rotation.x = 0.5;
    this.mesh.add(jaw);
    // matted hair patch
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.24 * s, 8, 6),
      new THREE.MeshStandardMaterial({ color: 0x1a1410, roughness: 1 }));
    hair.scale.set(1.05, 0.55, 1.05);
    hair.position.set(0, 2.12 * s, 0.06 * s);
    this.mesh.add(hair);

    // ----- casino outfits: every kind is dressed for the floor -----
    const std = (color, opts = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.7, ...opts });
    const box = (w, h, d, mat, x, y, z) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w * s, h * s, d * s), mat);
      m.position.set(x * s, y * s, z * s);
      this.mesh.add(m);
      return m;
    };
    const cyl = (rT, rB, h, mat, x, y, z, segs = 10) => {
      const m = new THREE.Mesh(new THREE.CylinderGeometry(rT * s, rB * s, h * s, segs), mat);
      m.position.set(x * s, y * s, z * s);
      this.mesh.add(m);
      return m;
    };
    const bowtie = (color = 0xb3122e) => {
      box(0.26, 0.1, 0.1, std(color), 0, 1.66, 0.4);
    };
    const glowEyes = (color = 0xff4a4a) => {
      const eyeMat = new THREE.MeshBasicMaterial({ color });
      for (const dx of [-0.11, 0.11]) {
        const e = new THREE.Mesh(new THREE.SphereGeometry(0.05 * s, 6, 6), eyeMat);
        e.position.set(dx * s, 2.0 * s, 0.22 * s);
        this.mesh.add(e);
      }
    };

    switch (this.kind) {
      case 'walker': {          // washed-up gambler: loose tie, trilby
        glowEyes();
        box(0.1, 0.5, 0.08, std(0xb3122e), 0.05, 1.3, 0.42);  // crooked tie
        cyl(0.28, 0.28, 0.12, std(0x2a2a2a), 0, 2.2, 0);      // trilby crown
        cyl(0.4, 0.4, 0.04, std(0x2a2a2a), 0, 2.15, 0);       // brim
        break;
      }
      case 'sprinter': {        // valet: red vest, pillbox cap
        glowEyes(0xffb04a);
        box(0.62, 0.7, 0.5, std(0x8d1f2f), 0, 1.15, 0.06);    // vest
        box(0.1, 0.7, 0.52, std(0xc9a227), 0, 1.15, 0.06);    // gold trim
        cyl(0.24, 0.24, 0.16, std(0x8d1f2f), 0, 2.22, 0);     // pillbox cap
        break;
      }
      case 'brute': {           // bouncer: black suit, shades, earpiece
        glowEyes(0xffffff);
        box(0.95, 0.9, 0.75, std(0x14141c), 0, 1.15, 0);      // suit jacket
        box(0.14, 0.5, 0.1, std(0xffffff), 0, 1.3, 0.4);      // shirt
        box(0.45, 0.1, 0.1, std(0x000000, { metalness: 0.6 }), 0, 2.02, 0.22); // shades
        cyl(0.03, 0.03, 0.25, std(0x111111), 0.24, 1.85, 0.1);// earpiece wire
        break;
      }
      case 'spitter': {         // cocktail server: bowtie + serving tray
        glowEyes(0x7aff4a);
        bowtie(0x111111);
        const tray = cyl(0.34, 0.34, 0.04, std(0xc0c0c0, { metalness: 0.8 }), 0.62, 1.45, 0.3);
        cyl(0.06, 0.06, 0.16, std(0x27e6ff), 0.55, 1.55, 0.28, 8); // toxic "drink"
        tray.rotation.z = 0.1;
        break;
      }
      case 'gasbag': {          // bloated high roller: gold chain, fanned cards
        glowEyes(0xd6ff4a);
        const chain = new THREE.Mesh(new THREE.TorusGeometry(0.34 * s, 0.05 * s, 8, 14),
          std(0xc9a227, { metalness: 0.9, roughness: 0.3 }));
        chain.position.y = 1.6 * s; chain.rotation.x = Math.PI / 2.4;
        this.mesh.add(chain);
        for (let i = -1; i <= 1; i++) {                        // cards tucked in the waistband
          const card = box(0.16, 0.24, 0.02, std(0xf5f0e0), i * 0.18, 0.85, 0.44);
          card.rotation.z = i * 0.25;
        }
        break;
      }
      case 'pitguard': {        // pit security: visor, shoulder plates, suit badge
        box(0.5, 0.12, 0.3, std(0x111111), 0, 2.08, 0.14);    // visor
        box(0.5, 0.18, 0.5, std(0x33384f, { metalness: 0.5 }), -0.5, 1.62, 0);  // pauldrons
        box(0.5, 0.18, 0.5, std(0x33384f, { metalness: 0.5 }), 0.5, 1.62, 0);
        const badge = box(0.14, 0.18, 0.03, std(0xffd24a, { metalness: 0.8 }), -0.2, 1.35, 0.44); // ♠ badge
        badge.rotation.z = Math.PI / 4;
        break;
      }
      case 'croupier': {        // card dealer gone bad: vest, green visor, card fan
        glowEyes(0xd8ffd8);
        box(0.6, 0.68, 0.48, std(0x1a1a22), 0, 1.15, 0.05);   // black vest
        box(0.12, 0.68, 0.5, std(0xf5f0e0), 0, 1.15, 0.06);   // white shirt strip
        const visor = box(0.5, 0.1, 0.32, std(0x1f8f4f, { transparent: true, opacity: 0.85 }), 0, 2.08, 0.16);
        visor.rotation.x = -0.3;
        for (let i = -1; i <= 1; i++) {                        // hand of razor cards
          const card = box(0.14, 0.2, 0.02, std(0xf5f0e0), 0.6 + i * 0.06, 1.4, 0.3);
          card.rotation.z = i * 0.35;
        }
        break;
      }
      case 'magician': {        // stage magician: cape, wand, star-spangled hat
        glowEyes(0xc27aff);
        const cape = box(0.75, 1.0, 0.08, std(0x2a1040), 0, 1.15, -0.32);
        cape.rotation.x = 0.12;
        cyl(0.28, 0.28, 0.5, std(0x14081f), 0, 2.35, 0);      // tall hat
        cyl(0.4, 0.4, 0.04, std(0x14081f), 0, 2.12, 0);
        box(0.3, 0.06, 0.06, std(0xc27aff), 0, 2.3, 0.26);    // hat band glow
        cyl(0.025, 0.025, 0.4, std(0xf5f0e0), 0.55, 1.4, 0.25, 6); // wand
        break;
      }
      case 'jackpot': {         // walking golden slot machine — kill for a payout
        glowEyes(0xfff2a0);
        box(0.75, 0.5, 0.35, std(0x241a30, { metalness: 0.5 }), 0, 1.2, 0.3);  // chest cabinet
        box(0.6, 0.22, 0.02, std(0x08060f), 0, 1.28, 0.49);   // screen
        const arm = cyl(0.03, 0.03, 0.5, std(0x999999, { metalness: 0.9 }), 0.5, 1.35, 0.2, 6);
        arm.rotation.z = -0.4;
        const knob = new THREE.Mesh(new THREE.SphereGeometry(0.08 * s, 8, 8),
          new THREE.MeshBasicMaterial({ color: 0xff3333 }));
        knob.position.set(0.62 * s, 1.55 * s, 0.2 * s);
        this.mesh.add(knob);
        const light = new THREE.Mesh(new THREE.CylinderGeometry(0.1 * s, 0.13 * s, 0.22 * s, 8),
          new THREE.MeshBasicMaterial({ color: 0xffd24a }));
        light.position.y = 2.35 * s;
        this.mesh.add(light);
        break;
      }
      case 'collector': {       // the Debt Collector: top hat, briefcase, watch chain
        glowEyes(0xff2d2d);
        cyl(0.3, 0.3, 0.42, std(0x0a0a0a), 0, 2.35, 0);       // top hat
        cyl(0.42, 0.42, 0.04, std(0x0a0a0a), 0, 2.16, 0);
        box(0.34, 0.26, 0.1, std(0x2a1a0a), 0.6, 0.9, 0.15);  // briefcase of your chips
        cyl(0.02, 0.02, 0.3, std(0xc9a227, { metalness: 0.9 }), 0.15, 1.35, 0.42, 6); // watch chain
        break;
      }
    }
    if (this.elite) {
      const crown = new THREE.Mesh(new THREE.ConeGeometry(0.25 * s, 0.3 * s, 5),
        new THREE.MeshBasicMaterial({ color: 0xc9a227 }));
      crown.position.y = 2.65 * s;
      this.mesh.add(crown);
    }
    this.groanT = rand(3, 12);

    // ----- limbs: rounded capsules pivoted at shoulder/hip, with hands + feet -----
    const limbGeoArm = new THREE.CapsuleGeometry(0.075 * s, 0.5 * s, 3, 7).translate(0, -0.3 * s, 0);
    const limbGeoLeg = new THREE.CapsuleGeometry(0.095 * s, 0.55 * s, 3, 7).translate(0, -0.34 * s, 0);
    const handGeo = new THREE.SphereGeometry(0.095 * s, 7, 6);
    const footGeo = new THREE.BoxGeometry(0.16 * s, 0.09 * s, 0.26 * s);
    // torn suit trousers on the legs, bare decayed arms, gore-stained hands
    const pantsMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(0x241f2a).multiplyScalar(0.8 + Math.random() * 0.4), roughness: 1 });
    const handMat = new THREE.MeshStandardMaterial({
      color: skin.clone().multiplyScalar(0.55).offsetHSL(0, 0.1, -0.02), roughness: 1 });
    const mkLimb = (geo, x, y, tip) => {
      const m = new THREE.Mesh(geo, tip === 'hand' ? bodyMat : pantsMat);
      m.position.set(x * s, y * s, 0.03 * s);
      if (tip === 'hand') {
        const hand = new THREE.Mesh(handGeo, handMat);
        hand.scale.set(1, 0.8, 1.25);          // clawed reach
        hand.position.y = -0.62 * s;
        m.add(hand);
      } else {
        const foot = new THREE.Mesh(footGeo, new THREE.MeshStandardMaterial({ color: 0x1a1410, roughness: 1 }));
        foot.position.set(0, -0.68 * s, 0.06 * s);
        m.add(foot);
      }
      this.mesh.add(m);
      return m;
    };
    this.limbs = {
      lArm: mkLimb(limbGeoArm, -0.52, 1.55, 'hand'),
      rArm: mkLimb(limbGeoArm, 0.52, 1.55, 'hand'),
      lLeg: mkLimb(limbGeoLeg, -0.19, 0.84, 'foot'),
      rLeg: mkLimb(limbGeoLeg, 0.19, 0.84, 'foot'),
    };
    // classic zombie pose: arms out front
    this.limbs.lArm.rotation.x = this.limbs.rArm.rotation.x = -1.25;
    this.animT = Math.random() * 10;
    this.lungeT = 0;

    this.parts = [body, head];
    this.mesh.add(body, head);
    this.mesh.scale.setScalar(0.93 + Math.random() * 0.14);   // no two the same height

    // spawn at a wall edge, never on the player
    const edge = pick(['n', 's', 'e', 'w']);
    const r = ARENA_HALF - 2;
    const t = rand(-r, r);
    if (edge === 'n') this.mesh.position.set(t, 0, -r);
    if (edge === 's') this.mesh.position.set(t, 0, r);
    if (edge === 'e') this.mesh.position.set(r, 0, t);
    if (edge === 'w') this.mesh.position.set(-r, 0, t);
    this.game.scene.add(this.mesh);
  }

  knockback(dir, force) {
    this.kbVel.add(dir.clone().setY(0).normalize().multiplyScalar(force));
  }

  takeDamage(dmg, strong, point, cause = 'hit') {
    if (this.dead) return;
    this.lastCause = cause;
    // pit guard body armor: full damage only on the head
    if (this.kind === 'pitguard' && point && point.y < 1.6 * this.def.scale) {
      dmg *= (1 - this.def.bodyResist);
    }
    this.hp -= dmg;
    this.hitFlash = 0.08;
    // stagger: bullets shove, scaled down for the big ones
    const away = this.mesh.position.clone().sub(this.game.player.pos).setY(0).normalize();
    this.kbVel.add(away.multiplyScalar((strong ? 2.2 : 1.3) / this.def.scale));
    if (point && this.game.settings) {
      this.game.ui.floatText(point, Math.round(dmg), strong ? 'dmg crit' : 'dmg');
    }
    if (this.hp <= 0) this.die();
  }

  die() {
    if (this.dead) return;
    this.dead = true;
    const g = this.game;
    g.audioAt('zombie_die', this.mesh.position);
    g.onKill(this);

    // drops
    const chipMult = this.elite ? CONFIG.eliteMult.chips : 1;
    const amt = Math.round(randInt(this.def.chips[0], this.def.chips[1]) * chipMult);
    g.pickups.spawnChips(this.mesh.position.clone(), amt + (this.stash || 0));
    if (this.stash) g.ui.banner(`DEBT RECLAIMED +${this.stash} chips (with interest)`, 'gold');
    g.pickups.spawnDrop(this.mesh.position.clone().add(new THREE.Vector3(rand(-1, 1), 0, rand(-1, 1))));

    // gasbag explodes on death — no corpse, it IS the explosion
    if (this.kind === 'gasbag') {
      g.enemies.explodeAt(this.mesh.position.clone(), this.def.blastRadius, this.damage, true);
      g.scene.remove(this.mesh);
      return;
    }
    // topple + sink instead of vanishing — with some variety in how they go down
    g.effects.spawnBurst(this.mesh.position.clone().setY(1.2 * this.def.scale), 0x8f1f2f, 6, 3.5);
    g.enemies.corpses.push({
      mesh: this.mesh, t: 0,
      axis: Math.random() < 0.7 ? 'x' : 'z',            // forward or sideways
      sign: Math.random() < 0.5 ? 1 : -1,
      spin: this.kind === 'sprinter' ? (Math.random() * 2 - 1) * 3 : 0,
    });
  }

  update(dt) {
    const g = this.game;
    const p = g.player;
    this.attackCd = Math.max(0, this.attackCd - dt);

    // ambient groans (only nearby, so it doesn't turn into a choir)
    this.groanT -= dt;
    if (this.groanT <= 0) {
      this.groanT = rand(6, 16);
      if (this.mesh.position.distanceTo(p.pos) < 30) g.audioAt('groan', this.mesh.position);
    }

    // heavy footsteps for the big ones — you hear them coming
    if (this.kind === 'brute' || this.kind === 'collector' || this.kind === 'pitguard') {
      this.stepT = (this.stepT ?? 0) - dt;
      if (this.stepT <= 0) {
        this.stepT = Math.max(0.3, 1.4 / this.speed);
        if (this.mesh.position.distanceTo(p.pos) < 18) {
          g.audioAt(this.kind === 'collector' ? 'step_click' : 'step_heavy', this.mesh.position);
        }
      }
    }

    // hit flash
    if (this.hitFlash > 0) {
      this.hitFlash -= dt;
      this.bodyMat.emissive.set(0xffffff);
      this.bodyMat.emissiveIntensity = 0.8;
    } else {
      this.bodyMat.emissive.set(this.kind === 'gasbag' && this.hp < this.maxHp * 0.35 ? 0x9dbb4a : 0x000000);
      this.bodyMat.emissiveIntensity = this.kind === 'gasbag' && this.hp < this.maxHp * 0.35 ? 0.6 : 0;
    }

    const toPlayer = p.pos.clone().sub(this.mesh.position); toPlayer.y = 0;
    const dist = toPlayer.length();
    toPlayer.normalize();
    this.mesh.rotation.y = Math.atan2(toPlayer.x, toPlayer.z);

    // knockback decay
    if (this.kbVel.lengthSq() > 0.01) {
      this.mesh.position.add(this.kbVel.clone().multiplyScalar(dt));
      this.kbVel.multiplyScalar(Math.max(0, 1 - 6 * dt));
    }

    // behavior
    if (this.kind === 'jackpot') {
      // flees the player; escapes for good if you don't kill it in time
      this.mesh.position.add(toPlayer.multiplyScalar(-this.speed * dt));
      this.mesh.rotation.y += Math.PI;                 // face away while fleeing
    } else if (this.kind === 'magician') {
      this.blinkT = (this.blinkT ?? this.def.blinkCd) - dt;
      if (this.blinkT <= 0 && dist > 6) {
        this.blinkT = this.def.blinkCd;
        // poof out, reappear 5-8m from the player at a random angle
        g.effects.spawnBurst(this.mesh.position.clone().setY(1.4), 0xc27aff, 8, 4);
        const a = Math.random() * Math.PI * 2;
        const r2 = 5 + Math.random() * 3;
        this.mesh.position.set(p.pos.x + Math.cos(a) * r2, 0, p.pos.z + Math.sin(a) * r2);
        g.effects.spawnBurst(this.mesh.position.clone().setY(1.4), 0xc27aff, 8, 4);
        g.audioAt('card', this.mesh.position);
      } else {
        this.mesh.position.add(toPlayer.clone().multiplyScalar(this.speed * dt));
      }
      const reachM = 1.3 + this.def.scale * 0.4;
      if (dist < reachM && this.attackCd <= 0) {
        this.attackCd = 1.1;
        this.lungeT = 0.35;
        p.takeDamage(this.damage, this);
      }
    } else if (this.kind === 'croupier') {
      // keeps dealing distance, flings a fan of razor cards
      const want = this.def.attackRange * 0.8;
      if (dist > this.def.attackRange) this.mesh.position.add(toPlayer.clone().multiplyScalar(this.speed * dt));
      else if (dist < want - 2) this.mesh.position.add(toPlayer.clone().multiplyScalar(-this.speed * 0.6 * dt));
      if (dist <= this.def.attackRange && this.attackCd <= 0) {
        this.attackCd = this.def.attackCd;
        this.lungeT = 0.35;
        g.audioAt('card', this.mesh.position);
        const base = p.pos.clone().sub(this.mesh.position).setY(0).normalize();
        for (let i = 0; i < this.def.burst; i++) {
          const a = (i - (this.def.burst - 1) / 2) * 0.12;
          const dir = base.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), a);
          dir.y = 0.03;
          g.enemies.spawnProjectile(
            this.mesh.position.clone().add(new THREE.Vector3(0, 1.6, 0)),
            dir.multiplyScalar(this.def.projSpeed), this.damage, 0xf5f0e0, this);
        }
      }
    } else if (this.kind === 'spitter') {
      const want = this.def.attackRange * 0.8;
      if (dist > this.def.attackRange) this.mesh.position.add(toPlayer.multiplyScalar(this.speed * dt));
      else if (dist < want - 2) this.mesh.position.add(toPlayer.multiplyScalar(-this.speed * 0.7 * dt));
      if (dist <= this.def.attackRange && this.attackCd <= 0) {
        this.attackCd = this.def.attackCd;
        this.lungeT = 0.35;
        g.audioAt('gas_hiss', this.mesh.position);
        const aim = p.pos.clone().sub(this.mesh.position).normalize();
        g.enemies.spawnProjectile(
          this.mesh.position.clone().add(new THREE.Vector3(0, 1.6, 0)),
          aim.multiplyScalar(this.def.projSpeed), this.damage, 0x7aff4a, this);
      }
    } else {
      // melee chasers
      this.mesh.position.add(toPlayer.clone().multiplyScalar(this.speed * dt));
      const reach = 1.3 + this.def.scale * 0.4;
      if (dist < reach && this.attackCd <= 0) {
        this.attackCd = 1.1;
        this.lungeT = 0.35;
        p.takeDamage(this.damage, this);
      }
    }

    // ----- limb animation: walk cycle + attack lunge -----
    this.animT += dt * (2.0 + this.speed * 0.9);
    const swing = Math.sin(this.animT);
    this.limbs.lLeg.rotation.x = swing * 0.55;
    this.limbs.rLeg.rotation.x = -swing * 0.55;
    if (this.lungeT > 0) {
      this.lungeT -= dt;
      const k = this.lungeT / 0.35;               // 1 -> 0
      const down = -0.35 - Math.sin(k * Math.PI) * 0.5;
      this.limbs.lArm.rotation.x = this.limbs.rArm.rotation.x = down;
      this.mesh.rotation.x = Math.sin(k * Math.PI) * 0.18;   // lean into the swipe
    } else {
      this.mesh.rotation.x = 0;
      this.limbs.lArm.rotation.x = -1.25 + Math.sin(this.animT + Math.PI) * 0.12;
      this.limbs.rArm.rotation.x = -1.25 + Math.sin(this.animT) * 0.12;
    }

    g.arena.collide(this.mesh.position, 0.5 * this.def.scale);
    // gentle separation so they don't stack
    for (const other of g.enemies.list) {
      if (other === this || other.dead) continue;
      const d = this.mesh.position.distanceTo(other.mesh.position);
      const min = 0.9 * (this.def.scale + other.def.scale) * 0.5 + 0.5;
      if (d < min && d > 1e-4) {
        const push = this.mesh.position.clone().sub(other.mesh.position).setY(0).normalize()
          .multiplyScalar((min - d) * 0.5);
        this.mesh.position.add(push);
      }
    }
  }
}

// ------------------------------- the manager --------------------------------
export class Enemies {
  constructor(game) {
    this.game = game;
    this.list = [];
    this.projectiles = [];   // enemy shots
    this.grenades = [];      // player chip bombs
    this.corpses = [];       // toppling bodies (visual only, not shootable)
    this.spawnQueue = [];
    this.spawnT = 0;
  }

  remaining() { return this.list.length + this.spawnQueue.length; }

  hitMeshes() {
    const out = [];
    for (const z of this.list) out.push(...z.parts);
    for (const b of this.game.bosses) if (!b.dead) out.push(...b.parts);
    return out;
  }

  // ------------------------------ round setup -------------------------------
  buildRound(round, mods) {
    this.clearAll();
    const S = CONFIG.spawn;
    let count = Math.round((S.baseCount + S.perRound * (round - 1)) * (mods.countMult || 1));
    if (mods.bossRound) count = Math.round(count * 0.55);

    const queue = [];
    for (let i = 0; i < count; i++) {
      let kind = 'walker';
      const r = Math.random();
      if (mods.onlyKinds) {                                  // RUSH HOUR etc.
        kind = pick(mods.onlyKinds);
      } else if (mods.heavyMix) {                            // HEAVYWEIGHT NIGHT
        kind = r < 0.4 ? 'brute' : r < 0.75 ? 'pitguard' : 'walker';
      } else {
        if (round >= 2 && r < 0.22) kind = 'sprinter';
        else if (round >= 3 && r < 0.34) kind = 'spitter';
        else if (round >= 4 && r < 0.42) kind = 'croupier';
        else if (round >= 4 && r < 0.50) kind = 'gasbag';
        else if (round >= 4 && r < 0.58) kind = 'pitguard';
        else if (round >= 6 && r < 0.64) kind = 'magician';
        else if (round >= 6 && r < 0.72) kind = 'brute';
      }
      queue.push({ kind, elite: !!mods.elite && Math.random() < 0.25 });
    }
    // penalty: extra specials
    for (let i = 0; i < (mods.extraSpecial || 0); i++) {
      queue.push({ kind: pick(['brute', 'gasbag', 'pitguard']), elite: !!mods.elite });
    }
    if (mods.debtCollector) queue.push({ kind: 'collector', elite: false });
    // bonus target: a jackpot wanders in on some rounds
    if (!mods.bossRound && round >= 3 && Math.random() < 0.25) queue.push({ kind: 'jackpot', elite: false });

    this.spawnQueue = queue;
    this.roundScale = {
      hp: 1 + CONFIG.spawn.hpScalePerRound * (round - 1),
      dmg: (1 + CONFIG.spawn.dmgScalePerRound * (round - 1)) * (mods.dmgMult || 1),
      speedMult: mods.speedMult || 1,
    };
    this.spawnT = 0;
  }

  update(dt) {
    // trickle spawns
    this.spawnT -= dt;
    while (this.spawnQueue.length && this.list.length < CONFIG.spawn.maxAlive && this.spawnT <= 0) {
      const s = this.spawnQueue.shift();
      const z = new Zombie(this.game, s.kind, this.roundScale, s.elite);
      this.list.push(z);
      this.spawnT = rand(0.15, 0.5);
      if (s.kind === 'jackpot') {
        z.lifeT = CONFIG.enemies.jackpot.despawn;
        this.game.ui.banner('★ A JACKPOT WALKS THE FLOOR — CASH IT OUT ★', 'gold', 2600);
        this.game.audioAt('jackpot', z.mesh.position);
      }
    }

    for (let i = this.list.length - 1; i >= 0; i--) {
      const z = this.list[i];
      if (z.dead) { this.list.splice(i, 1); continue; }
      // the jackpot escapes if you're too slow — no kill, no payout
      if (z.lifeT !== undefined) {
        z.lifeT -= dt;
        if (z.lifeT <= 0) {
          z.dead = true;
          this.game.scene.remove(z.mesh);
          this.game.ui.prompt('The jackpot cashed out and left...');
          this.list.splice(i, 1);
          continue;
        }
      }
      z.update(dt);
    }
    this._updateProjectiles(dt);
    this._updateGrenades(dt);
    this._updateCorpses(dt);
  }

  _updateCorpses(dt) {
    for (let i = this.corpses.length - 1; i >= 0; i--) {
      const c = this.corpses[i];
      c.t += dt;
      const tip = Math.min(1, c.t / 0.45);
      c.mesh.rotation[c.axis || 'x'] = tip * (Math.PI / 2) * 0.96 * (c.sign || 1);
      if (c.spin) c.mesh.rotation.y += c.spin * dt;      // sprinters corkscrew down
      if (c.t > 0.55) c.mesh.position.y -= dt * 1.4;     // sink into the carpet
      if (c.t > 1.15) {
        this.game.scene.remove(c.mesh);
        this.corpses.splice(i, 1);
      }
    }
  }

  // ---------------------------- enemy projectiles ---------------------------
  spawnProjectile(pos, vel, damage, color, source) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8),
      new THREE.MeshBasicMaterial({ color }));
    m.position.copy(pos);
    this.game.scene.add(m);
    this.projectiles.push({ mesh: m, vel, damage, t: 4, source });
  }

  _updateProjectiles(dt) {
    const g = this.game;
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.t -= dt;
      pr.mesh.position.add(pr.vel.clone().multiplyScalar(dt));
      const hitPlayer = pr.mesh.position.distanceTo(g.player.pos) < 0.8;
      const oob = Math.abs(pr.mesh.position.x) > ARENA_HALF + 1 || Math.abs(pr.mesh.position.z) > ARENA_HALF + 1;
      if (hitPlayer) g.player.takeDamage(pr.damage, pr.source);
      if (hitPlayer || oob || pr.t <= 0) {
        g.scene.remove(pr.mesh);
        this.projectiles.splice(i, 1);
      }
    }
  }

  // --------------------------- player grenades (NEW) ------------------------
  spawnGrenade(pos, vel) {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.08, 10),
      new THREE.MeshStandardMaterial({ color: 0xff2d55, emissive: 0xff2d55, emissiveIntensity: 0.6 }));
    m.position.copy(pos);
    this.game.scene.add(m);
    this.grenades.push({ mesh: m, vel: vel.clone(), fuse: CONFIG.grenade.fuse });
  }

  _updateGrenades(dt) {
    const g = this.game;
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const gr = this.grenades[i];
      gr.fuse -= dt;
      gr.vel.y -= 14 * dt;
      gr.mesh.position.add(gr.vel.clone().multiplyScalar(dt));
      gr.mesh.rotation.x += dt * 8;
      if (gr.mesh.position.y < 0.1) {
        gr.mesh.position.y = 0.1;
        gr.vel.y = Math.abs(gr.vel.y) * 0.35;   // bounce
        gr.vel.x *= 0.7; gr.vel.z *= 0.7;
      }
      if (gr.fuse <= 0) {
        this.explodeAt(gr.mesh.position.clone(), CONFIG.grenade.radius, CONFIG.grenade.damage, false);
        g.scene.remove(gr.mesh);
        this.grenades.splice(i, 1);
      }
    }
  }

  /** shared explosion: hurts zombies always; hurts the player if hostile */
  explodeAt(pos, radius, damage, hostile) {
    const g = this.game;
    g.audioAt('explosion', pos);
    g.addShake(0.22);
    g.effects.spawnBurst(pos.clone().setY(Math.max(0.6, pos.y)), 0xffb347, 14, 7);
    // flash sphere
    const flash = new THREE.Mesh(new THREE.SphereGeometry(radius * 0.55, 12, 12),
      new THREE.MeshBasicMaterial({ color: 0xffb347, transparent: true, opacity: 0.8 }));
    flash.position.copy(pos);
    g.scene.add(flash);
    let s = 1;
    const grow = setInterval(() => {
      s += 0.35; flash.scale.setScalar(s); flash.material.opacity *= 0.72;
      if (s > 3) { clearInterval(grow); g.scene.remove(flash); }
    }, 30);

    for (const z of [...this.list]) {
      const d = z.mesh.position.distanceTo(pos);
      if (d < radius) z.takeDamage(damage * (1 - d / radius * 0.6), true, z.mesh.position, 'explosion');
    }
    for (const b of g.bosses) {
      if (!b.dead && b.mesh.position.distanceTo(pos) < radius + 1) {
        b.takeDamage(damage * 0.8, false, b.mesh.position);
      }
    }
    if (hostile && g.player.pos.distanceTo(pos) < radius) {
      g.player.takeDamage(damage * 0.5, null);
    } else if (!hostile && g.player.pos.distanceTo(pos) < radius * 0.6) {
      g.player.takeDamage(15, null); // your own bomb stings a little
    }
  }

  clearAll() {
    for (const z of this.list) { z.dead = true; this.game.scene.remove(z.mesh); }
    for (const pr of this.projectiles) this.game.scene.remove(pr.mesh);
    for (const gr of this.grenades) this.game.scene.remove(gr.mesh);
    for (const c of this.corpses) this.game.scene.remove(c.mesh);
    this.list = [];
    this.projectiles = [];
    this.grenades = [];
    this.corpses = [];
    this.spawnQueue = [];
  }
}
