// weapons.js — the arsenal: Lucky Seven, Riverboat Scattergun, Chip Spitter,
// and the NEW Boneyard Special lever rifle (locked until unlocked). Also owns
// the NEW chip-bomb grenades (G) and melee pistol-whip (F). Attachment
// upgrades from upgrades.js modify per-weapon stat multipliers.

import * as THREE from 'three';
import { CONFIG, clamp, rand } from './config.js';
import { Audio } from './audio.js';

const SHOOT_SFX = { pistol: 'shoot_pistol', shotgun: 'shoot_shotgun', smg: 'shoot_smg', rifle: 'shoot_rifle' };

class Weapon {
  constructor(id, def) {
    this.id = id;
    this.def = def;
    this.locked = !!def.locked;
    this.mag = def.mag;
    this.reserve = def.reserve;
    // attachment multipliers (upgrades.js bumps these)
    this.mods = { damage: 1, fireRate: 1, mag: 1, reload: 1, crit: 0, lifesteal: 0 };
  }
  get magSize() { return Math.round(this.def.mag * this.mods.mag); }
  get damage() { return this.def.damage * this.mods.damage; }
  get fireInterval() { return 1 / (this.def.fireRate * this.mods.fireRate); }
  get reloadTime() { return this.def.reload * this.mods.reload; }
  get critChance() { return this.def.critChance + this.mods.crit; }
}

export class Weapons {
  constructor(game) {
    this.game = game;
    this.arsenal = {};
    for (const [id, def] of Object.entries(CONFIG.weapons)) {
      this.arsenal[id] = new Weapon(id, def);
    }
    this.currentId = 'pistol';
    this.triggerHeld = false;
    this.cooldown = 0;
    this.reloading = false;
    this.reloadT = 0;
    this.meleeCd = 0;
    this.kick = 0;
    this.switchT = 0;
    this.pendingSwitch = null;
    this.raycaster = new THREE.Raycaster();
    this._buildViewmodel();
  }

  get current() { return this.arsenal[this.currentId]; }

  reset() {
    for (const [id, def] of Object.entries(CONFIG.weapons)) {
      const w = this.arsenal[id];
      w.locked = !!def.locked;
      w.mods = { damage: 1, fireRate: 1, mag: 1, reload: 1, crit: 0, lifesteal: 0 };
      w.mag = w.magSize;
      w.reserve = def.reserve;
    }
    this.currentId = 'pistol';
    this.reloading = false;
    this.cooldown = 0;
    this.meleeCd = 0;
    this._refreshViewmodel();
  }

  // ----------------------------- viewmodel ----------------------------------
  _mats() {
    if (this._matCache) return this._matCache;
    this._matCache = {
      steel: new THREE.MeshStandardMaterial({ color: 0x2a2a38, metalness: 0.8, roughness: 0.35 }),
      dark:  new THREE.MeshStandardMaterial({ color: 0x16161f, metalness: 0.6, roughness: 0.4 }),
      wood:  new THREE.MeshStandardMaterial({ color: 0x5a3a1a, roughness: 0.7 }),
      brass: new THREE.MeshStandardMaterial({ color: 0xc9a227, metalness: 0.95, roughness: 0.25 }),
      glowGold:  new THREE.MeshBasicMaterial({ color: 0xffd24a }),
      glowPink:  new THREE.MeshBasicMaterial({ color: 0xff2d78 }),
      glowCyan:  new THREE.MeshBasicMaterial({ color: 0x27e6ff }),
      glowGreen: new THREE.MeshBasicMaterial({ color: 0x2dff7a }),
    };
    return this._matCache;
  }

  _box(w, h, d, mat, x, y, z) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    m.position.set(x, y, z);
    return m;
  }

  _cyl(r, len, mat, x, y, z, alongZ = true, segs = 10) {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, segs), mat);
    if (alongZ) m.rotation.x = Math.PI / 2;
    m.position.set(x, y, z);
    return m;
  }

  /** Lucky Seven — gold-trimmed revolver; the drum spins with every shot */
  _mkPistol() {
    const M = this._mats(), g = new THREE.Group();
    g.add(this._box(0.09, 0.13, 0.3, M.steel, 0, 0, -0.05));            // frame
    g.add(this._cyl(0.025, 0.4, M.dark, 0, 0.035, -0.32));              // barrel
    const drum = this._cyl(0.062, 0.11, M.brass, 0, 0.0, -0.08, true, 6);
    g.add(drum);                                                        // 6-shot drum
    g.add(this._box(0.075, 0.16, 0.09, M.wood, 0, -0.13, 0.1));         // grip
    const charm = this._box(0.03, 0.05, 0.012, M.glowGold, 0.06, -0.1, 0.12);
    charm.rotation.z = 0.3; g.add(charm);                               // lucky 7 charm
    g.userData = { drum };
    return g;
  }

  /** Riverboat Scattergun — double-barrel with a pump that racks after firing */
  _mkShotgun() {
    const M = this._mats(), g = new THREE.Group();
    g.add(this._cyl(0.032, 0.62, M.dark, -0.035, 0.03, -0.3));          // barrels
    g.add(this._cyl(0.032, 0.62, M.dark, 0.035, 0.03, -0.3));
    g.add(this._box(0.12, 0.1, 0.28, M.steel, 0, -0.02, 0.02));         // receiver
    g.add(this._box(0.1, 0.11, 0.22, M.wood, 0, -0.05, 0.24));          // stock
    const pump = this._box(0.13, 0.08, 0.16, M.wood, 0, -0.045, -0.32);
    g.add(pump);                                                        // pump forend
    g.add(this._box(0.125, 0.02, 0.3, M.brass, 0, 0.09, -0.28));        // brass rib
    const sight = this._box(0.02, 0.03, 0.02, M.glowPink, 0, 0.11, -0.58);
    g.add(sight);
    g.userData = { cycle: pump, cycleMode: 'pump', cycleBase: -0.32 };
    return g;
  }

  /** Chip Spitter — boxy SMG, long mag, cyan glow strip */
  _mkSmg() {
    const M = this._mats(), g = new THREE.Group();
    g.add(this._box(0.1, 0.13, 0.42, M.dark, 0, 0, -0.06));             // receiver
    g.add(this._cyl(0.03, 0.22, M.steel, 0, 0.02, -0.38));              // stub barrel
    g.add(this._cyl(0.045, 0.16, M.dark, 0, 0.02, -0.46));              // suppressor
    const mag = this._box(0.055, 0.24, 0.1, M.steel, 0, -0.17, -0.02);
    mag.rotation.x = 0.12; g.add(mag);                                  // long mag
    g.add(this._box(0.075, 0.14, 0.08, M.dark, 0, -0.13, 0.16));        // grip
    g.add(this._box(0.104, 0.02, 0.3, M.glowCyan, 0, 0.075, -0.1));     // glow strip
    g.userData = { mag };
    return g;
  }

  /** Boneyard Special — long lever rifle; the lever swings after each shot */
  _mkRifle() {
    const M = this._mats(), g = new THREE.Group();
    g.add(this._cyl(0.028, 0.85, M.steel, 0, 0.035, -0.42, true, 8));   // octagon-ish barrel
    g.add(this._cyl(0.02, 0.7, M.brass, 0, -0.005, -0.38));             // under-barrel mag tube
    g.add(this._box(0.09, 0.12, 0.24, M.brass, 0, 0, 0.0));             // brass receiver
    g.add(this._box(0.09, 0.12, 0.3, M.wood, 0, -0.02, 0.26));          // stock
    const lever = new THREE.Group();
    const loop = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.012, 6, 12), M.steel);
    loop.position.set(0, -0.08, 0.06);
    lever.add(loop);
    lever.position.set(0, -0.05, 0.02);
    g.add(lever);                                                       // lever loop
    g.add(this._box(0.02, 0.04, 0.02, M.glowGreen, 0, 0.1, -0.8));      // glow bead sight
    g.userData = { cycle: lever, cycleMode: 'lever', cycleBase: 0 };
    return g;
  }

  _buildViewmodel() {
    this.vm = new THREE.Group();
    this.vmModels = {
      pistol: this._mkPistol(),
      shotgun: this._mkShotgun(),
      smg: this._mkSmg(),
      rifle: this._mkRifle(),
    };
    const scales = { pistol: 1.0, shotgun: 1.15, smg: 1.05, rifle: 1.15 };
    for (const [id, m] of Object.entries(this.vmModels)) {
      m.visible = false;
      m.scale.setScalar(scales[id]);
      this.vm.add(m);
    }
    this.vm.position.set(0.32, -0.28, -0.7);
    this.game.camera.add(this.vm);

    this.muzzle = new THREE.PointLight(0xffcc66, 0, 8);
    this.muzzle.position.set(0.32, -0.2, -1.2);
    this.game.camera.add(this.muzzle);
    this.flashMesh = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.22),
      new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0.9, depthTest: false, blending: THREE.AdditiveBlending }));
    this.flashMesh.position.set(0.32, -0.24, -1.15);
    this.flashMesh.visible = false;
    this.game.camera.add(this.flashMesh);
    this.cycleT = 0;
    this._refreshViewmodel();
  }

  _refreshViewmodel() {
    for (const [id, m] of Object.entries(this.vmModels)) m.visible = id === this.currentId;
    this.cycleT = 0;
  }

  // ----------------------------- switching ----------------------------------
  switchTo(id) {
    const w = this.arsenal[id];
    if (!w || w.locked || id === this.currentId || this.switchT > 0) {
      if (w?.locked) this.game.ui.prompt(`${w.def.name} is LOCKED — win an ALL IN or buy it at the cashier`);
      return;
    }
    // animated swap: gun drops off-screen, swaps at the bottom, comes back up
    this.pendingSwitch = id;
    this.switchT = 0.28;
    this.reloading = false;
    this.game.ui.reloadBar(null);
    Audio.play('card');
  }

  unlock(id) {
    const w = this.arsenal[id];
    if (!w || !w.locked) return false;
    w.locked = false;
    w.mag = w.magSize;
    this.game.ui.banner(`${w.def.name} UNLOCKED — press ${w.def.slot}`, 'gold', 2600);
    return true;
  }

  // ------------------------------ firing ------------------------------------
  tryFire() {
    const g = this.game;
    if (g.state !== 'COMBAT' || this.reloading || this.cooldown > 0 || this.switchT > 0) return;
    const w = this.current;
    if (w.mag <= 0) {
      Audio.play('dryfire');
      this.startReload();
      return;
    }
    w.mag--;
    this.cooldown = w.fireInterval;
    this.kick = 1;
    Audio.play(SHOOT_SFX[this.currentId]);

    // camera punch per shot (recoil climbs on full auto — control it)
    const KICKS = { pistol: 0.006, shotgun: 0.02, smg: 0.0032, rifle: 0.013 };
    g.player.pitch = Math.min(1.45, g.player.pitch + KICKS[this.currentId]);
    if (this.currentId === 'shotgun') g.addShake(0.06);
    if (this.currentId === 'rifle') g.addShake(0.04);

    // muzzle flash: sprite always (dimmer with reduced flash), light only without
    this.flashMesh.visible = true;
    this.flashMesh.material.opacity = g.settings.reducedFlash ? 0.35 : 0.9;
    this.flashMesh.rotation.z = Math.random() * Math.PI;
    this.flashMesh.scale.setScalar(this.currentId === 'shotgun' ? 1.7 : 1);
    if (!g.settings.reducedFlash) this.muzzle.intensity = 60;
    clearTimeout(this._flashT);
    this._flashT = setTimeout(() => { this.flashMesh.visible = false; this.muzzle.intensity = 0; }, 45);

    g.effects.spawnShell();
    if (Math.random() < 0.6) {
      const sv = new THREE.Vector3();
      this.flashMesh.getWorldPosition(sv);
      g.effects.spawnBurst(sv, 0x777777, 2, 0.8, -1.4);   // smoke rises
    }

    // per-weapon fire animation: revolver drum clicks around, pump/lever cycles
    const model = this.vmModels[this.currentId];
    if (model.userData.drum) model.userData.drum.rotation.z -= Math.PI / 3;
    if (model.userData.cycle) this.cycleT = 0.3;

    // LAST CALL: the final round in the mag hits for triple
    const lastCall = g.playerMods.lastBullet && w.mag === 0 && w.magSize > 1;
    const spreadBase = w.def.spread * (g.player.aiming ? 0.4 : 1);
    for (let p = 0; p < w.def.pellets; p++) {
      this._fireRay(w, spreadBase, lastCall ? 3 : 1);
    }
    if (lastCall) g.ui.prompt('LAST CALL!', 700);
    g.ui.updateHUD();
  }

  _fireRay(w, spread, dmgMult = 1) {
    const g = this.game;
    const dir = new THREE.Vector3(0, 0, -1)
      .applyEuler(g.camera.rotation)
      .add(new THREE.Vector3(rand(-spread, spread), rand(-spread, spread), rand(-spread, spread)))
      .normalize();
    this.raycaster.set(g.camera.position, dir);
    this.raycaster.far = 80;

    const targets = g.enemies.hitMeshes();
    const hits = this.raycaster.intersectObjects(targets, false);
    // walls/cover can block — approximate with arena colliders via distance test on first hit
    const hit = hits[0];
    this._tracer(dir, hit ? hit.distance : 60);
    if (!hit) return;

    const ref = hit.object.userData.ref;
    const isHead = !!hit.object.userData.isHead;
    let dmg = w.damage * dmgMult * g.playerMods.dmgAllMult;   // Blood Pact
    if (g.dashBuffT > 0) dmg *= 1.6;                          // Dash & Cash window
    if (isHead) dmg *= CONFIG.headshotMult;
    const crit = Math.random() < (w.critChance + g.playerMods.critAdd);
    if (crit) dmg *= CONFIG.critMult;
    // Crit Comptroller: crits refund a grenade (2s internal cooldown)
    if (crit && g.playerMods.critGrenade && (this.critGrenadeCd ?? 0) <= 0
        && g.player.grenades < g.playerMods.grenadeMax) {
      this.critGrenadeCd = 2;
      g.player.grenades++;
      g.ui.floatText(hit.point, '+💣', 'ammo');
    }

    g.effects.spawnBurst(hit.point, (crit || isHead) ? 0xc9a227 : 0x8f1f2f, (crit || isHead) ? 7 : 4, 3.5);
    ref.takeDamage(dmg, crit || isHead, hit.point);
    if (w.mods.lifesteal > 0) g.player.heal(dmg * w.mods.lifesteal);
    g.ui.hitmarker(crit || isHead);
    Audio.play(crit ? 'crit' : 'hit');
    if (isHead) {
      g.stats.headshots++;
      g.addChips(Math.round(g.playerMods.headshotBonus));
    }
  }

  _tracer(dir, dist) {
    const g = this.game;
    const start = g.camera.position.clone()
      .add(dir.clone().multiplyScalar(0.8))
      .add(new THREE.Vector3(0, -0.15, 0));
    const end = g.camera.position.clone().add(dir.clone().multiplyScalar(dist));
    const geo = new THREE.BufferGeometry().setFromPoints([start, end]);
    const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0xffe08a, transparent: true, opacity: 0.7 }));
    g.scene.add(line);
    setTimeout(() => { g.scene.remove(line); geo.dispose(); }, 50);
  }

  // ------------------------------ reload ------------------------------------
  startReload() {
    const w = this.current;
    if (this.reloading || this.switchT > 0 || w.mag >= w.magSize || w.reserve <= 0) return;
    this.reloading = true;
    this.reloadT = 0;
    this._reloadHalf = false;
    Audio.play('reload');
  }

  refillAll() {
    for (const w of Object.values(this.arsenal)) {
      w.reserve = w.def.maxReserve;
      w.mag = w.magSize;
    }
    this.game.ui.updateHUD();
  }

  addReservePct(pct) {
    for (const w of Object.values(this.arsenal)) {
      w.reserve = Math.min(w.def.maxReserve, w.reserve + Math.round(w.def.reserve * pct));
    }
  }

  applyReservePenalty(mult) {
    for (const w of Object.values(this.arsenal)) w.reserve = Math.floor(w.reserve * mult);
    this.game.ui.updateHUD();
  }

  // --------------------------- melee + grenade (NEW) ------------------------
  tryMelee() {
    const g = this.game;
    if (g.state !== 'COMBAT' || this.meleeCd > 0) return;
    this.meleeCd = CONFIG.melee.cooldown;
    Audio.play('melee');
    this.kick = 1.6;
    const fwd = new THREE.Vector3(0, 0, -1).applyEuler(g.camera.rotation);
    const targets = [...g.enemies.list, ...g.bosses.filter((b) => !b.dead)];
    for (const e of targets) {
      const to = e.mesh.position.clone().sub(g.player.pos);
      const d = to.length();
      if (d > CONFIG.melee.range + (e.def?.scale || 1) * 0.5) continue;
      to.normalize();
      if (to.dot(fwd) < CONFIG.melee.arcDot) continue;
      e.takeDamage(CONFIG.melee.damage * g.playerMods.meleeDmg, false, e.mesh.position);
      if (e.knockback) e.knockback(fwd, CONFIG.melee.knockback);
      g.ui.hitmarker(false);
    }
  }

  tryGrenade() {
    const g = this.game;
    if (g.state !== 'COMBAT' || g.player.grenades <= 0) return;
    g.player.grenades--;
    const dir = new THREE.Vector3(0, 0, -1).applyEuler(g.camera.rotation);
    dir.y += 0.25; dir.normalize();
    g.enemies.spawnGrenade(
      g.camera.position.clone().add(dir.clone().multiplyScalar(0.8)),
      dir.multiplyScalar(CONFIG.grenade.throwSpeed));
    Audio.play('card');
    g.ui.updateHUD();
  }

  // ------------------------------ update ------------------------------------
  update(dt) {
    const g = this.game;
    this.cooldown = Math.max(0, this.cooldown - dt);
    this.meleeCd = Math.max(0, this.meleeCd - dt);
    this.critGrenadeCd = Math.max(0, (this.critGrenadeCd ?? 0) - dt);

    if (this.reloading) {
      const w = this.current;
      this.reloadT += dt;
      g.ui.reloadBar(clamp(this.reloadT / w.reloadTime, 0, 1));
      if (this.reloadT >= w.reloadTime) {
        const need = w.magSize - w.mag;
        const take = Math.min(need, w.reserve);
        w.mag += take;
        w.reserve -= take;
        // Devil's Reload: speed has a price
        if (g.playerMods.reloadHpCost > 0 && take > 0) {
          g.player.hp = Math.max(1, g.player.hp - g.playerMods.reloadHpCost);
        }
        this.reloading = false;
        g.ui.reloadBar(null);
        g.ui.updateHUD();
      }
    }

    // full-auto
    if (this.triggerHeld && this.current.def.auto) this.tryFire();

    const model = this.vmModels[this.currentId];

    // ---- weapon switch: drop, swap at the bottom, rise ----
    let switchDip = 0;
    if (this.switchT > 0) {
      this.switchT = Math.max(0, this.switchT - dt);
      const prog = 1 - this.switchT / 0.28;
      switchDip = Math.sin(prog * Math.PI) * 0.45;
      if (prog >= 0.5 && this.pendingSwitch) {
        this.currentId = this.pendingSwitch;
        this.pendingSwitch = null;
        this._refreshViewmodel();
        g.ui.updateHUD();
      }
    }

    // ---- reload choreography, per weapon ----
    let reloadDip = 0, reloadRoll = 0;
    if (this.reloading) {
      const w = this.current;
      const p2 = clamp(this.reloadT / w.reloadTime, 0, 1);
      reloadDip = Math.sin(p2 * Math.PI) * 0.14;
      reloadRoll = Math.sin(p2 * Math.PI) * 0.45;
      if (p2 > 0.5 && !this._reloadHalf) { this._reloadHalf = true; Audio.play('ammo'); }
      const ud = model.userData;
      if (ud.drum) {
        // revolver: drum swings out, spins while shells drop in, snaps back
        ud.drum.position.x = p2 < 0.8 ? Math.sin(Math.min(1, p2 / 0.2) * Math.PI / 2) * 0.08
                                      : Math.max(0, (1 - p2) / 0.2) * 0.08;
        if (p2 > 0.2 && p2 < 0.75) ud.drum.rotation.z -= dt * 22;
      } else if (ud.mag) {
        // smg: mag drops away, vanishes, fresh one rises and clicks in
        if (p2 < 0.35) { ud.mag.visible = true; ud.mag.position.y = -0.17 - (p2 / 0.35) * 0.3; ud.mag.rotation.x = 0.12 + p2 * 1.4; }
        else if (p2 < 0.55) { ud.mag.visible = false; }
        else { ud.mag.visible = true; ud.mag.rotation.x = 0.12; ud.mag.position.y = -0.47 + ((p2 - 0.55) / 0.45) * 0.3; }
      } else if (ud.cycleMode === 'pump') {
        // shotgun: shells thumbed in, pump racks twice
        const cyc = Math.sin(p2 * Math.PI * 4);
        ud.cycle.position.z = ud.cycleBase + Math.max(0, cyc) * 0.11;
      } else if (ud.cycleMode === 'lever') {
        // rifle: lever cranks through the reload
        ud.cycle.rotation.x = Math.max(0, Math.sin(p2 * Math.PI * 5)) * 1.0;
      }
    } else {
      // make sure parts are home after a reload
      const ud = model.userData;
      if (ud.drum) ud.drum.position.x = 0;
      if (ud.mag && !ud.mag.visible) { ud.mag.visible = true; ud.mag.position.y = -0.17; ud.mag.rotation.x = 0.12; }
    }

    // ---- post-shot pump / lever cycling ----
    if (this.cycleT > 0 && model.userData.cycle && !this.reloading) {
      this.cycleT = Math.max(0, this.cycleT - dt);
      const k = Math.sin((1 - this.cycleT / 0.3) * Math.PI);   // out and back
      if (model.userData.cycleMode === 'lever') {
        model.userData.cycle.rotation.x = k * 1.15;
      } else {
        model.userData.cycle.position.z = model.userData.cycleBase + k * 0.13;
      }
    }
    // smg mag rattle on sustained fire
    if (model.userData.mag && !this.reloading) {
      model.userData.mag.rotation.z = this.kick * 0.06 * Math.sin(performance.now() / 18);
    }

    // ---- kick + walk sway + idle breathing ----
    this.kick = Math.max(0, this.kick - dt * 8);
    const moving = g.player.onGround
      && (g.player.keys['KeyW'] || g.player.keys['KeyA'] || g.player.keys['KeyS'] || g.player.keys['KeyD']);
    const swayX = moving ? Math.sin(g.player.bobT) * 0.014 : 0;
    const swayY = moving ? -Math.abs(Math.cos(g.player.bobT)) * 0.012 : 0;
    const breathe = Math.sin(performance.now() / 640) * 0.006;

    const aim = g.player.aiming && !this.reloading && this.switchT <= 0;
    const baseX = aim ? 0 : 0.32;
    const baseY = aim ? -0.22 : -0.28;
    const target = new THREE.Vector3(
      baseX + swayX,
      baseY + swayY + breathe - reloadDip - switchDip,
      -0.7 + this.kick * 0.12);
    this.vm.position.lerp(target, Math.min(1, dt * 12));
    this.vm.rotation.x = this.kick * 0.25 + reloadDip * 1.2;
    this.vm.rotation.z += ((aim ? 0 : reloadRoll) - this.vm.rotation.z) * Math.min(1, dt * 10);

    g.ui.crosshairSpread(this.kick * 10 + (g.player.aiming ? 0 : 4));
  }
}
