# HOUSE OF THE UNDEAD

The casino never closed. The gamblers never left.

A browser FPS roguelite: fight casino zombies for 10 rounds, bank chips, then
gamble them at the tables between rounds — winning a wager is the only way to
earn weapon upgrades, and losing brings a penalty. Round 5: THE PIT BOSS.
Round 10: THE HOUSE DEALER.

## Run it

Needs a local web server (ES modules won't load from file://):

```
cd HOUSE-OF-THE-UNDEAD
python3 -m http.server 8000     # or: npx serve
```

Open http://localhost:8000 — click the canvas to lock your mouse.

No internet needed after that: Three.js is vendored locally and all sound is
synthesized live with WebAudio (no audio files).

## Controls

| Key | Action |
|---|---|
| WASD | move |
| Mouse | look / LMB fire / RMB aim |
| Shift | sprint |
| Space | jump |
| **Q** | **dash** (brief invulnerability) |
| **G** | **chip bomb** (grenade) |
| **F** | **melee** pistol-whip |
| R | reload |
| 1–4 | weapons (4 = Boneyard Special, must be unlocked) |
| Esc | pause |
| F3 | debug panel |

## What's in this build

- **⚡ DAILY RUN**: one attempt per day, seeded from the date — everyone in the
  world gets the same rounds, specials, objectives, card deals, and wheel
  spins. No vault perks (level field), no mid-run saves (refreshing doesn't
  give a retry), score = round x1000 + chips + kills x10 (+5000 for beating
  the house). Your score shows on the menu until midnight rolls the seed
- **♾ ENDLESS MODE**: beating round 10 no longer ends the run — the floor
  reopens. Keep going with a boss every 5th round (Pit Boss or House Dealer,
  scaling up), or hit CASH OUT at any intermission to bank the win. Dying deep
  in endless still counts as a victory, and deeper rounds mean fatter vault
  deposits
- **😤 THE BOSSES REMEMBER**: die to a boss and it holds the grudge across
  runs — +10% HP per unpaid debt (cap 5), personal taunts in the intro and on
  spawn. Finally beat it and you settle the grudge for +75 chips per debt

- 4 weapons with distinct 3D models and fire animations: the Lucky Seven
  revolver's drum clicks around per shot, the Riverboat Scattergun racks its
  pump, the Chip Spitter's mag rattles on full auto, and the **Boneyard
  Special** swings its lever after every round (unlock it via a LEGENDARY
  wager win or 450 chips at the cashier). Balance v3: pistol and shotgun
  buffed, smg trades per-shot damage for rate + mag, rifle hits like the
  legendary it is
- 10 enemy types, all in casino dress: gambler walkers (trilby + loose tie),
  valet sprinters (red vest), bouncer brutes (suit + shades), cocktail-server
  spitters (serving tray of something toxic), high-roller gasbags (gold chain,
  explode on death), pit security guards (visor + pauldrons, weak head), and
  THE DEBT COLLECTOR (top hat + briefcase, steals chips — kill him to get them
  back with interest), plus three new faces: the CROUPIER (vest + green visor,
  flings 3-card razor bursts from range), the MAGICIAN (cape + top hat,
  teleports toward you in a purple poof), and the JACKPOT — a golden walking
  slot machine that flees; kill it inside 20 seconds for a 130-200 chip payout
  or it cashes out and leaves
- Blackjack with dealt-in card animations, hole-card flip, and one-at-a-time
  dealer draws; roulette with a counter-spinning ball that spirals into the
  winning pocket, plus a history strip of past spins; win/lose glow on every
  table
- **Five card draw poker**: 100-chip ante, click cards to hold, one draw,
  beat the dealer — your hand rank sets the reward tier (pair = common,
  two pair to straight = rare, flush or better = legendary)
- **Special rounds** (40% chance on non-boss rounds 3+): HIGH STAKES (double
  chips, +50% enemy damage), BLACKOUT (lights out), RUSH HOUR (all sprinters),
  HEAVYWEIGHT NIGHT (brutes and pit guards), VIP NIGHT (every zombie is a
  golden elite, chips x2). The chip multiplier applies to everything you earn
  that round, including the clear bonus
- **Round objectives** (50% chance on non-boss rounds 2+): optional side goals
  shown on the HUD — HEADHUNTER (8 headshots), UNTOUCHABLE (take no damage),
  DEMOLITION DERBY (6 explosion kills), SPEED CLEAR (under 60s). Complete for
  bonus chips, health, or grenades; no penalty for missing
- **Cursed upgrades** (purple cards, rare+ offers): real power with real
  downsides — Blood Pact (+40% damage, -25 max HP), Loaded Dice (+50% chip
  pickups, hits cost 5 chips), Devil's Reload (40% faster, 3 HP per reload),
  Glass Cannon (+25% crit, armor stops working), House Marker (+300 chips now,
  next wager loss is one penalty step nastier)
- **Synergy attachments**: Dash & Cash (+60% damage for 1.5s after dashing),
  Crit Comptroller (crits refund a chip bomb), Vampire Chips (chips heal you),
  Combo Insurance (+2s combo window), Last Call (final bullet in every mag
  deals triple)
- A **3x3 slot machine** with 5 paylines (3 rows + both diagonals, 50
  chips/spin, one free column re-spin per visit; slots can't kill you)
- **Choose-your-stake wagers**: bet any amount from 50 chips to everything —
  a slider with MIN / 25% / HALF / ALL IN quick buttons. Reward tier is earned
  by risk: RARE needs 150+ AND 40% of your bankroll on the line, LEGENDARY
  needs 300+ AND 85%. Poker's ante is your choice too — hand rank still sets
  the tier, and a legendary-risk ante bumps it +1. One free House Credit when
  broke
- **Minimap radar**: top-left corner, rotates with your facing. Enemy dots
  colored by type (spitters green, the Debt Collector gold, brutes bigger),
  bosses as red rings, off-range threats pinned dim at the rim. Disabled by
  the same penalty that kills the threat indicator
- 6 weapon attachments x 3 tiers plus player upgrades: Running Shoes, Chip
  Magnet, Steel Toe, Quick Hands, Casino Insurance, Card Counter, High Roller
  Suite, Demolition License, Marked Cards
- Kill-combo chip multiplier (chain kills within 3.5s, up to x3)
- Loss penalties (mild/moderate/severe), boss phases, red-alert lighting
- **Casino lounge band**: the background music is a swinging procedural jazz
  vamp — walking upright bass with shuffle timing, brushed ride ticks, soft
  chord pads every bar, occasional vibraphone riffs. Danger speeds the swing
  and layers in hats; boss fights drop it into a fast minor stride
- **Bigger floor**: the arena grew ~40% (68m across) and gained a whole new
  wing — a raised stage with velvet curtain, mic stand, and colored
  spotlights ("LIVE TONIGHT"), a glowing fountain centerpiece, six slot banks,
  five card tables, and a longer bar. Spawns, radar range, boss teleports, and
  ambient chimes all scaled to match
- **Realistic casino undead**: corpse-flesh skin (every kind's color pulled
  toward grey-green decay), necks, festering wounds, lolling head tilts, torn
  suit trousers, gore-stained grasping hands, and per-zombie height variance —
  while keeping every casino outfit
- **Animation pass v2**: per-weapon reload choreography (revolver drum swings
  out and spins, shotgun racks its pump twice, SMG drops the mag and slaps a
  new one in, rifle cranks its lever), animated weapon switching, walk sway +
  idle breathing on the viewmodel, muzzle smoke that drifts up, camera dip on
  hard landings, bullet stagger on zombies, and varied death falls (sprinters
  corkscrew down)
- **Full spatial 3D audio**: groans, deaths, acid spits, explosions, and boss
  telegraphs all pan and attenuate from their real positions — you hear the
  flank before you see it. Brutes, pit guards, and the Debt Collector have
  audible footsteps. Sounds coming from behind cover are muffled. The casino
  has a living ambient bed (crowd murmur, ghost slot payouts from the actual
  machine banks, neon buzz), and the music's tempo and hi-hat layer scale with
  how many zombies are near you and how low your health is. All procedural
  WebAudio — still zero sound files
- **THE VAULT — meta progression**: 20% of every run's final chips (+2% per
  round reached, +10% for a win) banks permanently. Spend it on the main menu:
  Kevlar Vest (start with armor), Deep Pockets (+grenades), Front Money
  (starting chips), Comped Rates (cheaper cashier, prices update live),
  Regular's Card (4th upgrade card on every offer), Gun Locker (Boneyard
  Special from round 1). Losing runs are deposits now. Farm-proof: only chips
  EARNED in the run deposit — Front Money starting chips are excluded
- **Mid-run saves**: your run snapshots at every intermission and after every
  purchase, wager, and upgrade — closing the tab resumes from the intermission
  via a CONTINUE RUN button. Stakes save the moment they hit the table, so
  save-scumming a bad blackjack hand doesn't work
- Bug fix: Demolition License and Marked Cards were mutating global config and
  silently persisting across runs — now correctly per-run
- Reduced-flashing accessibility option, local high scores, F3 debug panel
- Feel pass: zombies walk with swinging limbs, lunge when they attack, and
  topple over when they die; muzzle flashes light the room; shell casings
  eject and bounce; blood / gold-spark impact particles; camera punch per
  shot; screen shake on explosions and boss slams; brief slow-mo on the last
  kill of a round and on boss defeats (shake is softened by reduced-flash)

## A note on this version

Only `index.html`, `main.js`, and `debug.js` survived from the previous build
(the folder upload came through empty), so every other module was rebuilt to
match those files' interfaces, then extended. Known crash sources fixed along
the way: the post-wager soft-lock (all panels hidden with no state resumed),
pointer-lock rejections when re-locking too fast after Esc, and a per-frame
crash guard so one bad frame logs to the console instead of freezing the game.

All chips and wagers are fictional game currency with no real-world value.
